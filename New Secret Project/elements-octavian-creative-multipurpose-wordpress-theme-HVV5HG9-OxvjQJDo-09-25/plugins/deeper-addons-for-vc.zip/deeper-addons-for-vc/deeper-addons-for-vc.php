<?php 
/*
Plugin Name: Deeper Addons for Visual Composer
Plugin URI: http://ninzio.com
Description: Deeper Addons for Visual Composer
Version: 1.0
Author: Ninzio Themes
Author URI: https://ninzio.com
Text Domain: deeper
Domain Path: /languages
License: GNU General Public License v3.0
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Definitions
define( 'DEEPER_VERSION', '1.0' );
define( 'DEEPER_URL', plugins_url( '/', __FILE__ ) );
define( 'DEEPER_PATH', plugin_dir_path( __FILE__ ) );
define( 'DEEPER_FILE', __FILE__ );

/**
 * Include the plugin files
 */
function deeper_addons_for_vc() {

	// Load main class
	require_once DEEPER_PATH . 'includes/loader.php';

	// Load translations
	load_plugin_textdomain( 'deeper', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'plugins_loaded', 'deeper_addons_for_vc' );


