<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


// Register section post type
function register_section_post_type() {
    $section_slug = 'section';

    $labels = array(
        'name'               => esc_html__( 'Single Section', 'deeper' ),
        'singular_name'      => esc_html__( 'Single Section Item', 'deeper' ),
        'add_new'            => esc_html__( 'Add New', 'deeper' ),
        'add_new_item'       => esc_html__( 'Add New Item', 'deeper' ),
        'new_item'           => esc_html__( 'New Item', 'deeper' ),
        'edit_item'          => esc_html__( 'Edit Item', 'deeper' ),
        'view_item'          => esc_html__( 'View Item', 'deeper' ),
        'all_items'          => esc_html__( 'All Items', 'deeper' ),
        'search_items'       => esc_html__( 'Search Items', 'deeper' ),
        'parent_item_colon'  => esc_html__( 'Parent Items:', 'deeper' ),
        'not_found'          => esc_html__( 'No items found.', 'deeper' ),
        'not_found_in_trash' => esc_html__( 'No items found in Trash.', 'deeper' )
    );

    $args = array(
        'labels'        => $labels,
        'rewrite'       => array( 'slug' => $section_slug ),
        'supports'      => array( 'title', 'editor', 'thumbnail' ),
        'public'        => true
    );

    register_post_type( 'section', $args );
}

add_action('init', 'register_section_post_type');

// Single Section update messages.
function section_updated_messages( $messages ) {
    $post             = get_post();
    $post_type        = get_post_type( $post );
    $post_type_object = get_post_type_object( $post_type );

    $messages['section'] = array(
        0  => '', // Unused. Messages start at index 1.
        1  => esc_html__( 'Single Section updated.', 'deeper' ),
        2  => esc_html__( 'Custom field updated.', 'deeper' ),
        3  => esc_html__( 'Custom field deleted.', 'deeper' ),
        4  => esc_html__( 'Single Section updated.', 'deeper' ),
        5  => isset( $_GET['revision'] ) ? sprintf( esc_html__( 'Single Section restored to revision from %s', 'deeper' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
        6  => esc_html__( 'Single Section published.', 'deeper' ),
        7  => esc_html__( 'Single Section saved.', 'deeper' ),
        8  => esc_html__( 'Single Section submitted.', 'deeper' ),
        9  => sprintf(
            esc_html__( 'Single Section scheduled for: <strong>%1$s</strong>.', 'deeper' ),
            date_i18n( esc_html__( 'M j, Y @ G:i', 'deeper' ), strtotime( $post->post_date ) )
        ),
        10 => esc_html__( 'Single Section draft updated.', 'deeper' )
    );
    return $messages;
}

add_filter( 'post_updated_messages', 'section_updated_messages' );

// Register section taxonomy
function register_section_taxonomy() {
    $cat_slug = 'section_category';

    $labels = array(
        'name'                       => esc_html__( 'Single Section Categories', 'deeper' ),
        'singular_name'              => esc_html__( 'Category', 'deeper' ),
        'search_items'               => esc_html__( 'Search Categories', 'deeper' ),
        'menu_name'                  => esc_html__( 'Categories', 'deeper' ),
        'all_items'                  => esc_html__( 'All Categories', 'deeper' ),
        'parent_item'                => esc_html__( 'Parent Category', 'deeper' ),
        'parent_item_colon'          => esc_html__( 'Parent Category:', 'deeper' ),
        'new_item_name'              => esc_html__( 'New Category Name', 'deeper' ),
        'add_new_item'               => esc_html__( 'Add New Category', 'deeper' ),
        'edit_item'                  => esc_html__( 'Edit Category', 'deeper' ),
        'update_item'                => esc_html__( 'Update Category', 'deeper' ),
        'add_or_remove_items'        => esc_html__( 'Add or remove categories', 'deeper' ),
        'choose_from_most_used'      => esc_html__( 'Choose from the most used categories', 'deeper' ),
        'not_found'                  => esc_html__( 'No Category found.', 'deeper' ),
        'menu_name'                  => esc_html__( 'Categories', 'deeper' )
    );
    $args = array(
        'labels'        => $labels,
        'rewrite'       => array( 'slug'=>$cat_slug ),
        'hierarchical'  => true,
    );
    register_taxonomy( 'section_category', 'section', $args );
}

add_action( 'init', 'register_section_taxonomy' );