<?php
class Deeper_Widget_Information extends WP_Widget {
    // Holds widget settings defaults, populated in constructor.
    protected $defaults;

    // Constructor
    function __construct() {
        $this->defaults = array(
            'title'            => 'Information',
            'desc'             => 'Desciption',
            'info_title1'      => '',
            'info1'            => '',
            'info_title2'      => '',
            'info2'            => '',
            'info_title3'      => '',
            'info3'            => '',
            'info_title4'      => '',
            'info4'            => '',
            'info_title5'      => '',
            'info5'            => '',
        );

        parent::__construct(
            'widget_information',
            esc_html__( 'Information', 'deeper' ),
            array(
                'classname'   => 'widget_information',
                'description' => esc_html__( 'Display Information', 'deeper' )
            )
        );
    }

    // Display widget
    function widget( $args, $instance ) {
        $instance = wp_parse_args( $instance, $this->defaults );
        extract( $instance );
        extract( $args );        

        echo $before_widget;

        if ( ! empty( $title ) ) { echo $before_title . $title . $after_title; }
        
        if ( $desc ) echo '<p class="desc">'. esc_html( $desc ) .'</p>';
        ?>

        <ul class="clearfix">
            <?php
            
            if ( $info_title1 || $info1 ) 
                printf( '<li class="clearfix"><span class="info-title">%1$s</span><span class="info">%2$s</span></li>', 
                    esc_html( $info_title1 ), esc_html( $info1 ) );

            if ( $info_title2 || $info2 ) 
                printf( '<li class="clearfix"><span class="info-title">%1$s</span><span class="info">%2$s</span></li>', 
                    esc_html( $info_title2 ), esc_html( $info2 ) );

            if ( $info_title3 || $info3 ) 
                printf( '<li class="clearfix"><span class="info-title">%1$s</span><span class="info">%2$s</span></li>', 
                    esc_html( $info_title3 ), esc_html( $info3 ) );

            if ( $info_title4 || $info4 ) 
                printf( '<li class="clearfix"><span class="info-title">%1$s</span><span class="info">%2$s</span></li>', 
                    esc_html( $info_title4 ), esc_html( $info4 ) );

            if ( $info_title5 || $info5 ) 
                printf( '<li class="clearfix"><span class="info-title">%1$s</span><span class="info">%2$s</span></li>', 
                    esc_html( $info_title5 ), esc_html( $info5 ) );

            ?>
        </ul>

		<?php echo $after_widget;
    }

    // Update widget
    function update( $new_instance, $old_instance ) {
        $instance               = $old_instance;

        $instance['title']              = strip_tags( $new_instance['title'] );
        $instance['desc']              = strip_tags( $new_instance['desc'] );
        $instance['info_title1']          = strip_tags( $new_instance['info_title1'] );
        $instance['info1']              =  $new_instance['info1'];
        $instance['info_title2']          = strip_tags( $new_instance['info_title2'] );
        $instance['info2']              =  $new_instance['info2'];
        $instance['info_title3']          = strip_tags( $new_instance['info_title3'] );
        $instance['info3']              =  $new_instance['info3'];
        $instance['info_title4']          = strip_tags( $new_instance['info_title4'] );
        $instance['info4']              =  $new_instance['info4'];
        $instance['info_title5']          = strip_tags( $new_instance['info_title5'] );
        $instance['info5']              =  $new_instance['info5'];
        
        return $instance;
    }

    // Widget setting
    function form( $instance ) {
        $instance = wp_parse_args( $instance, $this->defaults );       
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'deeper' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'desc' ) ); ?>"><?php esc_html_e( 'Description:', 'deeper' ) ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'desc' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'desc' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['desc'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'info_title1' ) ); ?>"><?php esc_html_e( 'Info Title 1:', 'deeper' ) ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'info_title1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'info_title1' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['info_title1'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'info1' ) ); ?>"><?php esc_html_e('Information 1:', 'deeper') ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'info1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'info1' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['info1'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'info_title2' ) ); ?>"><?php esc_html_e( 'Info Title 2:', 'deeper' ) ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'info_title1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'info_title2' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['info_title2'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'info2' ) ); ?>"><?php esc_html_e('Information 3:', 'deeper') ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'info2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'info2' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['info2'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'info_title3' ) ); ?>"><?php esc_html_e( 'Info Title 3:', 'deeper' ) ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'info_title3' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'info_title3' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['info_title3'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'info3' ) ); ?>"><?php esc_html_e('Information 3:', 'deeper') ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'info3' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'info3' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['info3'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'info_title4' ) ); ?>"><?php esc_html_e( 'Info Title 4:', 'deeper' ) ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'info_title4' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'info_title4' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['info_title4'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'info4' ) ); ?>"><?php esc_html_e('Information 4:', 'deeper') ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'info4' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'info4' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['info4'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'info_title5' ) ); ?>"><?php esc_html_e( 'Info Title 5:', 'deeper' ) ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'info_title5' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'info_title5' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['info_title5'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'info5' ) ); ?>"><?php esc_html_e('Information 5:', 'deeper') ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'info5' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'info5' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['info5'] ); ?>">
        </p>
    <?php
    }
}
add_action( 'widgets_init', 'register_deeper_information' );

// Register widget
function register_deeper_information() {
    register_widget( 'Deeper_Widget_Information' );
}


