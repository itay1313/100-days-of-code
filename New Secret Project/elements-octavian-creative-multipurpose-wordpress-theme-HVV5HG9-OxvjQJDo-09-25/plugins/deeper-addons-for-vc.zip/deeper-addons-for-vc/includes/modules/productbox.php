<?php
/**
 * Product Box shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Product_Box_Shortcode' ) ) {

	class Deeper_Product_Box_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_product', array( 'Deeper_Product_Box_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_product', array( 'Deeper_Product_Box_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$data = '';
			$config = array();

			extract( shortcode_atts( array(
				'product_id' => '',
				'product_image' => '',
				'product_image_2' => '',

				'show_cat' => '',
				'class' => '',
				// Design
				'image_rounded' => '',
				// Animation
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );
			$sale_html = $image_html = $link_html = $cart_html = $cat_html = '';
			$css = $cls = $img_css = $sale_price = $regular_price = '';
			$anim_cls = $anim_data = '';
			if ( $class ) $cls .= ' ' . $class;

			if ( $product_id ) {
				$product = new WC_Product( $product_id );

				// Sale Flash
				if ( $product->is_on_sale() ) {
					// Get product prices
			        $regular_price = (float) $product->get_regular_price(); // Regular price
			        $sale_price = (float) $product->get_price(); // Active price (the "Sale price" when on-sale)

			        // "Saving Percentage" calculation and formatting
			        $precision = 1; // Max number of decimals
			        $saving_percentage = round( 100 - ( $sale_price / $regular_price * 100 ), 0 ) . '%';
					$sale_html .= '<span class="onsale">-' . $saving_percentage . '</span>';
				}

				// Image
				if ( $product_image ) {
					if ( $image_rounded ) $img_css .= 'border-radius:' . $image_rounded . ';';

					$image_html = sprintf('<img class="img1" src="%1$s" alt="Product">', 
						esc_url( wp_get_attachment_image_src( $product_image, 'full' )[0] ) );

					if ( $product_image_2 ) {
						$cls .= ' has-2-img';
						$image_html .= sprintf('<img class="img2" src="%1$s" alt="Product">', 
							esc_url( wp_get_attachment_image_src( $product_image_2, 'full' )[0] ) );
					}
				}

				// Product Link
				$link_html = '<a href="' . esc_url( get_permalink( $product_id ) ) . '" class="product-link"></a>';

				// Cart
				$cart_html = sprintf(
					'<a href="%2$s/?add-to-cart=%1$s" data-product_id="%1$s"
					class="button product_type_simple add_to_cart_button ajax_add_to_cart added"  rel="nofollow" data-quantity="1"></a>',
					$product_id,
					esc_url( get_site_url() )
				);

				// Product title
				$title_html = '<h2 class="product-title"><a href="' . esc_url( get_permalink( $product_id ) ) . '">' . esc_attr( get_the_title( $product_id ) ) . '</a></h2>';

				// Price
				$regular_price = (float) $product->get_regular_price();
				if ( $product->is_on_sale() ) {
					$price_html = sprintf(
						'<span class="price">
							<del>
								<span class="amount"><span class="symbol">%1$s</span>%2$s</span>
							</del>
							<ins>
								<span class="amount"><span class="symbol">%1$s</span>%3$s</span>
							</ins>
						</span>',
						get_woocommerce_currency_symbol(),
						sanitize_text_field( $regular_price ),
						$sale_price
					);
				} else {
					$price_html = sprintf(
						'<span class="price">
							<span class="amount"><span class="symbol">%1$s</span>%2$s</span>
						</span>',
						get_woocommerce_currency_symbol(),
						$product->get_regular_price()
					);
				}

				// Category
				if ( $show_cat ) {
					$cat_html = '<span class="product-cat">' . wc_get_product_category_list( $product_id, ', ', '', '' ) . '</span>';
				}				

				$product_html = sprintf(
					'<div class="deeper-product-box %6$s">
						<div class="product-image" style="%5$s">
							%1$s
							%2$s
							<div class="btn-wrap">	
								%3$s
								%4$s
							</div>
						</div>	

						<div class="product-info">
							%7$s
							%9$s
							%8$s
						</div>
					</div>',
					$image_html,
					$sale_html,
					$cart_html,
					$link_html,
					$img_css,
					$cls,
					$title_html,
					$price_html,
					$cat_html
				);

				// Animation
		        if ( $animation ) {
				    $anim_cls .= ' wow '. $animation_effect;
				    $anim_data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';

				    return sprintf( '<div class="wow %2$s" %3$s>%1$s</div>', $product_html, $anim_cls, $anim_data );
				} else {
					return $product_html;
				}
			}
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Product Box', 'deeper' ),
		        'description' => __( 'Displays a product box with custom image.', 'deeper' ),
		        'base' => 'deeper_product',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/products.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
		        	array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => esc_html__('Product ID', 'deeper'),
						'param_name' => 'product_id',
						'value' => '',
					),
			        array(
						'type' => 'attach_image',
						'heading' => esc_html__('Product Image', 'deeper'),
						'param_name' => 'product_image',
						'value' => '',
					),
					array(
						'type' => 'attach_image',
						'heading' => esc_html__('Product Image 2 ( Optional )', 'deeper'),
						'param_name' => 'product_image_2',
						'value' => '',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Show Category?', 'deeper' ),
						'param_name' => 'show_cat',
						'value'      => array(
							'No' => '',
							'Yes' => 'true',
						),
						'std'		=> '',
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Extra Class', 'deeper'),
						'param_name' => 'class',
						'value' => '',
					),
					// Design
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Image Rounded', 'deeper'),
						'param_name' => 'image_rounded',
						'value' => '',
						'group' => esc_html__( 'Design', 'deeper' )
					),
					// Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		        )
		    );
		}
	}

	new Deeper_Product_Box_Shortcode;
}
