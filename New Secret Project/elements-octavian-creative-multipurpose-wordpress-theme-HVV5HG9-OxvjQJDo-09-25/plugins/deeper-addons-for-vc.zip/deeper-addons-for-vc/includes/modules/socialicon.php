<?php
/**
 * Social Icon shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Social_Icon_Shortcode' ) ) {

	class Deeper_Social_Icon_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_socialicon', array( 'Deeper_Social_Icon_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_socialicon', array( 'Deeper_Social_Icon_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$data = '';


			extract( shortcode_atts( array(
				// General
				'align' => 'align-left',
				'icon_color' => '',
				'bg_color' => '',
				'rounded' => '',
				'border' => '',
				'margin' => '',
				'font_size' => '',
				'line_height' => '',
				'width' => '',
				// Hover
				'hover_color' => '',
				'hover_bg' => '',
				'hover_border' => '',
				// URL
				'facebook' => '',
				'twitter' => '',
				'google' => '',
				'linkedin' => '',
				'instagram' => '',
				'behance' => '',
				'pinterest' => '',
				'youtube' => '',
				'dribbble' => '',
				'rss' => '',

			), $atts ) );

			$social_css = $social_cls = $html = '';
			$css = $cls = $data = '';
			$config = array();
			$cls = $align;
			$accent = deeper_get_accent_color();


			if ( $icon_color == $accent ) {
				$social_cls .= ' accent-color';
			} else {
				$social_css .= 'color:' . $icon_color . ';';
			}

			if ( $bg_color == $accent ) {
				$social_cls .= ' bg-accent';
			} else {
				$social_css .= 'background-color:' . $bg_color . ';';
			}

			if ( $rounded ) $social_css .= 'border-radius:' . $rounded . ';';
			if ( $border ) $social_css .= 'border:' . $border . ';';
			if ( $margin ) $social_css .= 'margin:' . $margin . ';';
			if ( $font_size ) $social_css .= 'font-size:' . $font_size . ';';
			if ( $width ) $social_css .= 'text-align:center;width:' . $width . ';height:' . $width . ';';
			if ( $line_height ) $social_css .= 'line-height:' . $line_height . ';';

			// Social string
			if ( $facebook ) 
				$html .= sprintf( '<a href="%1$s" class="fab fa-facebook-f %2$s" style="%3$s"></a>', esc_url( $facebook ), $social_cls, $social_css );
			if ( $twitter ) 
				$html .= sprintf( '<a href="%1$s" class="fab fa-twitter %2$s" style="%3$s"></a>', esc_url( $twitter ), $social_cls, $social_css );
			if ( $google ) 
				$html .= sprintf( '<a href="%1$s" class="fab fa-google %2$s" style="%3$s"></a>', esc_url( $google ), $social_cls, $social_css );
			if ( $linkedin ) 
				$html .= sprintf( '<a href="%1$s" class="fab fa-linkedin %2$s" style="%3$s"></a>', esc_url( $linkedin ), $social_cls, $social_css );
			if ( $instagram ) 
				$html .= sprintf( '<a href="%1$s" class="fab fa-instagram %2$s" style="%3$s"></a>', esc_url( $instagram ), $social_cls, $social_css );
			if ( $behance ) 
				$html .= sprintf( '<a href="%1$s" class="fab fa-behance %2$s" style="%3$s"></a>', esc_url( $behance ), $social_cls, $social_css );
			if ( $pinterest ) 
				$html .= sprintf( '<a href="%1$s" class="fab fa-pinterest %2$s" style="%3$s"></a>', esc_url( $pinterest ), $social_cls, $social_css );
			if ( $youtube ) 
				$html .= sprintf( '<a href="%1$s" class="fab fa-youtube %2$s" style="%3$s"></a>', esc_url( $youtube ), $social_cls, $social_css );
			if ( $dribbble ) 
				$html .= sprintf( '<a href="%1$s" class="fab fa-dribbble %2$s" style="%3$s"></a>', esc_url( $dribbble ), $social_cls, $social_css );
			if ( $css ) 
				$html .= sprintf( '<a href="%1$s" class="fab fa-css %2$s" style="%3$s"></a>', esc_url( $css ), $social_cls, $social_css );

			// Hover
			if ( $hover_color ) $config['hoverColor'] = $hover_color;
			if ( $hover_bg ) $config['hoverBg'] = $hover_bg;
			if ( $hover_border ) $config['hoverBorder'] = $hover_border;

			if ( $config ) {
				$data = 'data-config=\'' . json_encode( $config ) . '\'';
				$cls .= ' social-' . rand();
			}

			return sprintf(
				'<div class="deeper-socials %1$s" %3$s>%2$s</div>',
				$cls,
				$html,
				$data
			);
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Social Icon', 'deeper' ),
		        'description' => __( 'Social Icon.', 'deeper' ),
		        'base' => 'deeper_socialicon',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/social.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
		        	array(
						'type'       => 'dropdown',
						'heading'    => __( 'Alignment', 'deeper' ),
						'param_name' => 'align',
						'value'      => array(
							'Left' => 'align-left',
							'Right' => 'align-right',
							'Center' => 'align-center',
						),
						'std'		=> 'align-left',
					),
		        	array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Color', 'deeper' ),
						'param_name' => 'icon_color',
						'value' => '',
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Background Color', 'deeper' ),
						'param_name' => 'bg_color',
						'value' => '',
		            ),
		        	array(
						'type' => 'textfield',
						'heading' => __( 'Rounded', 'deeper' ),
						'param_name' => 'rounded',
						'value' => '',
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Border', 'deeper' ),
						'param_name' => 'border',
						'value' => '',
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Margin', 'deeper' ),
						'param_name' => 'margin',
						'value' => '',
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon : Font Size', 'deeper' ),
						'param_name' => 'font_size',
						'value' => '',
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon : Line Height', 'deeper' ),
						'param_name' => 'line_height',
						'value' => '',
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon : Width & Height', 'deeper' ),
						'param_name' => 'width',
						'value' => '',
		            ),
		            // URL
		        	array(
						'type' => 'colorpicker',
						'heading' => __( 'Hover : Icon Color', 'deeper' ),
						'param_name' => 'hover_color',
						'value' => '',
						'group' => esc_html__( 'Hover', 'deeper' )
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Hover : Background Color', 'deeper' ),
						'param_name' => 'hover_bg',
						'value' => '',
						'group' => esc_html__( 'Hover', 'deeper' )
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Hover : Border Color', 'deeper' ),
						'param_name' => 'hover_border',
						'value' => '',
						'group' => esc_html__( 'Hover', 'deeper' )
		            ),
		        	// URL
		        	array(
						'type' => 'textfield',
						'heading' => __( 'Facebook', 'deeper' ),
						'param_name' => 'facebook',
						'value' => '',
						'group' => esc_html__( 'URL', 'deeper' )
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Twitter', 'deeper' ),
						'param_name' => 'twitter',
						'value' => '',
						'group' => esc_html__( 'URL', 'deeper' )
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Google', 'deeper' ),
						'param_name' => 'google',
						'value' => '',
						'group' => esc_html__( 'URL', 'deeper' )
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Dribbble', 'deeper' ),
						'param_name' => 'dribbble',
						'value' => '',
						'group' => esc_html__( 'URL', 'deeper' )
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Youtube', 'deeper' ),
						'param_name' => 'youtube',
						'value' => '',
						'group' => esc_html__( 'URL', 'deeper' )
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Linkedin', 'deeper' ),
						'param_name' => 'linkedin',
						'value' => '',
						'group' => esc_html__( 'URL', 'deeper' )
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Instagram', 'deeper' ),
						'param_name' => 'instagram',
						'value' => '',
						'group' => esc_html__( 'URL', 'deeper' )
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Pinterest', 'deeper' ),
						'param_name' => 'pinterest',
						'value' => '',
						'group' => esc_html__( 'URL', 'deeper' )
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Behance', 'deeper' ),
						'param_name' => 'behance',
						'value' => '',
						'group' => esc_html__( 'URL', 'deeper' )
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'RSS', 'deeper' ),
						'param_name' => 'rss',
						'value' => '',
						'group' => esc_html__( 'URL', 'deeper' )
		            ),
		        )
		    );
		}
	}

	new Deeper_Social_Icon_Shortcode;
}
