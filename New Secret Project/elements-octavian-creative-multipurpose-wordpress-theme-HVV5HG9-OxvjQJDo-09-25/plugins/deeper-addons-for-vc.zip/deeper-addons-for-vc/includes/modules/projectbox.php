<?php
/**
 * Project_Box shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Project_Box_Shortcode' ) ) {

	class Deeper_Project_Box_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_projectbox', array( 'Deeper_Project_Box_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_projectbox', array( 'Deeper_Project_Box_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {

			extract( shortcode_atts( array(
				'image' => '',
			    'bg_color' => '',
			    'rounded' => '',
			    'shadow' => '',
			    // Content
			    'project_title' => '',
			    'project_title_color' => '',
			    'project_desc' => '',
			    'project_desc_color' => '',
			    'project_link_text' => '',
			    'project_link_url' => '',
			    'project_link_color' => '',
			    // Parallax Image
			    'parallax_image' => '',
			    'parallax_image_width' => '',
			    'parallax_image_top' => '',
			    'parallax_image_right' => '',
			    'parallax_image_bottom' => '',
			    'parallax_image_left' => '',
			    'parallax_x' => '',
			    'parallax_y' => '',
			    'parallax_smooth' => '30',
			    // Typography
			    'title_font_family' => '',
				'title_font_weight' => '',
				'title_font_size' => '',
				'title_line_height' => '',
				'title_letter_spacing' => '',
				'desc_font_family' => '',
				'desc_font_weight' => '',
				'desc_font_size' => '',
				'desc_line_height' => '',
				'desc_letter_spacing' => '',
				'link_font_family' => '',
				'link_font_weight' => '',
				'link_font_size' => '',
				'link_line_height' => '',
				'link_letter_spacing' => '',
			    // Spacing
			    'content_padding' => '',
			    'title_margin' => '',
			    'desc_margin' => '',

			    //Animation
			    'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',

			    'class' => '',
			), $atts ) );
			$text_html = $text_css = $cls = $css = $data = '';
			$parallax_image_html = $image_html = '';

			$url = vc_build_link( $project_link_url );
			$accent = deeper_get_accent_color();

			// General Style
			if ( $shadow ) $css .= 'box-shadow:' . $shadow . ';';
			if ( $rounded ) $css .= 'overflow:hidden;border-radius:' . $rounded . ';';
			if ( $image ) {
				$image_html = sprintf( '<img src="%1$s" alt="Image">', 
					wp_get_attachment_image_src( $image, 'full' )[0] 
				);
			}

			if ( $bg_color ) $css .= 'background-color:' . $bg_color . ';';

			// Project Title
			if ( $project_title ) {
				$title_cls = $title_css = $title_css = '';
				if ( $project_title_color ) $title_css .= 'color:' . $project_title_color . ';';
				if( $title_margin ) $title_css .= 'margin-bottom:' . intval( $title_margin ) . 'px;';

				if ( $title_font_weight ) $title_css .= 'font-weight:' . $title_font_weight . ';';
				if ( $title_font_size ) $title_css .= 'font-size:' . intval( $title_font_size ) . 'px;';
				if ( $title_line_height ) $title_css .= 'line-height:' . intval( $title_line_height ) . 'px;';
				if ( $title_letter_spacing ) $title_css .= 'letter-spacing:' . $title_letter_spacing . 'px;';
				if ( $title_font_family ) {
					deeper_enqueue_google_font( $title_font_family );
					$title_css .= 'font-family:' . $title_font_family . ';';
				}

				$text_html .= sprintf( '<h2 class="project-title" style="%3$s"><a href="%2$s">%1$s</a></h2>',
					esc_attr( $project_title ),
					esc_url( $url['url'] ),
					$title_css
				);
			}

			// Project Description
			if ( $project_desc ) {
				$desc_cls = $desc_css = '';
				if ( $project_desc_color ) $desc_css .= 'color:' . $project_desc_color . ';';
				if( $desc_margin ) $desc_css .= 'margin-bottom:' . intval( $desc_margin ) . 'px;';

				if ( $desc_font_weight ) $desc_css .= 'font-weight:' . $desc_font_weight . ';';
				if ( $desc_font_size ) $desc_css .= 'font-size:' . intval( $desc_font_size ) . 'px;';
				if ( $desc_line_height ) $desc_css .= 'line-height:' . intval( $desc_line_height ) . 'px;';
				if ( $desc_letter_spacing ) $desc_css .= 'letter-spacing:' . $desc_letter_spacing . 'px;';
				if ( $desc_font_family ) {
					deeper_enqueue_google_font( $desc_font_family );
					$desc_css .= 'font-family:' . $desc_font_family . ';';
				}

				$text_html .= sprintf( '<p class="project-desc %3$s" style="%2$s">%1$s</p>',
					esc_attr( $project_desc ),
					$desc_css,
					$desc_cls
				);
			}

			// Project Link
			if ( $url['url'] ) {
				$link_cls = $link_css = '';
				if ( $project_link_color ) $link_css .= 'color:' . $project_link_color . ';';
				if ( $link_font_weight ) $title_css .= 'font-weight:' . $link_font_weight . ';';
				if ( $link_font_size ) $title_css .= 'font-size:' . intval( $link_font_size ) . 'px;';
				if ( $link_line_height ) $title_css .= 'line-height:' . intval( $link_line_height ) . 'px;';
				if ( $link_letter_spacing ) $title_css .= 'letter-spacing:' . $link_letter_spacing . 'px;';
				if ( $link_font_family ) {
					deeper_enqueue_google_font( $link_font_family );
					$link_css .= 'font-family:' . $link_font_family . ';';
				}

				$text_html .= sprintf( '<a class="project-link" href="%2$s" style="%3$s">%1$s</a>',
					$project_link_text,
					esc_url( $url['url'] ),
					$link_css
				);
			} 

			// Parallax Image
			if ( $parallax_image ) {
				$parallax_image_css = '';
				$parallax_image_css .= 'position:absolute;';
				if ( $parallax_image_width ) $parallax_image_css .= 'width:' . $parallax_image_width . ';';
				if ( $parallax_image_top ) $parallax_image_css .= 'top:' . $parallax_image_top . ';';
				if ( $parallax_image_right ) $parallax_image_css .= 'right:' . $parallax_image_right . ';';
				if ( $parallax_image_bottom ) $parallax_image_css .= 'bottom:' . $parallax_image_bottom . ';';
				if ( $parallax_image_left ) $parallax_image_css .= 'left:' . $parallax_image_left . ';';

				$parallax_image_html = 
					sprintf( '<div class="parallax-image" style="%2$s" 
						data-parallax=\'{"x" : %3$s,"y" : %4$s, "smoothness" : %5$s}\'>
						<img src="%1$s" alt="Image"></div>',
						wp_get_attachment_image_src( $parallax_image, 'full' )[0],
						$parallax_image_css,
						$parallax_x,
						$parallax_y,
						$parallax_smooth
				);
			}

			// Text
			if ( $text_html ) {
				if ( $content_padding ) $text_css .= 'padding:' . $content_padding . ';';
			}

			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}

			return sprintf(
				'<div class="deeper-project-box %1$s" %7$s>
					<div class="project-item" style="%2$s">
						<div class="project-image">
							%6$s
							<div class="text-wrap" style="%4$s">%3$s</div>
							%5$s
						</div>
					</div>
				</div>',
				$cls,
				$css,
				$text_html,
				$text_css,
				$parallax_image_html,
				$image_html,
				$data
			);
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Project Box', 'deeper' ),
		        'description' => __( 'Display a custom project box.', 'deeper' ),
		        'base' => 'deeper_projectbox',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/portfolio.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
		        	array(
						'type'        => 'vc_link',
						'heading'     => esc_html__( 'Project Url (Required)', 'deeper' ),
						'param_name'  => 'project_link_url',
						'value'		  => '',
					),
		        	array(
						'type' => 'attach_image',
						'heading' => esc_html__('Project Image', 'deeper'),
						'param_name' => 'image',
						'value' => '',
					),
					array(
						'type'        => 'colorpicker',
						'heading'     => esc_html__( 'Background Color', 'deeper' ),
						'param_name'  => 'bg_color',
						'value'		  => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Rounded', 'deeper' ),
						'param_name'  => 'rounded',
						'value'		  => '',
						'description' => array( 'Ex: 10px', 'deeper' )
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Shadow', 'deeper' ),
						'param_name'  => 'rounded',
						'value'		  => '',
					),
					// Content
					array(
						'type'        => 'textfield',
						'holder'	  => 'div',
						'heading'     => esc_html__( 'Project Title', 'deeper' ),
						'param_name'  => 'project_title',
						'value'		  => '',
						'group' 	  => esc_html__( 'Content', 'deeper' ),
					),
					array(
						'type'        => 'colorpicker',
						'heading'     => esc_html__( 'Project Title Color', 'deeper' ),
						'param_name'  => 'project_title_color',
						'value'		  => '',
						'group' 	  => esc_html__( 'Content', 'deeper' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Project Description', 'deeper' ),
						'param_name'  => 'project_desc',
						'value'		  => '',
						'group' 	  => esc_html__( 'Content', 'deeper' ),
					),
					array(
						'type'        => 'colorpicker',
						'heading'     => esc_html__( 'Project Desciption Color', 'deeper' ),
						'param_name'  => 'project_desc_color',
						'value'		  => '',
						'group' 	  => esc_html__( 'Content', 'deeper' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Project Link Text', 'deeper' ),
						'param_name'  => 'project_link_text',
						'value'		  => '',
						'group' 	  => esc_html__( 'Content', 'deeper' ),
					),
					// Parallax Image
					array(
						'type' => 'attach_image',
						'heading' => esc_html__('Parallax Image', 'deeper'),
						'param_name' => 'parallax_image',
						'value' => '',
						'group' 	  => esc_html__( 'Parallax Image', 'deeper' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Parallax Image: Width', 'deeper' ),
						'param_name'  => 'parallax_image_width',
						'value'		  => '',
						'group' 	  => esc_html__( 'Parallax Image', 'deeper' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Parallax Image: Top', 'deeper' ),
						'param_name'  => 'parallax_image_top',
						'value'		  => '',
						'group' 	  => esc_html__( 'Parallax Image', 'deeper' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Parallax Image: Right', 'deeper' ),
						'param_name'  => 'parallax_image_right',
						'value'		  => '',
						'group' 	  => esc_html__( 'Parallax Image', 'deeper' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Parallax Image: Bottom', 'deeper' ),
						'param_name'  => 'parallax_image_bottom',
						'value'		  => '',
						'group' 	  => esc_html__( 'Parallax Image', 'deeper' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Parallax Image: Left', 'deeper' ),
						'param_name'  => 'parallax_image_left',
						'value'		  => '',
						'group' 	  => esc_html__( 'Parallax Image', 'deeper' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'X axis translation.', 'deeper' ),
						'param_name'  => 'parallax_x',
						'value'		  => '',
						'group' 	  => esc_html__( 'Parallax Image', 'deeper' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Y axis translation.', 'deeper' ),
						'param_name'  => 'parallax_y',
						'value'		  => '',
						'group' 	  => esc_html__( 'Parallax Image', 'deeper' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Smoothness: Slowdown the animation.', 'deeper' ),
						'param_name'  => 'parallax_smooth',
						'value'		  => '30',
						'group' 	  => esc_html__( 'Parallax Image', 'deeper' ),
					),
					// Typography
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Project Title', 'deeper' ),
						'param_name' => 'title_typograpy',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Project Title: Font Family', 'deeper' ),
						'param_name' => 'title_font_family',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Project Title: Font Weight', 'deeper' ),
						'param_name' => 'title_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Project Title: Font Size', 'deeper' ),
						'param_name' => 'title_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Project Title: Line Height', 'deeper' ),
						'param_name' => 'title_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Project Title: Letter Spacing', 'deeper' ),
						'param_name' => 'title_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
				  	),
				  	array(
						'type' => 'deeper_heading',
						'text' => __( 'Project Description', 'deeper' ),
						'param_name' => 'desc_typograpy',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Project Description: Font Family', 'deeper' ),
						'param_name' => 'desc_font_family',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Project Description: Font Weight', 'deeper' ),
						'param_name' => 'desc_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Project Description: Font Size', 'deeper' ),
						'param_name' => 'desc_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Project Description: Line Height', 'deeper' ),
						'param_name' => 'desc_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Project Description: Letter Spacing', 'deeper' ),
						'param_name' => 'desc_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
				  	),
				  	array(
						'type' => 'deeper_heading',
						'text' => __( 'Project Link', 'deeper' ),
						'param_name' => 'link_typograpy',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Project Link: Font Family', 'deeper' ),
						'param_name' => 'link_font_family',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Project Link: Font Weight', 'deeper' ),
						'param_name' => 'link_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Project Link: Font Size', 'deeper' ),
						'param_name' => 'link_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Project Link: Line Height', 'deeper' ),
						'param_name' => 'link_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Project Link: Letter Spacing', 'deeper' ),
						'param_name' => 'link_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
				  	),
					// Spacing
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Content Padding', 'deeper' ),
						'param_name'  => 'content_padding',
						'value'		  => '',
						'group' 	  => esc_html__( 'Spacing', 'deeper' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title Margin Bottom', 'deeper' ),
						'param_name'  => 'title_margin',
						'value'		  => '',
						'group' 	  => esc_html__( 'Spacing', 'deeper' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Description Margin Bottom', 'deeper' ),
						'param_name'  => 'desc_margin',
						'value'		  => '',
						'group' 	  => esc_html__( 'Spacing', 'deeper' ),
					),
					// Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
					// Extra Class
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra Class', 'deeper' ),
						'param_name'  => 'class',
						'value'		  => '',
					),

		        )
		    );
		}
	}

	new Deeper_Project_Box_Shortcode;
}
