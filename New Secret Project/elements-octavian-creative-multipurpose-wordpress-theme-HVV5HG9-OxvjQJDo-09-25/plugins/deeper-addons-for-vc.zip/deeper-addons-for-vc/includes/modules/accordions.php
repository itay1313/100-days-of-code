<?php
/**
 * Accordions shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Accordions_Shortcode' ) ) {

	class Deeper_Accordions_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_accordions', array( 'Deeper_Accordions_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_accordions', array( 'Deeper_Accordions_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {		

			extract( shortcode_atts( array(
				'style'					=> 'style-1',
			    'accordion_item' 		=> '',
			    //Animation
			    'animation' 			=> '',
				'animation_effect' 		=> 'fadeInUp',
				'animation_duration' 	=> '0.75s',
				'animation_delay' 		=> '0.3s',
				//Extra Class
				'class' 				=> '',
			), $atts ) );
			// Init
			$items_html = '';
			$cls = $data = '';

			$cls = $style;
			if ( $class ) $cls .= ' ' . $class;
			$accordion_item = vc_param_group_parse_atts( $atts['accordion_item'] );

			foreach ( $accordion_item as $key=>$item ) {
				$active = '';
				$heading = $desc = '';

				if ( $key == 0 ) $active = ' active';
				if ( isset( $item['heading'] ) ) $heading = $item['heading'];
				if ( isset( $item['desc'] ) ) $desc = $item['desc'];

				if ( $heading || $desc )
					$items_html .= 
						sprintf( '<div class="item %3$s"><div class="heading"><h6>%1$s</h6><span class="accordions-arrow"></span></div><div class="content">%2$s</div></div>',
						esc_html( $heading ),
						esc_html( $desc ),
						esc_html ( $active )
						);
			}

			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}

			return sprintf( '<div class="deeper-accordions %2$s" %3$s>%1$s</div>', 
				$items_html,
				$cls,
				$data );
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Accordions', 'deeper' ),
		        'description' => __( 'Accordions.', 'deeper' ),
		        'base' => 'accordions',
				'weight'	=>	180,
		        'icon' => plugins_url( '../../assets/icon/accordion.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
		        	array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'deeper' ),
						'param_name' => 'style',
						'value'      => array(
							'Style 1' => 'style-1',
							'Style 2' => 'style-2',
						),
						'std'		=> 'style-1',
					),
			        array(
						'type' => 'param_group',
						'heading' => esc_html__( 'Accordion Item', 'deeper' ),
						'param_name' => 'accordion_item',
						'value' => '',
						'group' => esc_html__( 'Content', 'deeper' ),
				        'params' => array(
			                array(
			                    'type' => 'textfield',
			                    'heading' => esc_html__( 'Heading', 'deeper' ),
			                    'param_name' => 'heading',
			                    'value' => '',
			                ),
			                array(
			                    'type' => 'textfield',
			                    'heading' => esc_html__( 'Description', 'deeper' ),
			                    'param_name' => 'desc',
			                    'value' => '',
			                ),			            				            
			            ) 
				    ),
			        // Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            // Extra Class
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Extra Class', 'deeper'),
						'param_name' => 'class',
						'value' => '',
		            ),
		        )
			);
		}
	}
	new Deeper_Accordions_Shortcode;
}

