<?php
/**
 * Parallax_Box shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_deeper_parallaxbox extends WPBakeryShortCodesContainer {}
}

if ( ! class_exists( 'Deeper_Parallax_Box_Shortcode' ) ) {

	class Deeper_Parallax_Box_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_parallaxbox', array( 'Deeper_Parallax_Box_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_parallaxbox', array( 'Deeper_Parallax_Box_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			extract( shortcode_atts( array(
				'stretch' => '',
				'offset_left' => '-10%',
				'offset_right' => '-10%',
				'class' => '',
			), $atts ) );
			$cls = '';

			if ( $class ) $cls .= $class . ' ';
			if ( $stretch == 'stretch_left' || $stretch == 'stretch_right' ) {
				$cls .= ' stretch ctb-'. rand();
				$data = '';
				$config = array();

				if ( $stretch == 'stretch_left' && !empty( $offset_left ) ) $config['stretchLeft'] = $offset_left;
				if ( $stretch == 'stretch_right' && !empty( $offset_right ) ) $config['stretchRight'] = $offset_right;

				if ( $config )
					$data = 'data-config=\'' . json_encode( $config ) . '\'';

				return sprintf(
				'<div class="deeper-fancy-image %2$s" %3$s><div class="deeper-parallax-box"><div class="parallax-wrap">%1$s</div></div></div>',
					do_shortcode( $content ),
					$cls,
					$data
				);
			}

			return sprintf(
				'<div class="deeper-parallax-box %2$s"><div class="parallax-wrap">%1$s</div></div>',
				do_shortcode( $content ),
				$cls
			);
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Parallax Box', 'deeper' ),
		        'description' => __( 'Parallax Box.', 'deeper' ),
		        'base' => 'parallaxbox',
				'weight'	=>	180,
		        'icon' => plugins_url( '../../assets/icon/parallaxbox.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'as_parent' => array( 'only' => 'deeper_parallaxitem' ),
				'controls' => 'full',
				'show_settings_on_create' => false,
				'category' => esc_html__('Deeper Addons', 'deeper'),
				'js_view' => 'VcColumnView',
				'params' => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Image Stretch', 'deeper' ),
						'param_name' => 'stretch',
						'value'      => array(
							'No Stretch' => '',
							'Stretch To Right' => 'stretch_right',
							'Stretch To Left' => 'stretch_left',
						),
						'std'		=> '',
						'group' => esc_html__( 'Stretch', 'deeper' ),
						'dependency' => array( 'element' => 'effect', 'value' => 'reveal' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Offset Left', 'deeper'),
						'param_name' => 'offset_left',
						'value' => '-10%',
						'group' => esc_html__( 'Stretch', 'deeper' ),
						'dependency' => array( 'element' => 'stretch', 'value' => 'stretch_left' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Offset Right', 'deeper'),
						'param_name' => 'offset_right',
						'value' => '-10%',
						'group' => esc_html__( 'Stretch', 'deeper' ),
						'dependency' => array( 'element' => 'stretch', 'value' => 'stretch_right' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Extra Class', 'deeper'),
						'param_name' => 'class',
						'value' => '',
			        ),
				)
		    );
		}
	}
}

new Deeper_Parallax_Box_Shortcode;