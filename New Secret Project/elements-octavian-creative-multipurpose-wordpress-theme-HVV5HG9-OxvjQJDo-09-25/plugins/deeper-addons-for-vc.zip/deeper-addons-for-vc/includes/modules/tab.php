<?php
/**
 * Tab shortcode for Visual Composer
 *
 * @package Deeper Addons
 */
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_deeper_tab extends WPBakeryShortCodesContainer {}
}

if ( ! class_exists( 'Deeper_Tab_Shortcode' ) ) {

	class Deeper_Tab_Shortcode {
		// Constructor
		public function __construct() {

			// Add shortcode
			add_shortcode( 'deeper_tab', array( 'Deeper_Tab_Shortcode', 'output' ) );
			
			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_tab', array( 'Deeper_Tab_Shortcode', 'map' ) );
			}	
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			extract(shortcode_atts(array(
	            'tab_title' => 'Title',
	            'tab_tag' => '',
	            'icon_show' => 'font_icon',
	            'icon_type' => '',
	            'icon' => '',
	            'icon_font_size' => '',
	            'img_icon' => '',
	            'img_icon_hover' => '',
	            'img_icon_width' => '',
	            'img_icon_height' => ''
	        ), $atts));

	        $icon_html = $icon_css = '';

	        if ( $icon_show == 'font_icon' && $icon_type ) {
	            if ( isset( $atts["icon_{$icon_type}"] ) )
	                $icon = $atts["icon_{$icon_type}"];
	            vc_icon_element_fonts_enqueue( $icon_type );

	            if ( $icon_font_size ) $icon_css .= 'font-size:'. intval( $icon_font_size ) .'px;';

	            $icon_html = '<span class="icon" style="'. $icon_css .'"><i class="'. $icon .'"></i></span>';
	        }

	        if ( $icon_show == 'image_icon' ) {
	            $origin_img = $hover_img = $img_data = '';

	            if ( $img_icon ) {
	                $origin_img = wp_get_attachment_image_src( $img_icon, 'full' )[0];
	                $img_data .= 'data-origin-src='. $origin_img;
	            }

	            if ( $img_icon_hover ) {
	                $hover_img = wp_get_attachment_image_src( $img_icon_hover, 'full' )[0];
	                $img_data .= ' data-hover-src='. $hover_img;
	            }

	            if ( $origin_img )
	                $icon_html = '<img class="image-icon" src="'. $origin_img .'" '. $img_data .' width="'. $img_icon_width .'" height="'. $img_icon_height .'" alt="Image" />';
	        }

	        $tag_html = '';
	        if ( $tab_tag ) $tag_html .= sprintf( '<span class="tag">%1$s</span>', $tab_tag );

	        return sprintf( 
	        	'<div class="tab-content">
                	<div class="item-title"><a class="anchor-link">%1$s<span class="title">%2$s</span>%4$s</a></div>
     	    		<div class="item-content">%3$s</div>
     	    	</div>',
     	    	$icon_html,
     	    	$tab_title,
     	    	do_shortcode( $content ),
     	    	$tag_html
	        	);  				
		}	

		// Map shortcode to VC
		public static function map() {
		    return array(
	        	"name" => esc_html__("Child Tab", 'deeper'),
				'base' => 'tab',
				'weight'	=>	180,
				'icon' => plugins_url( '../../assets/icon/tabs.png', __FILE__ ),
				'as_child' => array('only' => 'deeper_tabs'),
				'as_parent' => array('except' => 'deeper_tabs', 'deeper_tab'),
				'controls' => 'full',
				'show_settings_on_create' => true,
				'category' => esc_html__('Deeper Addons', 'deeper'),
				'js_view' => 'VcColumnView',
				'params' => array_merge(
					array(
						array(
							'type' => 'textfield',
							'holder' => 'div',
							'admin_label' => true,
							'heading' => esc_html__( 'Tab Title', 'deeper' ),
							'param_name' => 'tab_title',
		                    'std'       => 'Title',
						),
						array(
							'type' => 'textfield',
							'heading' => esc_html__( 'Tab Tag', 'deeper' ),
							'param_name' => 'tab_tag',
		                    'std'       => '',
						),
						array(
							'type'        => 'dropdown',
							'heading'     => esc_html__( 'Icon Type', 'deeper' ),
							'param_name'  => 'icon_show',
							'value'       => array(
								'Font Icon' => 'font_icon',
								'Image Icon' => 'image_icon',
							),
							'std'		=> 'font_icon',
						),
						// Image Icon
						array(
							'heading'     => esc_html__( 'Custom Image', 'deeper' ),
							'value'       => '',
							'type'        => 'attach_image',
							'param_name'  => 'img_icon',
							'dependency' => array( 'element' => 'icon_show', 'value' => array( 'image_icon' ) ),
							'group' => esc_html__( 'Image', 'deeper' ),
						),
						array(
							'heading'     => esc_html__( 'Custom Image on Hover', 'deeper' ),
							'value'       => '',
							'type'        => 'attach_image',
							'param_name'  => 'img_icon_hover',
							'dependency' => array( 'element' => 'icon_show', 'value' => array( 'image_icon' ) ),
							'group' => esc_html__( 'Image', 'deeper' ),
						),
						array(
							'heading'     => esc_html__( 'Image Width', 'deeper' ),
							'value'       => '',
							'type'        => 'textfield',
							'param_name'  => 'img_icon_width',
							'dependency' => array( 'element' => 'icon_show', 'value' => array( 'image_icon' ) ),
							'group' => esc_html__( 'Image', 'deeper' ),
						),
						array(
							'heading'     => esc_html__( 'Image Height', 'deeper' ),
							'value'       => '',
							'type'        => 'textfield',
							'param_name'  => 'img_icon_height',
							'dependency' => array( 'element' => 'icon_show', 'value' => array( 'image_icon' ) ),
							'group' => esc_html__( 'Image', 'deeper' ),
						),
						// Font Icon
						array(
							'type' => 'dropdown',
							'heading' => esc_html__( 'Icon library', 'deeper' ),
							'param_name' => 'icon_type',
							'description' => esc_html__( 'Select icon library.', 'deeper' ),
							'value' => array(
								'' => '',
								esc_html__( 'Elegant Icons', 'deeper' ) => 'extraicon',
								esc_html__( 'Basic UI Icons', 'deeper' ) => 'extraicon2',
								esc_html__( 'FontAwesome', 'deeper' ) => 'fontawesome',
								esc_html__( 'Open Iconic', 'deeper' ) => 'openiconic',
								esc_html__( 'Typicons', 'deeper' ) => 'typicons',
								esc_html__( 'Entypo', 'deeper' ) => 'entypo',
								esc_html__( 'Linecons', 'deeper' ) => 'linecons',
							),
							'group' => esc_html__( 'Icon', 'deeper' ),
							'dependency' => array( 'element' => 'icon_show', 'value' => array( 'font_icon' ) ),
						),
						array(
						    'type' => 'iconpicker',
						    'heading' => esc_html__( 'Icon', 'deeper' ),
						    'param_name' => 'icon_extraicon',
						    'settings' => array(
						        'emptyIcon' => true,
						        'type' => 'extraicon',
						        'iconsPerPage' => 200,
						    ),
						    'dependency' => array(
						        'element' => 'icon_type',
						        'value' => 'extraicon',
						    ),
						    'group' => esc_html__( 'Icon', 'deeper' ),
						),
						array(
						    'type' => 'iconpicker',
						    'heading' => esc_html__( 'Icon', 'deeper' ),
						    'param_name' => 'icon_extraicon2',
						    'settings' => array(
						        'emptyIcon' => true,
						        'type' => 'extraicon2',
						        'iconsPerPage' => 200,
						    ),
						    'dependency' => array(
						        'element' => 'icon_type',
						        'value' => 'extraicon2',
						    ),
						    'group' => esc_html__( 'Icon', 'deeper' ),
						),
						array(
							'type' => 'iconpicker',
							'heading' => esc_html__( 'Icon', 'deeper' ),
							'param_name' => 'icon',
							'settings' => array(
								'emptyIcon' => true,
								'iconsPerPage' => 200,
							),
							'dependency' => array(
								'element' => 'icon_type',
								'value' => 'fontawesome',
							),
							'group' => esc_html__( 'Icon', 'deeper' ),
						),
						array(
							'type' => 'iconpicker',
							'heading' => esc_html__( 'Icon', 'deeper' ),
							'param_name' => 'icon_openiconic',
							'settings' => array(
								'emptyIcon' => true,
								'type' => 'openiconic',
								'iconsPerPage' => 200,
							),
							'dependency' => array(
								'element' => 'icon_type',
								'value' => 'openiconic',
							),
							'group' => esc_html__( 'Icon', 'deeper' ),
						),
						array(
							'type' => 'iconpicker',
							'heading' => esc_html__( 'Icon', 'deeper' ),
							'param_name' => 'icon_typicons',
							'settings' => array(
								'emptyIcon' => true,
								'type' => 'typicons',
								'iconsPerPage' => 200,
							),
							'dependency' => array(
								'element' => 'icon_type',
								'value' => 'typicons',
							),
							'group' => esc_html__( 'Icon', 'deeper' ),
						),
						array(
							'type' => 'iconpicker',
							'heading' => esc_html__( 'Icon', 'deeper' ),
							'param_name' => 'icon_entypo',
							'settings' => array(
								'emptyIcon' => true,
								'type' => 'entypo',
								'iconsPerPage' => 300,
							),
							'dependency' => array(
								'element' => 'icon_type',
								'value' => 'entypo',
							),
							'group' => esc_html__( 'Icon', 'deeper' ),
						),
						array(
							'type' => 'iconpicker',
							'heading' => esc_html__( 'Icon', 'deeper' ),
							'param_name' => 'icon_linecons',
							'settings' => array(
								'emptyIcon' => true,
								'type' => 'linecons',
								'iconsPerPage' => 200,
							),
							'dependency' => array(
								'element' => 'icon_type',
								'value' => 'linecons',
							),
							'group' => esc_html__( 'Icon', 'deeper' ),
						),
				        array(
							'type' => 'textfield',
							'heading' => esc_html__('Icon: Font Size', 'deeper'),
							'param_name' => 'icon_font_size',
							'value' => '',
							'group' => esc_html__( 'Icon', 'deeper' ),
							'dependency' => array( 'element' => 'icon_show', 'value' => array( 'font_icon' ) ),
				        ),
				    )
				)
		    );
		}
	}
}

new Deeper_Tab_Shortcode;