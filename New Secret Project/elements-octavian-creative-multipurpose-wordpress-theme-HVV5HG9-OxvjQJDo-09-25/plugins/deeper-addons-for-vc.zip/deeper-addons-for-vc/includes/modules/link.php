<?php
/**
 * Link shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Link_Shortcode' ) ) {

	class Deeper_Link_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_link', array( 'Deeper_Link_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_link', array( 'Deeper_Link_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {

			extract( shortcode_atts( array(
				// General
				'link_align'			=> '',
				'link_style'			=> 'style-1',
				'link_text' 			=> 'Read More',
				'link_url' 				=> '',
				'link_margin' 			=> '',
				'link_padding' 			=> '',
				'link_extra'			=> '',

				'link_color'			=> '',
				'link_line_color'		=> '',
				'link_icon_color'		=> '',

				// Typography
				'link_font_family' 		=> '',
				'link_font_weight' 		=> '',
				'link_font_size' 		=> '',
				'link_line_height' 		=> '',
				'link_letter_spacing' 	=> '',
				// Hover
				'link_hover_color'			=> '',
				'link_hover_line_color'		=> '',
				'link_hover_icon_color'		=> '',
				'link_parent_hover'			=> '',
				// Animation
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );
			
			// Init
			$content = wpb_js_remove_wpautop( $content, true );
			$config = array();
			$accent = deeper_get_accent_color();
			$cls = $css = $data = $wrap_cls = $wrap_css =  '';
			$url_atts = '';

			if ( $link_url && $link_text ) {
				// Style + Size + Id + align
				$cls = $link_style;

				if ( $link_extra ) $wrap_cls .= ' ' . $link_extra;
				if ( $link_margin ) $wrap_css .= 'margin:' . $link_margin . ';';
				if ( $link_padding ) $wrap_css .= 'padding:' . $link_padding . ';';

				// URL
				if ( $link_url ) {
					$url = vc_build_link( $link_url );
					if ( $url['url'] ) $url_atts .= 'href=' . esc_url( $url['url'] );
					if ( $url['target'] ) $url_atts .= ' target=' . esc_attr( $url['target'] );
					if ( $url['title'] ) $url_atts .= ' title="' . sanitize_html_class( $url['title'] ) . '"';
				}


				// Typography
				if ( $link_font_weight ) $css .= 'font-weight:' . $link_font_weight . ';';
				if ( $link_font_size ) $css .= 'font-size:' . intval( $link_font_size ) . 'px;';
				if ( $link_line_height ) $css .= 'line-height:' . intval( $link_line_height ) . 'px;';
				if ( $link_letter_spacing ) $css .= 'letter-spacing:' . $link_letter_spacing . 'px;';
				if ( $link_font_family ) {
					deeper_enqueue_google_font( $link_font_family );
					$css .= 'font-family:' . $link_font_family . ';';
				}

				// Color - if link has color, line and icon has same color with link by default
				if ( $link_color == $accent ) {
					$cls .= ' accent-color';
				} elseif ( $link_color ) {
					$config['color'] = $link_color;
				} 

				if ( $link_line_color ) {
					$config['lineColor'] = $link_line_color;
				} else {
					if ( $link_color ) $config['lineColor'] = $link_color;
				}

				if ( $link_icon_color ) {
					$config['iconColor'] = $link_icon_color;
				} else {
					if ( $link_color ) $config['iconColor'] = $link_color;
				}

				// Hover
				if ( $link_hover_color ) $config['hoverColor'] = $link_hover_color;

				if ( $link_hover_line_color ) {
					$config['hoverLineColor'] = $link_hover_line_color;
				} else {
					if ( $link_hover_color ) $config['hoverLineColor'] = $link_hover_color;
				}

				if ( $link_hover_icon_color ) {
					$config['hoverIconColor'] = $link_hover_icon_color;
				} else {
					if ( $link_hover_color ) $config['hoverIconColor'] = $link_hover_color;
				}

				if ( $link_parent_hover ) $config['parentHover'] = $link_parent_hover;

				if ( $config ) {
					$data = 'data-config=\'' . json_encode( $config ) . '\'';
					$cls .= ' btn-' . rand();
				}

				//Animation
				if ( $animation ) {
				    $anim_cls = ' wow '. $animation_effect;
				    $anim_data = ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';

				    return sprintf( 
						'<div class="%7$s %9$s" %8$s>
							<div class="url-wrap %5$s" style="%10$s">
								<a class="deeper-link %1$s" style="%2$s" %4$s %6$s>
									<span class="text">%3$s</span>
									<span class="line"></span>
									<span class="icon fa fa-chevron-right"></span>
								</a>
							</div>
						</div>',
						$cls,
						$css,
						esc_html( $link_text ),
						esc_attr( $url_atts ),
						$link_align,
						$data,
						$anim_cls,
						$anim_data,
						$wrap_cls,
						$wrap_css
						);
				} else {
					$wrap_cls .= ' ' . $link_align;
					return sprintf( 
						'<div class="url-wrap %5$s" style="%7$s">
							<a class="deeper-link %1$s" style="%2$s" %4$s %6$s>
								<span class="text">%3$s</span>
								<span class="line"></span>
								<span class="icon fa fa-chevron-right"></span>
							</a>
						</div>',
						$cls,
						$css,
						esc_html( $link_text ),
						esc_attr( $url_atts ),
						$wrap_cls,
						$data,
						$wrap_css
					);
				}
			}
		}

		// Map shortcode to VC
		public static function map() {
			return array(
				'name' => __( 'Link', 'deeper' ),
		        'description' => __( 'Displays custom link.', 'deeper' ),
				'base' => 'deeper_link',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/links.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
				'params' => array(	
					array(
						'type' => 'dropdown',
						'heading' => __( 'Alignment', 'deeper' ),
						'param_name' => 'link_align',
						'value' => array(
							'Left' 			=> '',
							'Center' 		=> 'align-center',
							'Right' 		=> 'align-right',
						),
						'std'		=> ''
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Link Style', 'deeper' ),
						'param_name' => 'link_style',
						'value' => array(
							'Style 1' 		=> 'style-1',
							'Style 2' 		=> 'style-2',
							'Style 3' 		=> 'style-3',
						),
						'std'		=> 'style-1'
					),
			        array(
						'type' => 'textfield',
						'heading' => __('Text (Required)', 'deeper'),
						'param_name' => 'link_text',
						'value' => 'Read More',
			        ),
			        array(
						'type' => 'vc_link',
						'heading' => __( 'URL (Required):', 'deeper' ),
						'param_name' => 'link_url',
						'value' => '',
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Link Color', 'deeper'),
						'param_name' => 'link_color',
						'value' => '',
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Line Color', 'deeper'),
						'param_name' => 'link_line_color',
						'value' => '',
						'dependency'	=> array( 'element' => 'link_style', 'value' => array( 'style-1', 'style-2' ) ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Icon Color', 'deeper'),
						'param_name' => 'link_icon_color',
						'value' => '',
						'dependency'	=> array( 'element' => 'link_style', 'value' => 'style-3'),
			        ),
			        // Spacing 
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Spacing', 'deeper' ),
						'param_name' => 'deeper',
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Link: Margin', 'deeper' ),
						'param_name' => 'link_margin',
						'value' => '',
						'description'	=> __( 'Top Right Bottom Left. Example: 10px 0px 0px 0px', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Link: Padding', 'deeper' ),
						'param_name' => 'link_padding',
						'value' => '',
						'description'	=> __( 'Top Right Bottom Left. Example: 10px 0px 0px 0px', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'link_extra',
						'value' => '',
			        ),
			        // Typography
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Link', 'deeper' ),
						'param_name' => 'link_typograpy',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Link: Font Family', 'deeper' ),
						'param_name' => 'link_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Link: Font Weight', 'deeper' ),
						'param_name' => 'link_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Link: Font Size', 'deeper' ),
						'param_name' => 'link_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Link: Line Height', 'deeper' ),
						'param_name' => 'link_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Link: Letter Spacing', 'deeper' ),
						'param_name' => 'link_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
				  	// Hover
				  	array(
						'type' => 'colorpicker',
						'heading' => __('Hover: Link Color', 'deeper'),
						'param_name' => 'link_hover_color',
						'group' => __( 'Hover', 'deeper' ),
						'value' => '',
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Hover: Line Color', 'deeper'),
						'param_name' => 'link_hover_line_color',
						'group' => __( 'Hover', 'deeper' ),
						'value' => '',
						'dependency'	=> array( 'element' => 'link_style', 'value' => array( 'style-1', 'style-2' ) ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Hover: Icon Color', 'deeper'),
						'param_name' => 'link_hover_icon_color',
						'group' => __( 'Hover', 'deeper' ),
						'value' => '',
						'dependency'	=> array( 'element' => 'link_style', 'value' => 'style-3'),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Parent Hover (Optional)', 'deeper' ),
						'param_name' => 'link_parent_hover',
						'group' => __( 'Hover', 'deeper' ),
						'value' => '',
						'description'	=> __( 'Enter the name of the parent class that the effect occurs when mouse over it. Example: deeper-content-box', 'deeper' ),
			        ),
			        // Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
				)
			);
		}
	}

	new Deeper_Link_Shortcode;
}