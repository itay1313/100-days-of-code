<?php
/**
 * Portfolio_Carousel shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Portfolio_Carousel_Shortcode' ) ) {

	class Deeper_Portfolio_Carousel_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_portfoliocarousel', array( 'Deeper_Portfolio_Carousel_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_portfoliocarousel', array( 'Deeper_Portfolio_Carousel_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$data = '';
			$config = array();

			extract( shortcode_atts( array(
				'style'			=> 'style-1',
				'btn_text'		=> '',
				'items'			=> '6',
				'image_crop'	=> 'full',
				'cat_slug' => '',
				'exclude_cat_slug' => '',
				'gap'			=> '0',
				'autoplay' => 'false',
				'center' => 'left',
				'autoplay_speed' => 3000,
			    'fullaside' => 'false',
			    'loop' => '',
			    'groupcell' => 'false',
			    'full_screen' => '',
				
				'column' => '3',
				'column2' => '2',
				'column3' => '2',
				'column4' => '1',
				
				'project_link_text' => '',
				'class'	=> '',
				// Arrows
				'show_arrows' => '',
				'arrowsvg' => 'svg1',
				'arrows_position' => 'middle',
				'arrows_size' => 'arrows-medium',
				'arrows_offset' => 'arrow-offset-0',
				// Bullets
				'show_bullets' => '',
				'bullets_offset' => 'bullet-offset-0',
				'bullets_pos' => 'bullet-center',
				'bullets_style' => '',
				//Animation
			    'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );

			$args = array(
			    'post_type' => 'project',
			    'posts_per_page' => intval( $items )
			);

			if ( ! empty( $cat_slug ) ) {
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'project_category',
						'field'    => 'slug',
						'terms'    => $cat_slug
					),
				);
			}

			if ( ! empty( $exclude_cat_slug ) ) {
				$args['tax_query'] = array(
				    array(
				        'taxonomy' => 'project_category',
				        'field' => 'slug',
				        'terms' => $exclude_cat_slug,
				        'operator' => 'NOT IN'
				    ),
				);
			}

			$query = new WP_Query( $args );
			if ( ! $query->have_posts() ) { esc_html_e( 'Project item not found!', 'deeper' ); return; }

			$cls = $style . ' column-' . $column . ' column2-' . $column2 . ' column3-' . $column3 . ' column4-' . $column4 .  ' gap-' . $gap;
			if ( $class ) $cls .= ' ' . $class;
			if ( $full_screen ) $cls .= ' ' . $full_screen;
			if ( $style == 'style-2' ) $cls .= ' has-status';

			$config['cellAlign'] = $center;
			$config['autoPlay'] = $autoplay == 'true' ? abs( (int) $autoplay_speed ) : false;
			$config['fullAside'] = $fullaside == 'true' ? true : false;
			$config['wrapAround'] = $loop == 'true' ? true : false;
			$config['groupCells'] = $groupcell == 'true' ? true : false;
			
			// Arrows
			if ( $show_arrows ) {
				$cls .= ' has-arrows arrow-' . $arrows_position . ' ' . $arrows_offset . ' ' . $arrows_size;
				$config['prevNextButtons'] = true;
				$config['arrowShapeStyle'] = $arrowsvg;
			}

			// Bullets
			if ( $show_bullets ) {
				$cls .= ' has-bullets ' . $bullets_style . ' ' . $bullets_offset . ' ' . $bullets_pos;
				$config['pageDots'] = true;
			}

			if ( $config )
				$data = 'data-config=\'' . json_encode( $config ) . '\'';

			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}

			wp_enqueue_script( 'flickity' );
			ob_start(); ?>

			<div class="portfolio-carousel">
				<div class="deeper-carousel-box project-carousel <?php echo $cls; ?>" <?php echo $data; ?>>
					<?php if ( $query->have_posts() ) : ?>
						<?php while ( $query->have_posts() ) : $query->the_post(); ?>
							<?php
							switch ( $style ) {
								case 'style-2': ?>
									<div class="project-item">
										<div class="text-wrap">
											<?php
											$terms = get_the_terms( get_the_ID(), 'project_category' );

											if ( $terms )
												echo '<div class="project-cat">' . $terms[0]->name . '</div>';

											if ( octavian_metabox( 'title' ) ) 
												echo '<h2 class="project-title"><a href="' . esc_url( get_the_permalink() ) . '">' . octavian_metabox( 'title' ) .'</a></h2>'; 

											if ( octavian_metabox( 'project_desc' ) ) 
												echo '<div class="project-desc">' . octavian_metabox( 'project_desc' ) .'</div>';

											if ( $project_link_text ) 
												echo '<a class="project-link" href="' . esc_url( get_the_permalink() ) . '">' . 
													esc_attr( $project_link_text) . '</a>';
											?> 
										</div>

										<div class="project-image">
											<?php echo get_the_post_thumbnail( get_the_ID(), $image_crop ); ?>	
										</div><!-- /.project-image -->
									</div><!-- /.project-item -->

									<?php
									break;

								case 'style-3': ?>
									<div class="project-item">
										<div class="project-image">
											<?php echo get_the_post_thumbnail( get_the_ID(), $image_crop ); ?>	

											<div class="text-wrap">
											<?php
												$terms = get_the_terms( get_the_ID(), 'project_category' );

												if ( octavian_metabox( 'title' ) ) 
														echo '<h2 class="project-title"><a href="' . esc_url( get_the_permalink() ) . '">' . octavian_metabox( 'title' ) .'</a></h2>'; 

												if ( $terms )
													echo '<div class="project-cat">' . $terms[0]->name . '</div>';

												?> 
											</div>
										</div><!-- /.project-image -->
									</div><!-- /.project-item -->

									<?php
									break;

								case 'style-4': ?>
									<div class="project-item">
										<div class="project-image">
											<?php echo get_the_post_thumbnail( get_the_ID(), $image_crop ); ?>	

											<?php if ( $btn_text ) echo '<a class="viewmore-btn" href="' . esc_url ( get_the_permalink( get_the_ID() ) ) . '">' . esc_attr( $btn_text ) . '</a>'; ?>

										</div><!-- /.project-image -->
										
										<div class="text-wrap">
											<?php
											if ( octavian_metabox( 'title' ) ) 
												echo '<h2 class="project-title"><a href="' . esc_url( get_the_permalink() ) . '">' . octavian_metabox( 'title' ) .'</a></h2>'; 

											?> 
										</div>
									</div><!-- /.project-item -->

									<?php
									break;
								
								default: ?>
									<div class="project-item">
										<div class="project-image">
											<?php echo get_the_post_thumbnail( get_the_ID(), $image_crop ); ?>	

											<?php
											if ( octavian_metabox( 'title' ) || octavian_metabox( 'project_desc' ) ) { ?>
												<div class="text-wrap">
													<?php
													if ( octavian_metabox( 'title' ) ) 
														echo '<h2 class="project-title"><a href="' . esc_url( get_the_permalink() ) . '">' . octavian_metabox( 'title' ) .'</a></h2>'; 

													if ( octavian_metabox( 'project_desc' ) ) 
														echo '<div class="project-desc">' . octavian_metabox( 'project_desc' ) .'</div>';
													?> 
												</div>
											<?php } ?>
										</div>
									</div><!-- /.project-item -->

									<?php 
									break;
							}
						endwhile; ?>
					<?php endif; wp_reset_postdata(); ?>
				</div><!-- /.deeper-carousel-box -->

				<div class="status-wrap"><div class="carousel-status"></div></div>
			</div>
			<?php
			return ob_get_clean();
		}

		// Map shortcode to VC
		public static function map() {
			return array(
				'name' => esc_html__('Portfolio Carousel', 'deeper'),
				'base' => 'portfoliocarousel',
				'weight'	=>	180,
				'icon' => plugins_url( '../../assets/icon/portfolio.png', __FILE__ ),
				'category' => esc_html__('Deeper Addons', 'deeper'),
			    'params' => array(
			    	array(
						'type'       => 'dropdown',
						'heading'    => __( 'Style', 'deeper' ),
						'param_name' => 'style',
						'value'      => array(
							'Style 1' => 'style-1',
							'Style 2' => 'style-2',
							'Style 3' => 'style-3',
							'Style 4' => 'style-4',
						),
						'std'		=> 'style-1',
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__( 'View More Button Text', 'deeper' ),
						'param_name' => 'btn_text',
						'value' => '',
						'dependency' => array( 'element' => 'style', 'value' => 'style-4' ),
			        ),
			    	array(
						'type' => 'textfield',
						'heading' => esc_html__( 'Posts Per Page', 'deeper' ),
						'param_name' => 'items',
						'value' => '6',
		            ),    
		            array(
						'type'       => 'dropdown',
						'heading'    => __( 'Image Cropping', 'deeper' ),
						'param_name' => 'image_crop',
						'value'      => array(
							'Full' => 'full',
							'570 x 420' => 'deeper-std1',
							'570 x 340' => 'deeper-std2',
							'370 x 470' => 'deeper-std3',
							'370 x 430' => 'deeper-std4',
							'370 x 370' => 'deeper-std5',
							'370 x 270' => 'deeper-std6',
						),
						'std'		=> 'full',
					),        
			        array(
						'type' => 'textfield',
						'heading' => esc_html__( 'Category Slug (Optional)', 'deeper' ),
						'param_name' => 'cat_slug',
						'value' => '',
						'description'	=> esc_html__( 'Displaying posts that have this category. Using category-slug.', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__( 'Exclude Category Slug (Optional)', 'deeper' ),
						'param_name' => 'exclude_cat_slug',
						'value' => '',
						'description'	=> esc_html__( 'Exclude posts that have this category. Using category-slug.', 'deeper' ),
			        ),
		            array(
						'type'       => 'dropdown',
						'heading'    => __( 'Spacing between Items', 'deeper' ),
						'param_name' => 'gap',
						'value'      => array(
							'0px' => '0',
							'1px' => '1',
							'5px' => '5',
							'10px' => '10',
							'15px' => '15',
							'20px' => '20',
							'30px' => '30',
							'40px' => '40',
							'50px' => '50',
							'100px' => '100',
						),
						'std'		=> '0',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Auto Play?', 'deeper' ),
						'param_name' => 'autoplay',
						'value'      => array(
							'No' => 'false',
							'Yes' => 'true',
						),
						'std'		=> 'false',
					),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Auto Play Speed', 'deeper' ),
						'param_name' => 'autoplay_speed',
						'value' => '3000',
						'dependency' => array( 'element' => 'autoplay', 'value' => 'true' ),
		            ),      
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Full Aside?', 'deeper' ),
						'param_name' => 'fullaside',
						'value'      => array(
							'No' => 'false',
							'Yes' => 'true',
						),
						'std'		=> 'false',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Center Mode?', 'deeper' ),
						'param_name' => 'center',
						'value'      => array(
							'No' => 'left',
							'Yes' => 'center',
						),
						'std'		=> 'left',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Show Full Screen?', 'deeper' ),
						'param_name' => 'full_screen',
						'value'      => array(
							'Default' => '',
							'On Desktop ( > 1024px )' => 'full-screen',
							'On Tablet ( < 1024px )' => 'full-screen-xl',
							'On Mobile ( < 991px )' => 'full-screen-lg',
							'On Small Mobile ( < 776px )' => 'full-screen-md',
						),
						'std'		=> '',
						'dependency' => array( 'element' => 'center', 'value' => 'center' ),
						'description'	=> __( 'Used with center mode to show full screen when center mode and number of item is even.', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Infinity Loop?', 'deeper' ),
						'param_name' => 'loop',
						'value'      => array(
							'No' => 'false',
							'Yes' => 'true',
						),
						'std'		=> 'false',
						'description'	=> __( 'Duplicate last and first items to get loop illusion.', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Group Cell?', 'deeper' ),
						'param_name' => 'groupcell',
						'value'      => array(
							'No' => 'false',
							'Yes' => 'true',
						),
						'std'		=> 'false',
						'description'	=> __( 'Groups cells together in slides. Flicking, page dots, and previous/next buttons are mapped to group slides, not individual cells.', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Project Link Text', 'deeper' ),
						'param_name' => 'project_link_text',
						'value' => '',
						'dependency' => array( 'element' => 'style', 'value' => 'style-2' ),
		            ),
					array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'class',
						'value' => '',
		            ),
		            // Controls
		            array(
						'type' => 'deeper_heading',
						'text' => __( 'Arrows', 'deeper' ),
						'param_name' => 'deeper_heading_arrow',
						'group' => __( 'Controls', 'deeper' ),
		            ),
		            array(
						'type'       => 'dropdown',
						'heading'    => __( 'Show Arrows?', 'deeper' ),
						'param_name' => 'show_arrows',
						'group' => __( 'Controls', 'deeper' ),
						'value'      => array(
							'No' => '',
							'Yes' => 'yes',
						),
						'std'		=> '',
					),
		            array(
						'type'       => 'dropdown',
						'heading'    => __( 'Arrow Style?', 'deeper' ),
						'param_name' => 'arrowsvg',
						'value'      => array(
							'Style 1' => 'svg1',
							'Style 2' => 'svg2',
							'Style 3' => 'svg3',
						),
						'std'		=> 'svg1',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'show_arrows', 'value' => 'yes' )
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Arrows Position', 'deeper' ),
						'param_name' => 'arrows_position',
						'value'      => array(
							'Middle' => 'middle',
							'Top' => 'top',
						),
						'std'		=> 'middle',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'show_arrows', 'value' => 'yes' )
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Arrows Size', 'deeper' ),
						'param_name' => 'arrows_size',
						'value'      => array(
							'Small' => 'arrows-small',
							'Medium' => 'arrows-medium',
							'Big' => 'arrows-big',
						),
						'std'		=> 'arrows-medium',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'show_arrows', 'value' => 'yes' )
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Arrows Offset', 'deeper' ),
						'param_name' => 'arrows_offset',
						'value'      => array(
							'0px' 	=> 'arrow-offset-0',
							'10px' 	=> 'arrow-offset-10',
							'20px' 	=> 'arrow-offset-20',
							'30px' 	=> 'arrow-offset-30',
							'40px' 	=> 'arrow-offset-40',
							'50px' 	=> 'arrow-offset-50',
							'60px' 	=> 'arrow-offset-60',
							'70px' 	=> 'arrow-offset-70',
							'80px' 	=> 'arrow-offset-80',
							'90px' 	=> 'arrow-offset-90',
							'100px' 	=> 'arrow-offset-100',
						),
						'std'		=> 'arrow-offset-0',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'arrows_position', 'value' => 'top' )
					),
					array(
						'type' => 'deeper_heading',
						'text' => __( 'Bullets', 'deeper' ),
						'param_name' => 'deeper_heading_bullets',
						'group' => __( 'Controls', 'deeper' ),
		            ),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Show Bullets?', 'deeper' ),
						'param_name' => 'show_bullets',
						'group' => __( 'Controls', 'deeper' ),
						'value'      => array(
							'No' => '',
							'Yes' => 'yes',
						),
						'std'		=> '',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Bullets Style', 'deeper' ),
						'param_name' => 'bullets_style',
						'value'      => array(
							'Circle' 		=> 'bullet-style-1',
							'Line' 	=> 'bullet-style-2',
						),
						'std'		=> '',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'show_bullets', 'value' => 'yes' )
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Bullets Position', 'deeper' ),
						'param_name' => 'bullets_pos',
						'value'      => array(
							'Left' 		=> 'bullet-left',
							'Center' 	=> 'bullet-center',
							'Right' 	=> 'bullet-right',
						),
						'std'		=> 'bullet-center',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'show_bullets', 'value' => 'yes' )
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Bullets Offset', 'deeper' ),
						'param_name' => 'bullets_offset',
						'value'      => array(
							'0px' 	=> 'bullet-offset-0',
							'10px' 	=> 'bullet-offset-10',
							'20px' 	=> 'bullet-offset-20',
							'30px' 	=> 'bullet-offset-30',
							'40px' 	=> 'bullet-offset-40',
							'50px' 	=> 'bullet-offset-50',
							'60px' 	=> 'bullet-offset-60',
							'70px' 	=> 'bullet-offset-70',
							'80px' 	=> 'bullet-offset-80',
							'90px' 	=> 'bullet-offset-90',
							'100px' 	=> 'bullet-offset-100',
						),
						'std'		=> 'bullet-offset-0',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'show_bullets', 'value' => 'yes' )
					),
					// Column
					array (
						'type'       => 'dropdown',
						'heading'    => __( 'Column: Desktop ( > 1024px )', 'deeper' ),
						'param_name' => 'column',
						'value'      => array(
							'5 Columns' => '5',
							'4 Columns' => '4',
							'3 Columns' => '3',
							'2 Columns' => '2',
							'1 Columns' => '1',
						),
						'std'		=> '3',
						'group' => __( 'Columns', 'deeper' ),
					),
					array (
						'type'       => 'dropdown',
						'heading'    => __( 'Column: Tablet ( From 991px to 1024px )', 'deeper' ),
						'param_name' => 'column2',
						'value'      => array(
							'4 Columns' => '4',
							'3 Columns' => '3',
							'2 Columns' => '2',
							'1 Columns' => '1',
						),
						'std'		=> '2',
						'group' => __( 'Columns', 'deeper' ),
					),
					array (
						'type'       => 'dropdown',
						'heading'    => __( 'Column: Mobile ( From 767px to 991px )', 'deeper' ),
						'param_name' => 'column3',
						'value'      => array(
							'4 Columns' => '4',
							'3 Columns' => '3',
							'2 Columns' => '2',
							'1 Columns' => '1',
						),
						'std'		=> '2',
						'group' => __( 'Columns', 'deeper' ),
					),
					array (
						'type'       => 'dropdown',
						'heading'    => __( 'Column: Small Mobile ( < 767px )', 'deeper' ),
						'param_name' => 'column4',
						'value'      => array(
							'4 Columns' => '4',
							'3 Columns' => '3',
							'2 Columns' => '2',
							'1 Columns' => '1',
						),
						'std'		=> '1',
						'group' => __( 'Columns', 'deeper' ),
					),
					// Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
			    )
			);
		}
	}

	new Deeper_Portfolio_Carousel_Shortcode;
}



