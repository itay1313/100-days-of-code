<?php
/**
 * Subscribe shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Subscribe_Shortcode' ) ) {

	class Deeper_Subscribe_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_subscribe', array( 'Deeper_Subscribe_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_subscribe', array( 'Deeper_Subscribe_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$css = $cls = $data = '';

			extract( shortcode_atts( array(
				'style' => 'style-1',
				'class' => '',
				'alignment' => '',
				'width' => '',
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );

			$cls = $alignment . ' ' . $style;
			if ( $class ) $cls .= ' ' . $class;
			if ( $style == 'style-2' ) $cls .= ' placeholder-white';

			if ( $width ) {
				$css .= 'max-width:'. intval( $width ) .'px;';
				if ( $alignment == 'align-center' )
					$css .= 'margin-left: auto; margin-right: auto;';
			}

			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}

			return sprintf('<div class="deeper-subscribe clearfix %2$s" %3$s style="%4$s">%1$s</div>',
				do_shortcode('[mc4wp_form]'),
				$cls,
				$data,
				$css );
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Subcribe', 'deeper' ),
		        'description' => __( 'Form MailChimp.', 'deeper' ),
		        'base' => 'subscribe',
				'weight'	=>	180,
		        'icon' => plugins_url( '../../assets/icon/subscibe.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
		   //      	array(
					// 	'type'       => 'dropdown',
					// 	'heading'    => esc_html__( 'Style', 'deeper' ),
					// 	'param_name' => 'style',
					// 	'value'      => array(
					// 		'Style 1' => 'style-1',
					// 		'Style 2' => 'style-2',
					// 		'Style 3' => 'style-3',
					// 	),
					// 	'std'		=> '',
					// ),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Alignment', 'deeper' ),
						'param_name' => 'alignment',
						'value'      => array(
							'Left' => '',
							'Center' => 'align-center',
						),
						'std'		=> '',
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Max-Width', 'deeper'),
						'param_name' => 'width',
						'value' => '',
		            ),
		            // Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Extra Class', 'deeper'),
						'param_name' => 'class',
						'value' => '',
		            ),
		        )
		    );
		}
	}
}

new Deeper_Subscribe_Shortcode;