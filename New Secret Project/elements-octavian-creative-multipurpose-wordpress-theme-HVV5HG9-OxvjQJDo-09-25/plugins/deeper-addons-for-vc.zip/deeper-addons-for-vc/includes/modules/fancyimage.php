<?php
/**
 * Fancy_Image shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Fancy_Image_Shortcode' ) ) {

	class Deeper_Fancy_Image_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_fancyimage', array( 'Deeper_Fancy_Image_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_fancyimage', array( 'Deeper_Fancy_Image_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {

			$cls = $css = $cls2 = $data = $data2 = $icon_cls = $icon_css = $icon_html = $image_html = $new_tab = '';

			extract( shortcode_atts( array(
				'image' => '',
				'img_stretch' => '',
				'image_width' => '',
				'rounded' => '',
				'center_align' => '',
				'url' => '',
				'new_tab' => 'yes',

				// Video Icon
				'video_style' => 'style-1',
			    'video_size' => 'medium',
				'video_url' => '',	
				'video_text' => '',
				'video_class' => '',

			    'shadow' => '',
			    'effect' => 'simple',
			    'reveal_dir' => 'lr',
			    'bg_pos' => 'top',
				'stretch' => '',
				'offset_left' => '-22vw',
				'offset_right' => '-22vw',
				'class' => '',
			), $atts ) );

			$data = '';
			$config = array();

			if ( $class ) $cls .= ' ' . $class;

			if ( $img_stretch ) $cls .= 'img-stretch';
			if ( $stretch == 'stretch_mobi' ) $cls = 'stretch-on-mobile';

			if ( $stretch == 'stretch_left' || $stretch == 'stretch_right' ) {
				$cls2 .= ' stretch ctb-'. rand();

				if ( $stretch == 'stretch_left' && !empty( $offset_left ) ) $config['stretchLeft'] = $offset_left;
				if ( $stretch == 'stretch_right' && !empty( $offset_right ) ) $config['stretchRight'] = $offset_right;

			}

			if ( $config )
				$data = 'data-config=\'' . json_encode( $config ) . '\'';

			$icon_string = deeper_get_shortcode( 'deeper_videoicon', $atts, 'video' );

			if ( $image ) {
				$image_html = sprintf( '<img alt="image" src="%1$s" />', wp_get_attachment_image_src( $image, 'full' )[0] );

				if ( $url ) {
					$new_tab = $new_tab == 'yes' ? '_blank' : '_self';
					$image_html = sprintf( '<a target="%3$s" href="%2$s">%1$s</a>', $image_html, $url, $new_tab );
				}

				if ( $effect == 'simple' ) {
					if ( $image_width ) $css .= ' max-width:'.  intval($image_width) .'px;';
					if ( $rounded ) $css .= 'border-radius:'.  intval($rounded) .'px;overflow:hidden;';
					if ( $center_align ) $css .= 'text-align:center; margin:0 auto;';
					if ( $shadow )
					    $css .= ' box-shadow:'. $shadow . ';';
					return sprintf(
						'<div class="deeper-fancy-image simple %3$s" style="%4$s" %5$s>
							%1$s %2$s
						</div>',
						$image_html,
						do_shortcode( $icon_string ),
						$cls,
						$css,
						$data
					);
				}

				if ( $effect == 'reveal' ) {
					$cls .= ' '. $reveal_dir;
					if ( $rounded ) $css .= 'border-radius:'.  intval($rounded) .'px;overflow:hidden;';
					if ( $shadow )
					    $css .= ' box-shadow:'. $shadow . ';';

					return sprintf(
						'<div class="deeper-fancy-image reveal %3$s %6$s" %5$s %7$s data-inviewport="yes">
							<figure style="%4$s">%1$s %2$s</figure>
						</div>',
						$image_html,
						do_shortcode( $icon_string ),
						$cls,
						$css,
						$data2,
						$cls2,
						$data
					);
				}

				if ( $effect == 'background' ) {

					$data = 'data-in-viewport="true"';
					$cls .= ' bg-'. $bg_pos;

					return sprintf(
						'<div class="deeper-fancy-img %3$s" %5$s %6$s>
							<div class="deeper-fancy-img-inner">
								<span class="deeper-fancy-img-bg"></span>

								<div class="deeper-fancy-img-holder" style="%4$s">
									%1$s %2$s
								</div>
							</div>
						</div>',
						$image_html,
						$icon_html,
						$cls,
						$css,
						$data,
						$data2
					);
				}
			}
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Fancy Image', 'deeper' ),
		        'description' => __( 'Displaying a simple image with animation.', 'deeper' ),
		        'base' => 'fancyimage',
				'weight'	=>	180,
		        'icon' => plugins_url( '../../assets/icon/imagebox.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params'      => array(
					array(
						'type' => 'attach_image',
						'heading' => esc_html__('Image', 'deeper'),
						'param_name' => 'image',
						'value' => '',
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Image Stretch?', 'deeper' ),
						'param_name' => 'img_stretch',
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
		            // Effect
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Effect', 'deeper' ),
						'param_name' => 'effect',
						'value'      => array(
							'No Effect' => 'simple',
							'Reveal' => 'reveal',
							'Background' => 'background',
						),
						'std'		=> 'simple',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Reveal Direction', 'deeper' ),
						'param_name' => 'reveal_dir',
						'value'      => array(
							'Left - Right' => 'lr',
							'Right - Left' => 'rl',
						),
						'std'		=> 'lr',
						'dependency' => array( 'element' => 'effect', 'value' => 'reveal' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Background Position', 'deeper' ),
						'param_name' => 'bg_pos',
						'value'      => array(
							'Top' => 'top',
							'Right' => 'right',
							'Bottom' => 'bottom',
							'Left' => 'left',
						),
						'std'		=> 'top',
						'dependency' => array( 'element' => 'effect', 'value' => 'background' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Image Width (Optional)', 'deeper'),
						'param_name' => 'image_width',
						'value' => '',
						'dependency' => array( 'element' => 'effect', 'value' => 'simple' ),
			        ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Image Rounded', 'deeper'),
						'param_name' => 'rounded',
						'value' => '',
						'description'	=> esc_html__('ex: 10px', 'deeper'),
						'dependency' => array( 'element' => 'effect', 'value' => array('simple','reveal') ),
		            ),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Center Alignment', 'deeper' ),
						'param_name' => 'center_align',
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
						'dependency' => array( 'element' => 'effect', 'value' => 'simple' ),
					),
			        // Hyperlink
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Link (URL):', 'deeper'),
						'param_name' => 'url',
						'value' => '',
		            ),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__( 'Open Link in a new Tab', 'deeper' ),
						'param_name' => 'new_tab',
						'value' => array(
							'Yes' => 'yes',
							'No' => 'no',
						),
						'std'		=> 'yes',
					),
					// Box Shadow
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Box Shadow', 'deeper'),
						'param_name' => 'shadow',
						'value' => '',
						'group' => esc_html__( 'Box Shadow', 'deeper' ),
						'dependency' => array( 'element' => 'effect', 'value' => array('simple','reveal') ),
			        ),
					// Video Icon
					array(
						'type' => 'dropdown',
						'heading' => __( 'Style', 'deeper' ),
						'param_name' => 'video_style',
						'value' => array(
							'White' 		=> 'style-1',
							'Accent' 		=> 'style-2',
							'SVG White' 		=> 'style-3',
						),
						'std'		=> 'style-1',
						'group' => esc_html__( 'Video Icon', 'deeper' ),
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Icon Size', 'deeper' ),
						'param_name' => 'video_size',
						'value' => array(
							'Big' 		=> 'big',
							'Medium' 		=> 'medium',
							'Small' 		=> 'small',
						),
						'std'		=> 'medium',
						'group' => esc_html__( 'Video Icon', 'deeper' ),
					),
					array(
						'type' => 'vc_link',
						'heading' => __( 'URL (Required):', 'deeper' ),
						'param_name' => 'video_url',
						'value' => '',
						'group' => esc_html__( 'Video Icon', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Video Text (Optional):', 'deeper' ),
						'param_name' => 'video_text',
						'value' => '',
						'group' => esc_html__( 'Video Icon', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'video_class',
						'value' => '',
						'group' => esc_html__( 'Video Icon', 'deeper' ),
			        ),
					// Stretch
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Image Stretch', 'deeper' ),
						'param_name' => 'stretch',
						'value'      => array(
							'No Stretch' => '',
							'Stretch To Right' => 'stretch_right',
							'Stretch To Left' => 'stretch_left',
							'Stretch on Mobile' => 'stretch_mobi',
						),
						'std'		=> '',
						'group' => esc_html__( 'Stretch', 'deeper' ),
						'dependency' => array( 'element' => 'effect', 'value' => 'reveal' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Offset Left', 'deeper'),
						'param_name' => 'offset_left',
						'value' => '-22vw',
						'group' => esc_html__( 'Stretch', 'deeper' ),
						'dependency' => array( 'element' => 'stretch', 'value' => 'stretch_left' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Offset Right', 'deeper'),
						'param_name' => 'offset_right',
						'value' => '-22vw',
						'group' => esc_html__( 'Stretch', 'deeper' ),
						'dependency' => array( 'element' => 'stretch', 'value' => 'stretch_right' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Extra Class', 'deeper'),
						'param_name' => 'class',
						'value' => '',
			        ),
				)
		    );
		}
	}
}

new Deeper_Fancy_Image_Shortcode;