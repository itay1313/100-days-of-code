<?php
/**
 * Gmap shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Gmap_Shortcode' ) ) {

	class Deeper_Gmap_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_gmap', array( 'Deeper_Gmap_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_gmap', array( 'Deeper_Gmap_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$html = $css = $dragging = '';

			extract( shortcode_atts( array(
			    'style' => 'style-1',
			    'lat' => '',
			    'lng' => '',
			    'width' => '',
			    'height' => '300',
			    'zoom' => '14',
			    'drag_mobile' => 'true',
			    'drag_desktop' => 'true',
			    'marker_type' => 'simple',
			    'image' => ''
			), $atts ) );

			if ( $width ) $css .= 'width:'. intval( $width ) .'px;';
			if ( $height ) $css .= 'height:'. intval( $height ) .'px;';

			$id = "map_". uniqid();

			$dragging = ( wp_is_mobile() ) ? $drag_mobile : $drag_desktop;

			if ( $image && $marker_type == 'image' )
			    $image = wp_get_attachment_image_src( $atts['image'], 'full' )[0];

			$ultra_light = '[{"featureType":"water","elementType":"geometry","stylers":[{"color":"#e9e9e9"},{"lightness":17}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":20}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffffff"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#ffffff"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":16}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":21}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#dedede"},{"lightness":21}]},{"elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"lightness":16}]},{"elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#333333"},{"lightness":40}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#f2f2f2"},{"lightness":19}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#fefefe"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#fefefe"},{"lightness":17},{"weight":1.2}]}]';

			$mono_light = '[{"featureType":"administrative.locality","elementType":"all","stylers":[{"hue":"#2c2e33"},{"saturation":7},{"lightness":19},{"visibility":"on"}]},{"featureType":"landscape","elementType":"all","stylers":[{"hue":"#ffffff"},{"saturation":-100},{"lightness":100},{"visibility":"simplified"}]},{"featureType":"poi","elementType":"all","stylers":[{"hue":"#ffffff"},{"saturation":-100},{"lightness":100},{"visibility":"off"}]},{"featureType":"road","elementType":"geometry","stylers":[{"hue":"#bbc0c4"},{"saturation":-93},{"lightness":31},{"visibility":"simplified"}]},{"featureType":"road","elementType":"labels","stylers":[{"hue":"#bbc0c4"},{"saturation":-93},{"lightness":31},{"visibility":"on"}]},{"featureType":"road.arterial","elementType":"labels","stylers":[{"hue":"#bbc0c4"},{"saturation":-93},{"lightness":-2},{"visibility":"simplified"}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"hue":"#e9ebed"},{"saturation":-90},{"lightness":-8},{"visibility":"simplified"}]},{"featureType":"transit","elementType":"all","stylers":[{"hue":"#e9ebed"},{"saturation":10},{"lightness":69},{"visibility":"on"}]},{"featureType":"water","elementType":"all","stylers":[{"hue":"#e9ebed"},{"saturation":-78},{"lightness":67},{"visibility":"simplified"}]}]';

			$even_light = '[{"featureType":"administrative","elementType":"labels.text.fill","stylers":[{"color":"#6195a0"}]},{"featureType":"landscape","elementType":"all","stylers":[{"color":"#f2f2f2"}]},{"featureType":"landscape","elementType":"geometry.fill","stylers":[{"color":"#ffffff"}]},{"featureType":"poi","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"poi.park","elementType":"geometry.fill","stylers":[{"color":"#e6f3d6"},{"visibility":"on"}]},{"featureType":"road","elementType":"all","stylers":[{"saturation":-100},{"lightness":45},{"visibility":"simplified"}]},{"featureType":"road.highway","elementType":"all","stylers":[{"visibility":"simplified"}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#f4d2c5"},{"visibility":"simplified"}]},{"featureType":"road.highway","elementType":"labels.text","stylers":[{"color":"#4e4e4e"}]},{"featureType":"road.arterial","elementType":"geometry.fill","stylers":[{"color":"#f4f4f4"}]},{"featureType":"road.arterial","elementType":"labels.text.fill","stylers":[{"color":"#787878"}]},{"featureType":"road.arterial","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"all","stylers":[{"color":"#eaf6f8"},{"visibility":"on"}]},{"featureType":"water","elementType":"geometry.fill","stylers":[{"color":"#eaf6f8"}]}]';

			switch ( $style ) {
			    case "style-1":
			        $style = $ultra_light;
			        break;
			    case "style-2":
			        $style = $mono_light;
			        break;
			    case "style-3":
			        $style = $even_light;
			        break;
			}

			$html = '
			<script type="text/javascript">
			    var places = [['. $lat .', '. $lng .']];

			    function deeper_vc_gmap() {
			        var mapOptions = {
			            scrollwheel: false,
			            styles:'. $style .',
			            draggable: '. $dragging .',
			            zoom: '. $zoom .',
			            center: new google.maps.LatLng('. $lat .', '. $lng .'),
			            mapTypeControlOptions: {
			                mapTypeIds: [google.maps.MapTypeId.ROADMAP, "map_style"]
			            }
			        }

			        var map = new google.maps.Map( document.getElementById("'. $id .'"), mapOptions );
			       
			        setMarkers( map, places );
			    }

			    function setMarkers( map, locations ) {
			        for ( var i = 0; i < locations.length; i++ ) {
			            var place = locations[i];
			            var myLatLng = new google.maps.LatLng( place[0], place[1] );
			            var marker = new google.maps.Marker( {
			                position: myLatLng,
			                map: map,
			                icon: "'. $image .'",
			                zIndex: place[2],
			                animation: google.maps.Animation.DROP
			            } );

			            google.maps.event.addListener( marker, "click", function () {
			                infowindow.setContent( decodeURIComponent( this.html ) );
			                infowindow.open( map, this );
			            } );
			        }
			    }

			    google.maps.event.addDomListener(window, "load", deeper_vc_gmap);
			</script>';

			return sprintf( '%s<div id="%s" class="deeper-google-map" style="%s"></div>', $html, $id, $css );
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Google Map', 'deeper' ),
		        'description' => __( 'Displays Google Map.', 'deeper' ),
		        'base' => 'deeper_gmap',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/googlemap.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
			        array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Map Style', 'deeper' ),
						'param_name' => 'style',
						'value'      => array(
							'Style 1' => 'style-1',
							'Style 2' => 'style-2',
							'Style 3' => 'style-3',
						),
						'std'		=> 'style-1',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Latitude', 'deeper' ),
						'param_name'  => 'lat',
						'description' => '<a href="http://universimmedia.pagesperso-orange.fr/geo/loc.html" target="_blank">'. esc_html__('Here is a tool', 'deeper').'</a> '. esc_html__('where you can find Latitude & Longitude of your location', 'deeper'),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Longitude', 'deeper' ),
						'param_name'  => 'lng',
						'description' => '<a href="http://universimmedia.pagesperso-orange.fr/geo/loc.html" target="_blank">'. esc_html__('Here is a tool', 'deeper').'</a> '. esc_html__('where you can find Latitude & Longitude of your location', 'deeper'),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Map Width', 'deeper' ),
						'param_name' => 'width',
						'value'      => ''
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Map Height', 'deeper' ),
						'param_name' => 'height',
						'value'      => 300
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Zoom Level', 'deeper' ),
						'param_name'  => 'zoom',
						'description' => esc_html__( 'Select the default zoom level for the Maps', 'deeper' ),
						'value'       => array_combine( range( 1, 24 ), range( 1, 24 ) ),
						'std'		  => '14'
					),
		            array(
		                'type' => 'dropdown',
		                'heading' => esc_html__( 'Dragging on Mobile' ),
		                'param_name' => 'drag_mobile',
						//value'      => array( __( 'Yes, please.', 'deeper' ) => 'yes' ),
		                'value' => array( esc_html__( 'Enable' ) => 'true', esc_html__( 'Disable' ) => 'false'),
		                'std' => 'true'
		            ),
		            array(
		                'type' => 'dropdown',
		                'heading' => esc_html__( 'Dragging on Desktop' ),
		                'param_name' => 'drag_desktop',
		                'value' => array( esc_html__( 'Enable' ) => 'true', esc_html__( 'Disable' ) => 'false'),
		                'std' => 'true'
		            ),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Show The Marker', 'deeper' ),
						'param_name'  => 'marker_type',
						'value'       => array(
							'Simple'          => 'simple',
							'Custom Image' => 'image',
						),
						'std'		=> 'simple',
						'group' => esc_html__( 'Maker', 'deeper' ),
					),
					array(
						'type' => 'attach_image',
						'heading' => esc_html__('Image', 'deeper'),
						'param_name' => 'image',
						'value' => '',
						'group' => esc_html__( 'Maker', 'deeper' ),
						'dependency' => array( 'element' => 'marker_type', 'value' => 'image' ),
					),
				)
		    );
		}
	}

	new Deeper_Gmap_Shortcode;
}
