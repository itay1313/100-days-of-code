<?php
/**
 * Slider_Content shortcode for Visual Composer
 *
 * @package Deeper Addons
 */
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_deeper_slidercontent extends WPBakeryShortCodesContainer {}
}

if ( ! class_exists( 'Deeper_Slider_Content_Shortcode' ) ) {

	class Deeper_Slider_Content_Shortcode {
		// Constructor
		public function __construct() {

			// Add shortcode
			add_shortcode( 'deeper_slidercontent', array( 'Deeper_Slider_Content_Shortcode', 'output' ) );
			
			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_slidercontent', array( 'Deeper_Slider_Content_Shortcode', 'map' ) );
			}	
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			extract(shortcode_atts(array(
	        ), $atts));

	        return sprintf( 
	        	'<div class="slick-content-item">
	        		%1$s
     	    	</div>',
     	    	do_shortcode( $content )
	        	);  				
		}	

		// Map shortcode to VC
		public static function map() {
		    return array(
	        	"name" => esc_html__("Slider Content", 'deeper'),
				'base' => 'slidercontent',
				'weight'	=>	180,
				'icon' => plugins_url( '../../assets/icon/tabs.png', __FILE__ ),
				'as_child' => array('only' => 'deeper_slider'),
				'as_parent' => array('except' => 'deeper_slider, deeper_slidercontent'),
				'controls' => 'full',
				'show_settings_on_create' => true,
				'category' => esc_html__('Deeper Addons', 'deeper'),
				'js_view' => 'VcColumnView',
		    );
		}
	}
}

new Deeper_Slider_Content_Shortcode;