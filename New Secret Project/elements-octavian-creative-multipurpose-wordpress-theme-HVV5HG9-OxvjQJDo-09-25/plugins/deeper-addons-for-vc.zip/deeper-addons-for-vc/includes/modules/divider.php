<?php
/**
 * Divider shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Divider_Shortcode' ) ) {

	class Deeper_Divider_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_divider', array( 'Deeper_Divider_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_divider', array( 'Deeper_Divider_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {

			$css1 =  $css2 = $icon_html = $icon_cls = $icon_css = $icon_css2 = $border_css = '';
			$anim_cls = $anim_data = '';

			extract( shortcode_atts( array(
				'alignment' => 'divider-center',
				'style' => 'solid',
				'width' => '',
				'height' => '',
				'color' => '',
				'icon_display' => 'no-icon',
				'icon_type' => '',
				'icon' => '',
				'icon_color' => '',
				'icon_font_size' => '',
				// Spacing
				'icon_padding' => '',
				'icon_top_margin' => '',
				'margin' => '',
				// Animation
			    'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',

				'class' => '',

			), $atts ) );
			$accent = deeper_get_accent_color();
			$height = intval( $height );
			$icon_font_size = intval( $icon_font_size );
			$icon_top_margin = intval( $icon_top_margin );

			$cls = $alignment;

			if ( $style == 'solid') $cls .= ' divider-solid';
			if ( $style == 'dotted') $cls .= ' divider-dotted';
			if ( $style == 'dashed') $cls .= ' divider-dashed';
			if ( $style == 'double') $cls .= ' divider-double';

			if ( $icon_display == 'no-icon' ) {
				if ( $width ) $css1 .= 'width:'. $width .';';
				if ( $height ) $css1 .= 'border-width:'. $height .'px;';

				if ( $color == $accent ) { $cls .= ' accent'; }
				else { if ( $color ) $css1 .= 'border-top-color:'. $color .';'; }

				if ( $margin ) $css1 .= 'margin:'. $margin .';';

				return sprintf( '<div class="deeper-divider %1$s" style="%2$s"></div><div class="clearfix"></div>', $cls, $css1 );
			}

			if ( $icon_display == 'icon-font' ) {
				$icon = deeper_get_icon_class( $atts, 'icon' );

				if ( $width ) $css2 = 'width:'. $width .';';
				if ( $margin ) $css2 .= 'margin:'. $margin .';';

				if ( $height ) $border_css = 'border-bottom-width:'. $height .'px;';
				if ( $color ) $border_css .= 'border-color:'. $color .';';

				if ( $icon_display == 'icon-font' && $icon && $icon_type != '' ) {
					vc_icon_element_fonts_enqueue( $icon_type );

					if ( $icon_font_size ) $icon_css .= 'font-size:'. $icon_font_size .'px;';
					if ( $icon_padding ) $icon_css2 = 'padding:'. $icon_padding .';';
					if ( $icon_top_margin ) $icon_css2 = 'margin-top:'. $icon_top_margin .'px;';

					if ( $icon_color == $accent ) { $icon_cls .= ' accent'; }
					else { if ( $icon_color ) $icon_css .= 'color:'. $icon_color .';'; }

					$icon_html = sprintf( '<span class="%1$s %3$s" style="%2$s"></span>', $icon, $icon_css, $icon_cls );
				}

				//Animation
				if ( $animation ) {
				    $anim_cls .= ' wow '. $animation_effect;
				    $anim_data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
				}

				return sprintf(
					'<div class="deeper-divider has-icon %6$s" style="%1$s" %7$s>
						<div class="divider-icon">
							<span class="divider-icon-before %5$s" style="%4$s"></span>
							<span class="icon-wrap" style="%3$s">%2$s</span>
							<span class="divider-icon-after %5$s" style="%4$s"></span>
						</div>
					</div><div class="clearfix"></div>',
					$css2,
					$icon_html,
					$icon_css2,
					$border_css,
					$cls,
					$anim_cls,
					$anim_data
				);
			}
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Divider', 'deeper' ),
		        'description' => __( 'Displaying lines separator.', 'deeper' ),
		        'base' => 'divider',
				'weight'	=>	180,
		        'icon' => plugins_url( '../../assets/icon/divider.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Alignment', 'deeper' ),
						'param_name' => 'alignment',
						'value'      => array(
							'Left' => 'divider-left',
							'Center' => 'divider-center',
							'Right' => 'divider-right',
						),
						'std'		=> 'divider-center',
						'dependency' => array( 'element' => 'icon_display', 'value' => 'no-icon' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Line Style', 'deeper' ),
						'param_name' => 'style',
						'value'      => array(
							'Solid' => 'solid',
							'Dotted' => 'dotted',
							'Dashed' => 'dashed',
							'Double' => 'double',
						),
						'std'		=> 'solid',
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Line: Width', 'deeper'),
						'param_name' => 'width',
						'value' => '',
						'description' => esc_html__( 'Default: 100%.', 'deeper' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Line: Height', 'deeper'),
						'param_name' => 'height',
						'value' => '',
						'description'	=> esc_html__('Default: 1px', 'deeper'),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Line: Color', 'deeper'),
						'param_name' => 'color',
						'value' => '',
		            ),
					// Icon
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Icon to Display', 'deeper' ),
						'param_name' => 'icon_display',
						'value'      => array(
							'No Icon' => 'no-icon',
							'Icon Font' => 'icon-font',
						),
						'std'		=> 'no-icon',
						'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
						'type' => 'dropdown',
						'heading' => esc_html__( 'Icon library', 'deeper' ),
						'param_name' => 'icon_type',
						'description' => esc_html__( 'Select icon library.', 'deeper' ),
						'value' => array(
							'' => '',
							esc_html__( 'Jitsin Icons', 'deeper' ) => 'extraicon',
							esc_html__( 'Stroke 7 Icons', 'deeper' ) => 'extraicon2',
							esc_html__( 'Open Iconic', 'deeper' ) => 'openiconic',
							esc_html__( 'Typicons', 'deeper' ) => 'typicons',
							esc_html__( 'Entypo', 'deeper' ) => 'entypo',
							esc_html__( 'Linecons', 'deeper' ) => 'linecons',
						),
						'group' => esc_html__( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-font' ),
					),
					array(
					    'type' => 'iconpicker',
					    'heading' => esc_html__( 'Icon', 'deeper' ),
					    'param_name' => 'icon_extraicon',
					    'settings' => array(
					        'emptyIcon' => true,
					        'type' => 'extraicon',
					        'iconsPerPage' => 200,
					    ),
					    'dependency' => array(
					        'element' => 'icon_type',
					        'value' => 'extraicon',
					    ),
					    'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
					    'type' => 'iconpicker',
					    'heading' => esc_html__( 'Icon', 'deeper' ),
					    'param_name' => 'icon_extraicon2',
					    'settings' => array(
					        'emptyIcon' => true,
					        'type' => 'extraicon2',
					        'iconsPerPage' => 200,
					    ),
					    'dependency' => array(
					        'element' => 'icon_type',
					        'value' => 'extraicon2',
					    ),
					    'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
						'type' => 'iconpicker',
						'heading' => esc_html__( 'Icon', 'deeper' ),
						'param_name' => 'icon_openiconic',
						'settings' => array(
							'emptyIcon' => true,
							'type' => 'openiconic',
							'iconsPerPage' => 200,
						),
						'dependency' => array(
							'element' => 'icon_type',
							'value' => 'openiconic',
						),
						'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
						'type' => 'iconpicker',
						'heading' => esc_html__( 'Icon', 'deeper' ),
						'param_name' => 'icon_typicons',
						'settings' => array(
							'emptyIcon' => true,
							'type' => 'typicons',
							'iconsPerPage' => 200,
						),
						'dependency' => array(
							'element' => 'icon_type',
							'value' => 'typicons',
						),
						'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
						'type' => 'iconpicker',
						'heading' => esc_html__( 'Icon', 'deeper' ),
						'param_name' => 'icon_entypo',
						'settings' => array(
							'emptyIcon' => true,
							'type' => 'entypo',
							'iconsPerPage' => 300,
						),
						'dependency' => array(
							'element' => 'icon_type',
							'value' => 'entypo',
						),
						'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
						'type' => 'iconpicker',
						'heading' => esc_html__( 'Icon', 'deeper' ),
						'param_name' => 'icon_linecons',
						'settings' => array(
							'emptyIcon' => true,
							'type' => 'linecons',
							'iconsPerPage' => 200,
						),
						'dependency' => array(
							'element' => 'icon_type',
							'value' => 'linecons',
						),
						'group' => esc_html__( 'Icon', 'deeper' ),
					),
		            array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Icon: Color', 'deeper'),
						'param_name' => 'icon_color',
						'value' => '',
						'group' => esc_html__( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-font' ),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Icon: Font Size', 'deeper'),
						'param_name' => 'icon_font_size',
						'value' => '',
						'group' => esc_html__( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-font' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Icon: Padding', 'deeper'),
						'param_name' => 'icon_padding',
						'value' => '',
						'group' => esc_html__( 'Icon', 'deeper' ),
						'description'	=> esc_html__('Top Right Bottom Left. Default: 0px 12px 0px 12px', 'deeper'),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-font' ),
			        ),
			        // Spacing
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Icon: Top Margin', 'deeper'),
						'param_name' => 'icon_top_margin',
						'value' => '',
						'group' => esc_html__( 'Spacing', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Line: Margin', 'deeper'),
						'param_name' => 'margin',
						'value' => '',
						'group' => esc_html__( 'Spacing', 'deeper' ),
			        ),
			        // Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Extra Class', 'deeper'),
						'param_name' => 'class',
						'value' => '',
		            ),
		        )
		    );
		}
	}
}

new Deeper_Divider_Shortcode;