<?php
/**
 * Demo_Box shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Demo_Box_Shortcode' ) ) {

	class Deeper_Demo_Box_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_demobox', array( 'Deeper_Demo_Box_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_demobox', array( 'Deeper_Demo_Box_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {

			extract( shortcode_atts( array(
				'demo_image' => '',
				'demo_max_height' => '',
				'demo_url' => '',
				'demo_text' => '',
				'class' => '',
				// Coming Soon
				'box_text' => '',
				// Animation
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );

			$cls = $css = $data = '';
			$url = $image = '';

			if ( $demo_url ) {
				$url .= ' href="' . esc_url( vc_build_link( $demo_url )['url'] ) . '"';
				if ( vc_build_link( $demo_url )['target'] )
					$url .= ' target="' . esc_attr( vc_build_link( $demo_url )['target'] ) . '"';
			} 

			if ( $demo_max_height ) $css .= 'height:' . $demo_max_height . ';';
			if ( $demo_image ) $image = '<img src="' . wp_get_attachment_image_src( $demo_image, 'full' )[0] . '" alt="Image">';



			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}

			if ( $box_text ) {
				return sprintf(
					'<div class="deeper-demo-box no-image %1$s" %3$s>
						<span class="demo-image" style="%4$s"><span class="text">%5$s</span></span>
						<h3 class="demo-text"><a %2$s>%6$s</a></h3>
					</div>',
					$cls,
					$url,
					$data,
					$css,
					$box_text,
					$demo_text
				);
			}

			return sprintf(
				'<div class="deeper-demo-box %1$s" %3$s>
					<a class="demo-image" %2$s style="%4$s">
						%5$s
					</a>
					<h3 class="demo-text"><a %2$s>%6$s</a></h3>
				</div>',
				$cls,
				$url,
				$data,
				$css,
				$image,
				$demo_text
			);
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Demo Box', 'deeper' ),
		        'description' => __( 'Display Demo on Landing Page.', 'deeper' ),
		        'base' => 'deeper_demobox',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/partner.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
		        	array(
						'type' => 'attach_image',
						'heading' => esc_html__('Demo Image', 'deeper'),
						'param_name' => 'demo_image',
						'value' => '',
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Demo Image: Max Height', 'deeper' ),
						'param_name' => 'demo_max_height',
						'value' => '',
			        ),
			        array(
						'type' => 'vc_link',
						'heading' => __( 'Demo URL (Required):', 'deeper' ),
						'param_name' => 'demo_url',
						'value' => '',
			        ),
			        array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => __( 'Demo Text', 'deeper' ),
						'param_name' => 'demo_text',
						'value' => '',
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'class',
						'value' => '',
			        ),
			        // Coming Soon
			        array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => __( 'Text', 'deeper' ),
						'param_name' => 'box_text',
						'value' => '',
						'group' => esc_html__( 'Coming Soon', 'deeper' ),
			        ),
			        // Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		        )
		    );
		}
	}

	new Deeper_Demo_Box_Shortcode;
}
