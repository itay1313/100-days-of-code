<?php
/**
 * Parallax_Item shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Parallax_Item_Shortcode' ) ) {

	class Deeper_Parallax_Item_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_parallaxitem', array( 'Deeper_Parallax_Item_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_parallaxitem', array( 'Deeper_Parallax_Item_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {

			$cls = $css = $inner_css = $image_html = $data = '';

			extract( shortcode_atts( array(
				'image' => '',
				'image_width' => '',
				'image_rounded' => '',
				'stretch' => '',
				'parallax_attr' => '',
				'smoothness' => '30',
				'left' => '',
				'right' => '',
				'top' => '',
				'transform' => '',
				'class' => '',
			    'shadow' => '',
			    'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
				'class'	=> '',
			), $atts ) );
			$parallax_atts = '';
			$inner_css = '';

			if ( $class ) $cls .= ' ' . $class;
			if ( ! empty( $left ) ) $css .= 'left:'. $left .';';
			if ( ! empty( $right ) ) $css .= 'left:auto;right:'. $right .';';
			if ( ! empty( $top ) ) $css .= 'margin-top:'. $top .';';

			if ( $image ) $image_html .= '<img class="parallax-image" src="'. wp_get_attachment_image_src( $image, 'full' )[0] .'" alt="image">';
			if ( $image_width ) {
				$cls .= ' has-width';
				$css .= 'width:'. $image_width .';';
			}
			if ( $image_rounded ) $css .= 'border-radius:'. $image_rounded .';';

			if ( $shadow )
			    $css .= 'box-shadow:' . $shadow . ';';

			if ( $transform ) $css .= 'transform:' . $transform . ';';
			
			if ( $parallax_attr ) 
				$parallax_atts .= $parallax_attr . ', "smoothness": ' . intval ($smoothness );
			//Animation
			if ( $animation ) {
				$anim_cls = ' wow '. $animation_effect;
		    	$anim_data = ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';	

		    	return sprintf(
					'<div class="%6$s" %7$s>
						<div class="deeper-parallax-item %5$s" style="%2$s" data-parallax=\'{ %3$s }\' data-top="%4$s">
						 	<div class="inner">
						 		%1$s
						 	</div>
						</div>
					</div>',
					$image_html,
					$css,
					str_replace( '``', '"', $parallax_atts ),
					$top,
					$cls,
					$anim_cls,
					$anim_data
				);   
			} else {
				return sprintf(
					'<div class="deeper-parallax-item %5$s" style="%2$s" data-parallax=\'{ %3$s }\' data-top="%4$s">
					 	<div class="inner">
					 		<div class="image-wrap">
					 			%1$s
					 		</div>
					 	</div>
					</div>',
					$image_html,
					$css,
					str_replace( '``', '"', $parallax_atts ),
					$top,
					$cls
				);
			}
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Parallax Item', 'deeper' ),
		        'description' => __( 'Parallax Item for Parallax Box.', 'deeper' ),
		        'base' => 'parallaxitem',
				'weight'	=>	180,
				'as_child' => array( 'only' => 'deeper_parallaxbox' ),
		        'icon' => plugins_url( '../../assets/icon/parallaxbox.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params'      => array(
					array(
						'type' => 'attach_image',
						'heading' => esc_html__('Image', 'deeper'),
						'param_name' => 'image',
						'value' => '',
					),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Image Width', 'deeper'),
						'param_name' => 'image_width',
						'value' => '',
						'description'	=> esc_html__('You can use % or px value. Ex: 50%.', 'deeper'),
			        ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Image Rounded', 'deeper'),
						'param_name' => 'image_rounded',
						'value' => '',
						'description'	=> esc_html__('Ex: 5px', 'deeper'),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Box Shadow', 'deeper'),
						'param_name' => 'shadow',
						'value' => '',
		            ),
			        array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Parallax Attributes', 'deeper'),
			            'param_name' => 'parallax_attr',
			            'value' => '',
			            'description'   => esc_html__('Ex: "x": 10, "y": 20. Values Possible: x, y, z, rotateX, rotateY, rotateZ, scaleX, scaleY, scaleZ, scale.', 'deeper'),
			        ),
			        array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Smoothness', 'deeper'),
			            'param_name' => 'smoothness',
			            'value' => '30',
			            'description'   => esc_html__('Slowdown the animation.', 'deeper'),
			        ),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Left', 'deeper'),
						'param_name' => 'left',
						'value' => '',
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Right', 'deeper'),
						'param_name' => 'right',
						'value' => '',
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Top', 'deeper'),
						'param_name' => 'top',
						'value' => '',
					),	            
		            // Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ), 
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Extra Class', 'deeper'),
						'param_name' => 'class',
						'value' => '',
		            ),		           
				)
		    );
		}
	}
}

new Deeper_Parallax_Item_Shortcode;