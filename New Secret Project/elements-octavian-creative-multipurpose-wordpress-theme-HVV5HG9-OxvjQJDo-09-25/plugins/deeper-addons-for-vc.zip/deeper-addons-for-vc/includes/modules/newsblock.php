<?php
/**
 * News Block shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_News_Block_Shortcode' ) ) {
	
	class Deeper_News_Block_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_newblock', array( 'Deeper_News_Block_Shortcode', 'output' ) );		

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_newblock', array( 'Deeper_News_Block_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$cls = '';
			$date_html = $time_html = $location_html = $title_html = '';

			extract( shortcode_atts( array(
				'style'			=> 'style-1',
				'items'			=> '4',
				'cat_slug'		=> '',
				'exclude_cat_slug' => '',
				'image_crop'    => 'full',
			    'class'		 => '',
			    'linktext'	 => '',
			    // Animation
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );

			$data = $cls = '';

			$args = array(
			    'post_type' => 'post',
			    'posts_per_page' => intval( $items )
			);

			if ( ! empty( $cat_slug ) ) {
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'category',
						'field'    => 'slug',
						'terms'    => $cat_slug
					),
				);
			}

			if ( ! empty( $exclude_cat_slug ) ) {
				$args['tax_query'] = array(
				    array(
				        'taxonomy' => 'category',
				        'field' => 'slug',
				        'terms' => $exclude_cat_slug,
				        'operator' => 'NOT IN'
				    ),
				);
			}	

			$current_post = 0;	

			$query = new WP_Query( $args );
			if ( ! $query->have_posts() ) { esc_html_e( 'Post item not found!', 'deeper' ); return; }

			wp_enqueue_script( 'cubeportfolio' );
			wp_enqueue_script( 'magnificpopup' );

			if ( $class ) $cls .= ' ' . $class;
			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}

			$post_html = array();

			ob_start(); 
			if ( $query->have_posts() ) : ?>
            	<?php while ( $query->have_posts() ) : $query->the_post(); 
            		//var_dump($query);
            		$current_post++;
            		$html = '';
            		if ( $current_post == 1 ) {
            			$image_crop = 'deeper-std2';
            		} else {
            			$image_crop = 'deeper-std5';
            		} 

            		if ( has_post_thumbnail() ) 
            			$html .= sprintf( '<div class="thumb">%1$s</div>', get_the_post_thumbnail( get_the_ID(), $image_crop ) );

            		$html .= sprintf( 
            			'<div class="text">
            				<h3 class="post-title"><a href="%4$s">%1$s</a></h3>
            				<p class="desc">%2$s</p>
            				<span class="date">%3$s</span>
            			</div>', 
            			get_the_title(),
            			octavian_metabox( 'post-desc' ),
            			get_the_date(),
            			esc_url( get_the_permalink() )
            		); 

            		if ( $current_post == 1 ) {
            			$post_html[] .= sprintf( '<div class="deeper-news-box wow fadeInUp" data-wow-duration="0.75s" data-wow-delay="0s">%1$s</div>', $html );
            		} else {
            			$data = '';
            			$data .= 'data-wow-duration="0.75s" data-wow-delay="' . ( $current_post - 1 )* 0.3 . 's"';
            			$post_html[] .= sprintf( '<div class="deeper-news-box wow fadeInRight" %2$s>%1$s</div>', $html, $data );
            		}
            		

            		?>           		
            	<?php endwhile; ?>

            	<div class="deeper-news-block">
            		<div class="first-post">
            			<?php echo $post_html[0]; ?>
            		</div>

            		<div class="posts-wrap">
            			<?php
            				if ( $post_html[1] ) echo $post_html[1];
            				if ( $post_html[2] ) echo $post_html[2];
            				if ( $post_html[3] ) echo $post_html[3];
            			?>
            		</div>
            	</div>
			<?php endif; wp_reset_postdata(); 
			$return = ob_get_clean();
			return $return;
		}

		// Map shortcode to VC
		public static function map() {		

		    return array( 
		    	'name' => __( 'News Block', 'deeper' ),
				'description' => __( 'Displays a Block of recent news.', 'deeper' ),
				'base' => 'deeper_newblock',
				'weight'	=>	180,
				'icon' => plugins_url( '../../assets/icon/news.png', __FILE__ ),
				'category' => __( 'Deeper Addons', 'deeper' ),
				'params' => array(
			        array(
						'type' => 'textfield',
						'heading' => __( 'Category Slug (Optional)', 'deeper' ),
						'param_name' => 'cat_slug',
						'value' => '',
						'description'	=> __( 'Displaying posts that have this category. Using category-slug.', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Exclude Category Slug (Optional)', 'deeper' ),
						'param_name' => 'exclude_cat_slug',
						'value' => '',
						'description'	=> __( 'Exclude posts that have this category. Using category-slug.', 'deeper' ),
			        ),		
			        // Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
				  	array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'class',
						'value' => '',
			        ),
        		)
			);
		}
	}
}

new Deeper_News_Block_Shortcode;
