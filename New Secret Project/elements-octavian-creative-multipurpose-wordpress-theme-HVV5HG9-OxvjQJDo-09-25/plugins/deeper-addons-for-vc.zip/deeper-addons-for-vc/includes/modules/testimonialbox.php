<?php
/**
 * Testimonial_Box shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Testimonial_Box_Shortcode' ) ) {

	class Deeper_Testimonial_Box_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_testimonialbox', array( 'Deeper_Testimonial_Box_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_testimonialbox', array( 'Deeper_Testimonial_Box_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {

			extract( shortcode_atts( array(
				'style'  => 'style-1',
				'alignment' => 'align-center',
				// Avatar
				'avatar' => '',
				'avatar_width' => '',
				'avatar_rounded' => '',
				// Design
				'bg_image'	=> '',
				'bg_position'	=> 'left top',
				'bg_repeat'	=> 'no-repeat',
				'bg_size'	=> '',
				'bg_color'	=> '',
				'shadow'	=> '',
				'rounded'	=> '',
				// Content
				'title'	=> '',
				'author_name'	=> '',
				'author_position'	=> '',
				'title_color'	=> '',
				'author_name_color'	=> '',
				'author_position_color'	=> '',
				'comment_color'	=> '',
				'image_rating'	=> '',
				'image_rating_width'	=> '',
				// Typography
				'title_font_family' 	=> '',
				'title_font_weight' 	=> '',
				'title_font_size' 		=> '',
				'title_line_height' 	=> '',
				'title_letter_spacing' 	=> '',

				'comment_font_family' 	=> '',
				'comment_font_weight' 	=> '',
				'comment_font_size' 		=> '',
				'comment_line_height' 	=> '',
				'comment_letter_spacing' 	=> '',

				'author_name_font_family' 	=> '',
				'author_name_font_weight' 	=> '',
				'author_name_font_size' 		=> '',
				'author_name_line_height' 	=> '',
				'author_name_letter_spacing' 	=> '',

				'author_position_font_family' 	=> '',
				'author_position_font_weight' 	=> '',
				'author_position_font_size' 		=> '',
				'author_position_line_height' 	=> '',
				'author_position_letter_spacing' 	=> '',

				// Spacing
				'avatar_margin' => '',
				'content_padding' => '',
				'content_margin' => '',
				'title_margin' => '',
				'comment_margin' => '',
				'author_name_margin_top' => '',
				'author_name_margin_bottom' => '',
				'author_position_margin' => '',

				// Animation
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',

				'class'  => '',
			), $atts ) );
			$accent = deeper_get_accent_color();
			// Init
			$avatar_url = $avatar_css = '';
			$rating_url = $rating_css = '';
			$text_css = '';
			$title_css = $comment_css = $author_name_css = $author_position_css = '';
			$avatar_html = $title_html = $comment_html = $rating_html = $author_name_html = $author_position_html = '';
			$data = '';

			$accent = deeper_get_accent_color();
			$content = wpb_js_remove_wpautop( $content, true );
			
			$cls = $style . ' ' . $alignment . ' ' . $class;

			if ( $bg_image ) {
				$text_css .= 'background-image:url('. wp_get_attachment_image_src( $bg_image, 'full' )[0] .');';
				$text_css .= 'background-position:'. $bg_position .';';
				$text_css .= 'background-repeat:'. $bg_repeat .';';
				if ( $bg_size ) $text_css .= 'background-size:'. $bg_size .';';
			}

			if ( $bg_color == $accent ) {
				$cls .= ' bg-accent';
			} elseif ( $bg_color ) {
				$text_css .= 'background-color:' . $bg_color . ';';
			}
			if ( $content_padding ) $text_css .= 'padding:' . $content_padding . ';';
			if ( $content_margin ) $text_css .= 'margin:' . $content_margin . ';';
			if ( $rounded ) $text_css .= 'overflow:hidden;border-radius:' . $rounded . ';'; 
			if ( $shadow ) $text_css .= 'box-shadow:' . $shadow . ';'; 

			// Avatar 
			if ( $avatar ) {
				$avatar_url = wp_get_attachment_image_src( $avatar, 'full' )[0];
				if( $avatar_rounded ) $avatar_css .= 'overflow:hidden;border-radius:' . $avatar_rounded . ';';
				if( $avatar_width ) $avatar_css .= 'width:' . $avatar_width . ';height:' . $avatar_width . ';';
				if( $avatar_margin ) $avatar_css .= 'margin:' . $avatar_margin . ';';

				$avatar_html = sprintf(
					'<div class="avatar" style="%1$s">
						<img src="%2$s" alt="Avatar">
					</div>',
					esc_attr( $avatar_css ),
					esc_url( $avatar_url )
				);
			} 

			// Title
			if ( $title ) {
				$title_cls = '';
				if ( $title_color == $accent ) {
					$title_cls .= ' accent-color';
				} elseif ( $title_color ) {
					$title_css .=  'color:' . $title_color . ';';
				}
				if ( $title_font_weight ) $title_css .= 'font-weight:' . $title_font_weight . ';';
				if ( $title_font_size ) $title_css .= 'font-size:' . intval( $title_font_size ) . 'px;';
				if ( $title_line_height ) $title_css .= 'line-height:' . intval( $title_line_height ) . 'px;';
				if ( $title_letter_spacing ) $title_css .= 'letter-spacing:' . $title_letter_spacing . 'px;';
				if ( $title_font_family ) {
					deeper_enqueue_google_font( $title_font_family );
					$title_css .= 'font-family:' . $title_font_family . ';';
				}
				if ( $title_margin ) $title_css .= 'margin-bottom:' . intval( $title_margin ) . 'px;';

				$title_html = sprintf( 
				'<h3 class="title %3$s" style="%1$s">
					%2$s
				</h3>',
				esc_attr( $title_css ),
				esc_attr( $title ),
				esc_attr( $title_cls )
				);
			}

			// Comment
			if ( $content ) {
				$comment_cls = '';
				if ( $comment_color == $accent ) {
					$comment_cls .= ' accent-color';
				} elseif ( $comment_color ) {
					$comment_css .=  'color:' . $comment_color . ';';
				}
				if ( $comment_font_weight ) $comment_css .= 'font-weight:' . $comment_font_weight . ';';
				if ( $comment_font_size ) $comment_css .= 'font-size:' . intval( $comment_font_size ) . 'px;';
				if ( $comment_line_height ) $comment_css .= 'line-height:' . intval( $comment_line_height ) . 'px;';
				if ( $comment_letter_spacing ) $comment_css .= 'letter-spacing:' . $comment_letter_spacing . 'px;';
				if ( $comment_font_family ) {
					deeper_enqueue_google_font( $comment_font_family );
					$comment_css .= 'font-family:' . $comment_font_family . ';';
				}
				if ( $comment_margin ) $comment_css .= 'margin-bottom:' . intval( $comment_margin ) . 'px;';

				$comment_html = sprintf( 
				'<div class="comment" style="%1$s">
					%2$s
				</div>',
				esc_attr( $comment_css ),
				$content,
				esc_attr( $comment_cls )
				);
			} 

			// Rating
			if ( $image_rating ) {
				$rating_url = wp_get_attachment_image_src( $image_rating, 'full' )[0];
				if( $image_rating_width ) $rating_css .= 'width:' . $image_rating_width . ';';

				$rating_html = sprintf( 
					'<div class="rating">
						<img style ="%1$s" src="%2$s" alt="Star">
					</div>',
					esc_attr( $rating_css ),
					esc_url( $rating_url )
				);
			} 

			// Author name
			if ( $author_name ) {
				$author_name_cls = '';
				if ( $author_name_color == $accent ) {
					$author_name_cls .= ' accent-color';
				} elseif ( $author_name_color ) {
					$author_name_css .=  'color:' . $author_name_color . ';';
				}
				if ( $author_name_font_weight ) $author_name_css .= 'font-weight:' . $author_name_font_weight . ';';
				if ( $author_name_font_size ) $author_name_css .= 'font-size:' . intval( $author_name_font_size ) . 'px;';
				if ( $author_name_line_height ) $author_name_css .= 'line-height:' . intval( $author_name_line_height ) . 'px;';
				if ( $author_name_letter_spacing ) $author_name_css .= 'letter-spacing:' . $author_name_letter_spacing . 'px;';
				if ( $author_name_font_family ) {
					deeper_enqueue_google_font( $author_name_font_family );
					$author_name_css .= 'font-family:' . $author_name_font_family . ';';
				}
				if ( $author_name_margin_top ) $author_name_css .= 'margin-top:' . intval( $author_name_margin_top ) . 'px;';
				if ( $author_name_margin_bottom ) $author_name_css .= 'margin-bottom:' . intval( $author_name_margin_bottom ) . 'px;';

				$author_name_html = sprintf( 
					'<h5 class="author-name" style="%1$s">
						%2$s
					</h5>',
					esc_attr( $author_name_css ),
					esc_attr( $author_name ),
					esc_attr( $author_name_cls )
				);
			} 

			// Author Position
			if ( $author_position ) {
				$author_position_cls = '';
				if ( $author_position_color == $accent ) {
					$author_position_cls .= ' accent-color';
				} elseif ( $author_position_color ) {
					$author_position_css .=  'color:' . $author_position_color . ';';
				}
				if ( $author_position_font_weight ) $author_position_css .= 'font-weight:' . $author_position_font_weight . ';';
				if ( $author_position_font_size ) $author_position_css .= 'font-size:' . intval( $author_position_font_size ) . 'px;';
				if ( $author_position_line_height ) $author_position_css .= 'line-height:' . intval( $author_position_line_height ) . 'px;';
				if ( $author_position_letter_spacing ) $author_position_css .= 'letter-spacing:' . $author_position_letter_spacing . 'px;';
				if ( $author_position_font_family ) {
					deeper_enqueue_google_font( $author_position_font_family );
					$author_position_css .= 'font-family:' . $author_position_font_family . ';';
				}

				if ( $author_position_margin ) 
					$author_position_css .= 'margin-bottom:' . intval( $author_position_margin ) . 'px;';

				$author_position_html = sprintf( 
					'<span class="author-position" style="%1$s">
						%2$s
					</span>',
					esc_attr( $author_position_css ),
					esc_attr( $author_position ),
					esc_attr( $author_position_cls )
				);
			}

			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}
			ob_start(); ?>

			<div class="deeper-testimonial-box <?php echo esc_attr( $cls ); ?>" <?php echo esc_attr( $data ); ?>>
				<?php 
				switch ( $style ) {
					case 'style-1':
						echo $avatar_html; ?>

						<div class="texts" style="<?php echo esc_attr( $text_css ); ?>">
						<?php 
							echo $title_html;
							echo $comment_html;
							echo $rating_html;
						?>
							<div class="author-info">
								<?php
								echo $author_name_html;
								echo $author_position_html;
								?>
							</div><!-- /.author-info -->
						</div><!-- /.texts -->
						<?php
						break;

					case 'style-8':
						echo $avatar_html; ?>

						<div class="texts" style="<?php echo esc_attr( $text_css ); ?>">
						<?php 
							echo $title_html;
							echo $comment_html;
							echo $rating_html;
						?>
							<div class="author-info">
								<?php
								echo $author_name_html;
								echo $author_position_html;
								?>
							</div><!-- /.author-info -->
						</div><!-- /.texts -->
						<?php
						break;

					case 'style-10': ?>

						<div class="texts" style="<?php echo esc_attr( $text_css ); ?>">
						<?php 
							echo $title_html;
							echo $comment_html;
							echo $rating_html;
						?>
						</div><!-- /.texts -->

						<div class="author-info">
								<?php
								echo $author_name_html;
								echo $author_position_html;
								echo $avatar_html;
								?>
							</div><!-- /.author-info -->
						<?php
						break;
					
					default:	?>					
						<div class="texts" style="<?php echo esc_attr( $text_css ); ?>">
						<?php 
							echo $title_html;
							echo $comment_html;
							echo $rating_html;
						?>
							<div class="author-wrap clearfix">
								<?php echo $avatar_html; ?>

								<div class="author-info">
									<?php
									echo $author_name_html;
									echo $author_position_html;
									?>
								</div><!-- /.autho-info -->

								
							</div><!-- /.author-wrap -->
						</div><!-- /.texts -->
						<?php
						break;
				} ?>
			</div><!-- /.deeper-testimonial-box -->

			<?php
			return ob_get_clean();
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Testimonial Box', 'deeper' ),
		        'description' => __( 'Empty space with custom height.', 'deeper' ),
		        'base' => 'deeper_testimonialbox',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/testimonials.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
		        	array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Background Position', 'deeper' ),
						'param_name'  => 'style',
						'value'       => array(
							'Style 1' 		=> 'style-1',
							'Style 2' 		=> 'style-2',
							'Style 3' 		=> 'style-3',
							'Style 4' 		=> 'style-4',
							'Style 5' 		=> 'style-5',
							'Style 6' 		=> 'style-6',
							'Style 7' 		=> 'style-7',
							'Style 8' 		=> 'style-8',
							'Style 9' 		=> 'style-9',
							'Style 10' 		=> 'style-10',
						),
						'std'		=> 'style-1',
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Alignment', 'deeper' ),
						'param_name'  => 'alignment',
						'value'       => array(
							'Left' 			=> 'align-left',
							'Center' 		=> 'align-center',
							'Right' 		=> 'align-right',
						),
						'std'		=> 'align-center',
					),
					// Avatar
					array(
						'type' => 'deeper_heading',
						'text' => esc_html__('Avatar', 'deeper'),
						'param_name' => 'deeper_heading_avatar',
					),
			        array(
						'type' => 'attach_image',
						'heading' => esc_html__('Avatar', 'deeper'),
						'param_name' => 'avatar',
						'value' => '',
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Avatar: Width', 'deeper'),
						'param_name' => 'avatar_width',
						'value' => '',
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Avatar: Rounded', 'deeper'),
						'param_name' => 'avatar_rounded',
						'value' => '',
					),
					// Design
					array(
						'type' => 'attach_image',
						'heading' => esc_html__('Background Image', 'deeper'),
						'param_name' => 'bg_image',
						'value' => '',
						'group' => __( 'Design', 'deeper' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Background Position', 'deeper' ),
						'param_name'  => 'bg_position',
						'value'       => array(
							'Left Top' 		=> 'left top',
							'Right Top' 	=> 'right top',
							'Center Top' 	=> 'center top',
							'Center Center' => 'center center',
							'Center Bottom' => 'center bottom',
							'Left Bottom' 	=> 'left bottom',
							'Right Bottom'  => 'right bottom',
						),
						'std'		=> 'left top',
						'group' => __( 'Design', 'deeper' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Background Repeat', 'deeper' ),
						'param_name'  => 'bg_repeat',
						'value'       => array(
							'No Repeat' => 'no-repeat',
							'Repeat'   	=> 'repeat',
							'Repeat X'  => 'repeat-x',
							'Repeat Y'  => 'repeat-y',
						),
						'std'		=> 'no-repeat',
						'group' => __( 'Design', 'deeper' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Background Size', 'deeper' ),
						'param_name'  => 'bg_size',
						'value'       => array(
							'Auto' 	   => '',
							'Cover'        => 'cover',
						),
						'std'		=> '',
						'group' => __( 'Design', 'deeper' ),
					),
					array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Background Color', 'deeper'),
						'param_name' => 'bg_color',
						'value' => '',
						'group' => __( 'Design', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Rounded', 'deeper'),
						'param_name' => 'rounded',
						'value' => '',
						'group' => __( 'Design', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Shadow', 'deeper'),
						'param_name' => 'shadow',
						'value' => '',
						'group' => __( 'Design', 'deeper' ),
					),
					// Content
					array(
						'type' => 'deeper_heading',
						'holder' => 'div',
						'text' => esc_html__('Content', 'deeper'),
						'param_name' => 'deeper_heading_content',
						'group' => __( 'Content', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Title', 'deeper'),
						'param_name' => 'title',
						'holder'	=> 'div',
						'value' => '',
						'group' => __( 'Content', 'deeper' ),
					),
					array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Title Color', 'deeper'),
						'param_name' => 'title_color',
						'group' => __( 'Content', 'deeper' ),
						'value' => '',
					),
					array(
						'type' => 'textarea_html',
						'heading' => esc_html__('Comment', 'deeper'),
						'param_name' => 'content',
						'group' => __( 'Content', 'deeper' ),
						'value' => '',
					),
					array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Comment Color', 'deeper'),
						'param_name' => 'comment_color',
						'group' => __( 'Content', 'deeper' ),
						'value' => '',
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Author Name', 'deeper'),
						'param_name' => 'author_name',
						'group' => __( 'Content', 'deeper' ),
						'value' => '',
					),
					array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Author Name Color', 'deeper'),
						'param_name' => 'author_name_color',
						'group' => __( 'Content', 'deeper' ),
						'value' => '',
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Author Position', 'deeper'),
						'param_name' => 'author_position',
						'group' => __( 'Content', 'deeper' ),
						'value' => '',
					),
					array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Author Position Color', 'deeper'),
						'param_name' => 'author_position_color',
						'group' => __( 'Content', 'deeper' ),
						'value' => '',
					),
					array(
						'type' => 'attach_image',
						'heading' => esc_html__('Rating Image', 'deeper'),
						'param_name' => 'image_rating',
						'value' => '',
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Image Rating Width', 'deeper'),
						'param_name' => 'image_rating_width',
						'value' => '',
					),
					// Typography
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Title', 'deeper' ),
						'param_name' => 'title_typograpy',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Title: Font Family', 'deeper' ),
						'param_name' => 'title_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Title: Font Weight', 'deeper' ),
						'param_name' => 'title_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Title: Font Size', 'deeper' ),
						'param_name' => 'title_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Title: Line Height', 'deeper' ),
						'param_name' => 'title_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Title: Letter Spacing', 'deeper' ),
						'param_name' => 'title_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
				  	array(
						'type' => 'deeper_heading',
						'text' => __( 'Comment', 'deeper' ),
						'param_name' => 'comment_typograpy',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Comment: Font Family', 'deeper' ),
						'param_name' => 'comment_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Comment: Font Weight', 'deeper' ),
						'param_name' => 'comment_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Comment: Font Size', 'deeper' ),
						'param_name' => 'comment_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Comment: Line Height', 'deeper' ),
						'param_name' => 'comment_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Comment: Letter Spacing', 'deeper' ),
						'param_name' => 'comment_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
				  	array(
						'type' => 'deeper_heading',
						'text' => __( 'Author Name', 'deeper' ),
						'param_name' => 'author_name_typograpy',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Author Name: Font Family', 'deeper' ),
						'param_name' => 'author_name_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Author Name: Font Weight', 'deeper' ),
						'param_name' => 'author_name_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Author Name: Font Size', 'deeper' ),
						'param_name' => 'author_name_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Author Name: Line Height', 'deeper' ),
						'param_name' => 'author_name_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Author Name: Letter Spacing', 'deeper' ),
						'param_name' => 'author_name_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
				  	array(
						'type' => 'deeper_heading',
						'text' => __( 'Author Position', 'deeper' ),
						'param_name' => 'author_position_typograpy',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Author Position: Font Family', 'deeper' ),
						'param_name' => 'author_position_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Author Position: Font Weight', 'deeper' ),
						'param_name' => 'author_position_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Author Position: Font Size', 'deeper' ),
						'param_name' => 'author_position_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Author Position: Line Height', 'deeper' ),
						'param_name' => 'author_position_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Author Position: Letter Spacing', 'deeper' ),
						'param_name' => 'author_position_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
					// Spacing
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Avatar: Margin', 'deeper'),
						'param_name' => 'avatar_margin',
						'value' => '',
						'description'	=> esc_html__('Top Right Bottom Left. Ex: 0px 0px 1px 0px', 'deeper'),
						'group' => esc_html__( 'Spacing', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Content: Padding', 'deeper'),
						'param_name' => 'content_padding',
						'value' => '',
						'description'	=> esc_html__('Top Right Bottom Left. Ex: 0px 0px 1px 0px', 'deeper'),
						'group' => esc_html__( 'Spacing', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Content: Margin', 'deeper'),
						'param_name' => 'content_margin',
						'value' => '',
						'description'	=> esc_html__('Top Right Bottom Left. Ex: 0px 0px 1px 0px', 'deeper'),
						'group' => esc_html__( 'Spacing', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Title: Margin Bottom', 'deeper'),
						'param_name' => 'title_margin',
						'value' => '',
						'group' => esc_html__( 'Spacing', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Comment: Margin Bottom', 'deeper'),
						'param_name' => 'comment_margin',
						'value' => '',
						'group' => esc_html__( 'Spacing', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Author Name: Margin Top', 'deeper'),
						'param_name' => 'author_name_margin_top',
						'value' => '',
						'group' => esc_html__( 'Spacing', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Author Name: Margin Bottom', 'deeper'),
						'param_name' => 'author_name_margin_bottom',
						'value' => '',
						'group' => esc_html__( 'Spacing', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Author Position: Margin Bottom', 'deeper'),
						'param_name' => 'author_position_margin',
						'value' => '',
						'group' => esc_html__( 'Spacing', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Extra Class', 'deeper'),
						'param_name' => 'class',
						'value' => '',
					),
					// Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		        )
		    );
		}
	}

	new Deeper_Testimonial_Box_Shortcode;
}
