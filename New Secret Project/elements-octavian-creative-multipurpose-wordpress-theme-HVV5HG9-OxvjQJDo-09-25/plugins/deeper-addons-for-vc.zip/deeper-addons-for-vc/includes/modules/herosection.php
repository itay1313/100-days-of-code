<?php
/**
 * Content Box shortcode for Visual Composer
 *
 * @package Deeper Addons
 */
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_deeper_herosection extends WPBakeryShortCodesContainer {}
}

if ( ! class_exists( 'Deeper_Hero_Section_Shortcode' ) ) {

	class Deeper_Hero_Section_Shortcode {
		// Constructor
		public function __construct() {

			// Add shortcode
			add_shortcode( 'deeper_herosection', array( 'Deeper_Hero_Section_Shortcode', 'output' ) );
			
			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_herosection', array( 'Deeper_Hero_Section_Shortcode', 'map' ) );
			}	
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			
			extract( shortcode_atts( array(
			    'class' => '',
			), $atts ) );

			$cls = '';
			if ( $class ) $cls .= ' ' . $class;


			return sprintf(
				'<div class="deeper-hero %2$s">
					<div class="hero-inner">
						%1$s
					</div>
				</div>',
				do_shortcode( $content ),
				$cls
			);					
		}	

		// Map shortcode to VC
		public static function map() {
		    return array(
				'name' => esc_html__('Hero Section', 'deeper'),
				'description' => esc_html__('Hero Section.', 'deeper'),
				'base' => 'herosection',
				'weight'	=>	180,
				'icon' => plugins_url( '../../assets/icon/herosection.png', __FILE__ ),
				'as_parent' => array('except' => 'deeper_herosection'),
				'controls' => 'full',
				'show_settings_on_create' => true,
				'category' => esc_html__('Deeper Addons', 'deeper'),
				'js_view' => 'VcColumnView',
				'params' => array(
					array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'class',
						'value' => '',
			        ),
		        )
		    );
		}
	}
	new Deeper_Hero_Section_Shortcode;
}

