<?php
/**
 * Fancy_Text shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Fancy_Text_Shortcode' ) ) {

	class Deeper_Fancy_Text_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_fancytext', array( 'Deeper_Fancy_Text_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_fancytext', array( 'Deeper_Fancy_Text_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$wrap_css = $cls = $css = $texts = '';

			$text_css = $prefix_css = $suffix_css = '';
			$fancy_html = $fancy_wrap_css = $fancy_css = $fancy_text = '';
			$min = $max = '';

			extract( shortcode_atts( array(
			    'alignment' => 'text-center',
			    'animation' => 'scroll',
			    'text1' => '',
			    'text2' => '',
			    'text3' => '',
			    'text4' => '',
			    'text5' => '',
			    'prefix_text' => '',
			    'suffix_text' => '',
			    'text_color' => '',
			    'prefix_color' => '',
			    'suffix_color' => '',
			    'font_family' => 'Default',
			    'font_weight' => 'Default',
			    'font_size' => '65px',
			    'line_height' => '',
			    'font_size_mobile' => '50',
			), $atts ) );
			wp_enqueue_script( 'fittext' );
			$cls = $alignment;

			if ( $text_color ) $css .= 'color:'. $text_color .';';
			if ( $font_weight != 'Default' ) $css .= 'font-weight:'. $font_weight .';';
			if ( $font_family != 'Default' ) {
				deeper_enqueue_google_font( $font_family );
				$css .= 'font-family:'. $font_family .';';
			}

			if ( $animation == 'scroll' ) {

				if ( $font_size ) {
					$css .= 'font-size:'. intval( $font_size ) .'px;height:'. intval( $font_size ) .'px;line-height:'. intval( $font_size ) .'px;';
					$wrap_css .= 'height:'. intval( $font_size ) .'px;';
				}

				if ( $font_size ) $max = intval( $font_size );
				if ( $font_size_mobile ) $min = intval( $font_size_mobile );

				if ( $text1 ) $texts = '<div class="heading" style="'. $css .'">'. $text1 .'</div>';
				if ( $text2 ) $texts .= '<div class="heading" style="'. $css .'">'. $text2 .'</div>';
				if ( $text3 ) $texts .= '<div class="heading" style="'. $css .'">'. $text3 .'</div>';
				if ( $text4 ) $texts .= '<div class="heading" style="'. $css .'">'. $text4 .'</div>';
				if ( $text5 ) $texts .= '<div class="heading" style="'. $css .'">'. $text5 .'</div>';

				return sprintf(
					'<div class="deeper-fancy-text scroll %2$s" style="%3$s" data-min="%4$s" data-max="%5$s">
				        %1$s
				    </div>',
				    $texts,
					$cls,
					$wrap_css,
					$min,
					$max
				);
			}

			if ( $animation == 'fade' ) {
				wp_enqueue_script( 'animatedHeading' );

				if ( $font_size ) $css .= 'font-size:'. intval( $font_size ) .'px;line-height:'. intval( $font_size ) .'px;';
				if ( $font_size_mobile ) $cls .= ' mobi-size-'. $font_size_mobile;

				if ( $text1 ) $texts = '<b class="is-visible">'. $text1 .'</b>';
				if ( $text2 ) $texts .= '<b>'. $text2 .'</b>';
				if ( $text3 ) $texts .= '<b>'. $text3 .'</b>';
				if ( $text4 ) $texts .= '<b>'. $text4 .'</b>';
				if ( $text5 ) $texts .= '<b>'. $text5 .'</b>';

				return sprintf(
					'<div class="deeper-fancy-text zoom %3$s" style="%2$s">
						<div class="ah-headline" ><span class="ah-words-wrapper">
				        %1$s
				        </span></div>
				    </div>',
				    $texts,
					$css,
					$cls
				);
			}

			if ( $animation == 'typed' ) {
				wp_enqueue_script( 'typed' );

				if ( $font_size_mobile ) {
					$min = intval( $font_size_mobile );
					if ( $font_size ) $max = intval( $font_size );
				} else {
					if ( $font_size ) $css .= 'font-size:'. intval( $font_size ) .'px;';
				}

				if ( $line_height ) $css .= 'line-height:'. intval( $line_height ) .'px;';

				if ( $prefix_color ) $prefix_css .= 'color:'. $prefix_color .';';
				if ( $suffix_color )$suffix_css .= 'color:'. $suffix_color .';';

				if ( $text1 ) $texts .= $text1 .',';
				if ( $text2 ) $texts .= $text2 .',';
				if ( $text3 ) $texts .= $text3 .',';
				if ( $text4 ) $texts .= $text4 .',';
				if ( $text5 ) $texts .= $text5 .',';
				$texts = substr( $texts, 0, -1 );

				return sprintf(
					'<div class="deeper-fancy-text typed %4$s" data-fancy="%1$s" data-mfont="%2$s" data-font="%3$s">
				        <div class="heading" style="%5$s"><span style="%7$s">%6$s</span> <span class="text"></span> <span style="%9$s">%8$s</span></div>
				    </div>',
					$texts,
					$min,
					$max,
					$cls,
					$css,
					$prefix_text,
					$prefix_css,
					$suffix_text,
					$suffix_css
				);
			}

		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Fancy_Text', 'deeper' ),
		        'description' => __( 'Empty space with custom height.', 'deeper' ),
		        'base' => 'deeper_fancytext',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/fancytext.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
			        array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Text Alignment', 'deeper' ),
						'param_name' => 'alignment',
						'value'      => array(
							'Left' => '',
							'Center' => 'text-center',
							'Right' => 'text-right',
						),
						'std'		=> 'text-center',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation',
						'value'      => array(
							'Scrolling' => 'scroll',
							'Typing' => 'typed',
							'Fade' => 'fade',
						),
						'std'		=> 'scroll',
					),
					array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => esc_html__( 'Text 1 (Optional)', 'deeper' ),
						'param_name' => 'text1',
					),
					array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => esc_html__( 'Text 2 (Optional)', 'deeper' ),
						'param_name' => 'text2',
					),
					array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => esc_html__( 'Text 3 (Optional)', 'deeper' ),
						'param_name' => 'text3',
					),
					array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => esc_html__( 'Text 4 (Optional)', 'deeper' ),
						'param_name' => 'text4',
					),
					array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => esc_html__( 'Text 5 (Optional)', 'deeper' ),
						'param_name' => 'text5',
					),
					array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => esc_html__( 'Prefix Text (Optional)', 'deeper' ),
						'param_name' => 'prefix_text',
						'group' => esc_html__( 'Prefix & Suffix', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'typed' ),
					),
					array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => esc_html__( 'Suffix Text (Optional)', 'deeper' ),
						'param_name' => 'suffix_text',
						'group' => esc_html__( 'Prefix & Suffix', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'typed' ),
					),
		            array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Text Color', 'deeper'),
						'param_name' => 'text_color',
						'value' => '',
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Prefix Text Color', 'deeper'),
						'param_name' => 'prefix_color',
						'value' => '',
						'group' => esc_html__( 'Prefix & Suffix', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'typed' ),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Suffix Text Color', 'deeper'),
						'param_name' => 'suffix_color',
						'value' => '',
						'group' => esc_html__( 'Prefix & Suffix', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'typed' ),
		            ),
			        // Typography
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Font Family', 'deeper' ),
						'param_name' => 'font_family',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Font Weight', 'deeper' ),
						'param_name' => 'font_weight',
						'value'      => array(
							'Default'		=> 'Default',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => esc_html__( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Font Size', 'deeper'),
						'param_name' => 'font_size',
						'value' => '65px',
						'group' => esc_html__( 'Typography', 'deeper' ),
			        ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Line Height', 'deeper'),
						'param_name' => 'line_height',
						'value' => '',
						'group' => esc_html__( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'typed' ),
		            ),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Font Size on Mobile', 'deeper' ),
						'param_name' => 'font_size_mobile',
						'value'      => array(
							'Disable' => '',
							'15px' => '15',
							'20px' => '20',
							'25px' => '25',
							'30px' => '30',
							'35px' => '35',
							'40px' => '40',
							'45px' => '45',
							'50px' => '50',
							'55px' => '55',
							'60px' => '60',
						),
						'std'		=> '50',
						'group' => esc_html__( 'Typography', 'deeper' ),
					),
		        )
		    );
		}
	}

	new Deeper_Fancy_Text_Shortcode;
}
