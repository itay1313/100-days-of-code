<?php
/**
 * Contact_Form shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Contact_Form_Shortcode' ) ) {

	class Deeper_Contact_Form_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_contactform', array( 'Deeper_Contact_Form_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_contactform', array( 'Deeper_Contact_Form_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$cls = '';

			extract( shortcode_atts( array(
				'style' => 'style-1',
				'align' => 'align-center',
				'form_id' => '',
				'background' => '',
				'button' => 'accent',
				'width'	=> '',
				'class' => '',
			), $atts ) );
			$css = '';
			$cls .= 'form-' . $form_id . ' ' . $background . ' btn-'. $button . ' ' . $style . ' ' . $align;
			if ( $class ) $cls .= ' ' . $class;
			if ( $width ) {
				$css .= 'max-width:' . $width . ';';
				if ( $align == 'align-center' ) $css .= 'margin:0 auto;';
			} 

			return sprintf( 
				'<div class="deeper-cf7 %2$s" style="%3$s">%1$s</div>',
				do_shortcode( '[contact-form-7 id="'. $form_id .'"]' ),
				$cls,
				$css
			);
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Contact_Form', 'deeper' ),
		        'description' => __( 'Displays Form Contact.', 'deeper' ),
		        'base' => 'deeper_contactform',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/subscibe.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
		   //      	array(
					// 	'type'       => 'dropdown',
					// 	'heading'    => esc_html__( 'Style', 'deeper' ),
					// 	'param_name' => 'style',
					// 	'value'      => array(
					// 		'Style 1' => 'style-1',
					// 		'Style 2' => 'style-2',
					// 	),
					// 	'std'		=> 'style-1',
					// ),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Alignment', 'deeper' ),
						'param_name' => 'align',
						'value'      => array(
							'Left' => 'align-left',
							'Center' => 'align-center',
							'Right' => 'align-right',
						),
						'std'		=> 'align-center',
					),
			        array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Form', 'deeper' ),
						'param_name' => 'form_id',
						'std' => '',
						'value'      =>  deeper_list_contact_form_7(),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Input Background', 'deeper' ),
						'param_name' => 'background',
						'value'      => array(
							'Default' => '',
							'White' => 'input-white',
							'Black' => 'input-black',
						),
						'std'		=> '',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Button', 'deeper' ),
						'param_name' => 'button',
						'value'      => array(
							'Button Accent' => 'accent',
							'Button Light' => 'light',
							'Button Blue' => 'blue-light',
							'Button Green' => 'green',
							'Button Cyan' => 'cyan',
							'Button Red' => 'red',
							'Button Gradient Orange' => 'gradient-orange',
							'Button Gradient Orange 2' => 'gradient-orange2',
							'Button Gradient Red' => 'gradient-red',
							'Button Gradient Blue' => 'gradient-blue',
						),
						'std'		=> 'accent',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Max Width', 'deeper' ),
						'param_name' => 'width',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Extra Classes', 'deeper' ),
						'param_name' => 'class',
						'value'      => '',
					),
		        )
		    );
		}
	}

	new Deeper_Contact_Form_Shortcode;
}
