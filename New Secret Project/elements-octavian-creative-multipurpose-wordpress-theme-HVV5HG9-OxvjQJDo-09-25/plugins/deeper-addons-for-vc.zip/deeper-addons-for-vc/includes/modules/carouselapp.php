<?php
/**
 * Carousel_App shortcode for Visual Composer
 *
 * @package Deeper Addons
 */
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_deeper_carouselapp extends WPBakeryShortCodesContainer {}
}

if ( ! class_exists( 'Deeper_Carousel_App_Shortcode' ) ) {

	class Deeper_Carousel_App_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_carouselapp', array( 'Deeper_Carousel_App_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_carouselapp', array( 'Deeper_Carousel_App_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$data = '';
			$config = array();

			extract( shortcode_atts( array(
				'gap'			=> '40',
				'autoplay' => 'false',
				'center' => 'center',
				'full_screen' => '',
				'autoplay_speed' => 3000,
			    'fullaside' => 'false',
			    'loop' => 'true',
			    'groupcell' => 'false',
				
				'column' => '1',
				'column2' => '1',
				'column3' => '1',
				'column4' => '1',
				
				'class'	=> '',
				// Arrows
				'show_arrows' => '',
				'arrowsvg' => 'svg1',
				'arrows_position' => 'middle',
				'arrows_size' => 'arrows-medium',
				'arrows_offset' => 'arrow-offset-0',
				// Bullets
				'show_bullets' => '',
				'bullets_offset' => 'bullet-offset-0',
				'bullets_pos' => 'bullet-center',
				// Animation
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',

			), $atts ) );

			wp_enqueue_script( 'flickity' );

			$cls = ' column-' . $column . ' column2-' . $column2 . ' column3-' . $column3 . ' column4-' . $column4 .  ' gap-' . $gap;
			if ( $class ) $cls .= ' ' . $class;
			if ( $full_screen ) $cls .= ' ' . $full_screen;

			$config['cellAlign'] = $center;
			$config['autoPlay'] = $autoplay == 'true' ? abs( (int) $autoplay_speed ) : false;
			$config['fullAside'] = $fullaside == 'true' ? true : false;
			$config['wrapAround'] = false;
			$config['groupCells'] = false;
			$config['initialIndex'] = 2;
			
			// Arrows
			if ( $show_arrows ) {
				$cls .= ' has-arrows arrow-' . $arrows_position . ' ' . $arrows_offset . ' ' . $arrows_size;
				$config['prevNextButtons'] = true;
				$config['arrowShapeStyle'] = $arrowsvg;
			}

			// Bullets
			if ( $show_bullets ) {
				$cls .= ' has-bullets ' . $bullets_offset . ' ' . $bullets_pos;
				$config['pageDots'] = true;
			}

			if ( $config )
				$data = 'data-config=\'' . json_encode( $config ) . '\'';

			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}

			ob_start(); ?>
			<div class="deeper-app-carousel">
				<div class="carousel-outer">
					<div class="deeper-carousel-box app-carousel <?php echo $cls; ?>" <?php echo $data; ?> data-inviewport="yes">
						<?php echo do_shortcode( $content ); ?>					
					</div><!-- /.deeper-carousel-box -->

					<div class="flickity-phone">
						<div class="phone-top">
							<img src="<?php echo get_template_directory_uri() . '/assets/img/iphone-top.png'; ?>" alt="Image">
						</div>
						<div class="phone-bottom">
							<img src="<?php echo get_template_directory_uri() . '/assets/img/iphone-bottom.png'; ?>" alt="Image">
						</div>
						<div class="phone-left">
							<img src="<?php echo get_template_directory_uri() . '/assets/img/iphone-left.png'; ?>" alt="Image">
						</div>
						<div class="phone-right">
							<img src="<?php echo get_template_directory_uri() . '/assets/img/iphone-right.png'; ?>" alt="Image">
						</div>
					</div>
				</div>
			</div>

			<?php
			return ob_get_clean();
		}

		// Map shortcode to VC
		public static function map() {
			return array(
				'name' => esc_html__('Carousel App', 'deeper'),
				'base' => 'carouselapp',
				'weight'	=>	180,
				'icon' => plugins_url( '../../assets/icon/carouselbox.png', __FILE__ ),
				'as_parent' => array('except' => 'deeper_carouselapp'),
				'controls' => 'full',
				'show_settings_on_create' => true,
				'category' => esc_html__('Deeper Addons', 'deeper'),
				'js_view' => 'VcColumnView',
			    'params' => array(
			    	array(
						'type' => 'textfield',
						'heading' => esc_html__('Extra Class', 'deeper'),
						'param_name' => 'class',
						'value' => '',
		            ),
			    	// Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
			    )
			);
		}
	}

	new Deeper_Carousel_App_Shortcode;
}



