<?php
/**
 * Slider_Nav shortcode for Visual Composer
 *
 * @package Deeper Addons
 */
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_deeper_slidernav extends WPBakeryShortCodesContainer {}
}

if ( ! class_exists( 'Deeper_Slider_Nav_Shortcode' ) ) {

	class Deeper_Slider_Nav_Shortcode {
		// Constructor
		public function __construct() {

			// Add shortcode
			add_shortcode( 'deeper_slidernav', array( 'Deeper_Slider_Nav_Shortcode', 'output' ) );
			
			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_slidernav', array( 'Deeper_Slider_Nav_Shortcode', 'map' ) );
			}	
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			extract(shortcode_atts(array(
	        ), $atts));

	        return sprintf( 
	        	'<div class="slick-nav-item">
                	%1$s
     	    	</div>',
     	    	do_shortcode( $content )
	        	);  				
		}	

		// Map shortcode to VC
		public static function map() {
		    return array(
	        	"name" => esc_html__("Slider Navigation (Optional)", 'deeper'),
				'base' => 'slidernav',
				'weight'	=>	180,
				'icon' => plugins_url( '../../assets/icon/tabs.png', __FILE__ ),
				'as_child' => array('only' => 'deeper_slidercontent'),
				'as_parent' => array('except' => 'deeper_slider', 'deeper_slidernav', 'deeper_slidercontent'),
				'controls' => 'full',
				'show_settings_on_create' => true,
				'category' => esc_html__('Deeper Addons', 'deeper'),
				'js_view' => 'VcColumnView',
		    );
		}
	}
}

new Deeper_Slider_Nav_Shortcode;