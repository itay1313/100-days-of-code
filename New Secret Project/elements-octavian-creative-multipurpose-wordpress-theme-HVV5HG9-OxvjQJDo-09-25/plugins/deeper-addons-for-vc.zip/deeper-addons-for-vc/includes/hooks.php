<?php

// Add new image size
function deeper_custom_image_sizes() {
	add_image_size( 'deeper-std1', 570, 420, true );
	add_image_size( 'deeper-std2', 570, 340, true );
	add_image_size( 'deeper-std3', 370, 470, true );
	add_image_size( 'deeper-std4', 370, 430, true );
	add_image_size( 'deeper-std5', 370, 370, true );
	add_image_size( 'deeper-std6', 370, 270, true );
}
add_action( 'after_setup_theme', 'deeper_custom_image_sizes' );

// Style for VC
function deeper_vc_style() {
    $url = DEEPER_URL . 'assets/css/vc_custom.css';
    echo "<link rel='stylesheet' type='text/css' href='$url' />\n";
}

add_action('admin_head', 'deeper_vc_style');

// Add socials on user setting page
function deeper_socials_user_contact() {
	$user_contact['user_facebook']   = esc_html( 'Facebook URL' );
	$user_contact['user_twitter'] = esc_html( 'Twitter URL' );
	$user_contact['user_linkedin'] = esc_html( 'LinkedIn URL' );
	$user_contact['user_pinterest'] = esc_html( 'Pinterest URL' );
	$user_contact['user_instagram'] = esc_html( 'Instagram URL' );

	return $user_contact;
}

add_filter( 'user_contactmethods', 'deeper_socials_user_contact' );
