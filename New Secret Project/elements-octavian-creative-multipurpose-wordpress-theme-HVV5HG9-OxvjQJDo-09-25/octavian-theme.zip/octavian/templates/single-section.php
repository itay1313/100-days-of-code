<?php
/**
 * Header / Info
 *
 * @package octavian
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$args = array(
    'post_type' => 'section',
);

$query = new WP_Query( $args );
if ( ! $query->have_posts() ) { return; }


if ( $query->have_posts() ) : 
    while ( $query->have_posts() ) : $query->the_post(); 
        if ( ( octavian_is_woocommerce_shop() && octavian_metabox('single_section_shop') ) ||
             ( is_singular( 'product' ) && octavian_metabox('single_section_shop_single') ) ||
             ( is_singular( 'post' ) && octavian_metabox('single_section_post') ) ||
             ( is_singular( 'project' ) && octavian_metabox('single_section_project') ) ) {
            wp_register_style( 'octavian-custom-vc', false );
            wp_enqueue_style('octavian-custom-vc');
            $shortcodes_custom_css = get_post_meta( $id, '_wpb_shortcodes_custom_css', true );
            wp_add_inline_style( 'octavian-custom-vc', $shortcodes_custom_css );
            the_content();
        }
    endwhile;
endif; 
wp_reset_postdata(); 
