<?php
/**
 * Header / Button
 *
 * @package octavian
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$cls = octavian_get_mod( 'header_button_extra', '' );

if ( octavian_metabox( 'header_button_extra' ) ) $cls = octavian_metabox( 'header_button_extra' );
// Get defaults from Customizer
$text = octavian_get_mod( 'header_button_text', '' );
$url = octavian_get_mod( 'header_button_url', '' );

if ( $text && $url ) : ?>
	<div class="header-button <?php echo esc_attr( $cls ); ?>">
	    <?php
	    if ( $text && $url ) : ?>
	        <a href="<?php echo esc_url( do_shortcode( $url ) ); ?>">
	            <?php echo do_shortcode( $text ); ?>
	        </a>
	    <?php endif; ?>
	</div><!-- /.header-info -->
<?php endif; ?>