<?php
/**
 * Header
 *
 * @package octavian
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
$cls ='';

// Get header style
$cls = octavian_get_mod( 'header_class' );
$header_style = octavian_get_mod( 'header_site_style', 'style-2' );
if ( is_page() && octavian_metabox( 'header_style' ) )
	$header_style = octavian_metabox( 'header_style' );

// Custom style for main header area
$header_css = '';
if ( is_page() && $bg = octavian_metabox( 'header_background' ) )
	$header_css = 'background-color: '. $bg .';';

// Extra class
if ( octavian_metabox( 'header_extra' ) ) $cls = octavian_metabox( 'header_extra' );
?>

<?php get_template_part( 'templates/header-extra-nav' ); ?>

<header id="site-header" class="<?php echo esc_attr( $cls ); ?>" style="<?php echo esc_attr( $header_css ); ?>">
    <div class="octavian-container">
    	<div class="site-header-inner">
            <?php get_template_part( 'templates/header-logo'); ?>
            <?php get_template_part( 'templates/header-info'); ?>
            <div class="wrap-inner">
        		<?php 
                get_template_part( 'templates/header-menu');       
        		get_template_part( 'templates/header-button');
        		?>
            </div><!-- /.wrap-inner -->
    	</div><!-- /.site-header-inner -->
    </div><!-- /.octavian-container -->
</header><!-- /#site-header -->
