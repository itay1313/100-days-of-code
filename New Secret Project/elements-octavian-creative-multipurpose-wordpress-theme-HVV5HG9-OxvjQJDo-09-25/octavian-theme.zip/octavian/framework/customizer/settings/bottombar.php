<?php
/**
 * Bottom Bar setting for Customizer
 *
 * @package octavian
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Bottom Bar General
$this->sections['octavian_bottombar_general'] = array(
	'title' => esc_html__( 'General', 'octavian' ),
	'panel' => 'octavian_bottombar',
	'settings' => array(
		array(
			'id' => 'bottom_bar',
			'default' => true,
			'control' => array(
				'label' => esc_html__( 'Enable', 'octavian' ),
				'type' => 'checkbox',
			),
		),
		array(
			'id' => 'bottom_bar_style',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Style', 'octavian' ),
				'type' => 'select',
				'active_callback' => 'octavian_cac_has_bottombar',
				'choices' => array(
					''  	  => esc_html__( 'All Content', 'octavian' ),	
					'style-1' => esc_html__( 'Only Copyright', 'octavian' ),
					'style-2' => esc_html__( 'Logo + Copyright', 'octavian' ),
				),
			),
		),
		array(
			'id' => 'bottom_copyright',
			'transport' => 'postMessage',
			'default' => '&copy; Octavian - Creative Multipurpose WordPress Theme.',
			'control' => array(
				'label' => esc_html__( 'Copyright', 'octavian' ),
				'type' => 'octavian_textarea',
				'active_callback' => 'octavian_cac_has_bottombar',
			),
		),
		array(
			'id' => 'bottom_padding',
			'transport' => 'postMessage',
			'control' =>  array(
				'type' => 'text',
				'label' => esc_html__( 'Padding', 'octavian' ),
				'description' => esc_html__( 'Top Right Bottom Left.', 'octavian' ),
				'active_callback'=> 'octavian_cac_has_bottombar',
			),
			'inline_css' => array(
				'target' => '#bottom .bottom-bar-inner-wrap',
				'alter' => 'padding',
			),
		),
		array(
			'id' => 'bottom_background',
			'transport' => 'postMessage',
			'control' =>  array(
				'type' => 'color',
				'label' => esc_html__( 'Background', 'octavian' ),
				'active_callback'=> 'octavian_cac_has_bottombar',
			),
			'inline_css' => array(
				'target' => '#bottom',
				'alter' => 'background',
			),
		),
		array(
			'id' => 'bottom_background_img',
			'control' => array(
				'type' => 'image',
				'label' => esc_html__( 'Background Image', 'octavian' ),
				'active_callback' => 'octavian_cac_has_bottombar',
			),
		),
		array(
			'id' => 'bottom_background_img_style',
			'default' => 'repeat',
			'control' => array(
				'label' => esc_html__( 'Background Image Style', 'octavian' ),
				'type'  => 'image',
				'type'  => 'select',
				'choices' => array(
					''             => esc_html__( 'Default', 'octavian' ),
					'cover'        => esc_html__( 'Cover', 'octavian' ),
					'center-top'        => esc_html__( 'Center Top', 'octavian' ),
					'fixed-top'    => esc_html__( 'Fixed Top', 'octavian' ),
					'fixed'        => esc_html__( 'Fixed Center', 'octavian' ),
					'fixed-bottom' => esc_html__( 'Fixed Bottom', 'octavian' ),
					'repeat'       => esc_html__( 'Repeat', 'octavian' ),
					'repeat-x'     => esc_html__( 'Repeat-x', 'octavian' ),
					'repeat-y'     => esc_html__( 'Repeat-y', 'octavian' ),
				),
				'active_callback' => 'octavian_cac_has_bottombar',
			),
		),
		array(
			'id' => 'bottom_color',
			'transport' => 'postMessage',
			'control' =>  array(
				'type' => 'color',
				'label' => esc_html__( 'Color', 'octavian' ),
				'active_callback'=> 'octavian_cac_has_bottombar',
			),
			'inline_css' => array(
				'target' => '#bottom',
				'alter' => 'color',
			),
		),
		array(
			'id' => 'line_color',
			'transport' => 'postMessage',
			'control' =>  array(
				'type' => 'color',
				'label' => esc_html__( 'Line Color', 'octavian' ),
				'active_callback'=> 'octavian_cac_has_bottombar',
			),
			'inline_css' => array(
				'target' => '#bottom:before',
				'alter' => 'background-color',
			),
		),
	),
);

// Bottom Logo
$this->sections['octavian_bottom_logo'] = array(
	'title' => esc_html__( 'Logo', 'octavian' ),
	'panel' => 'octavian_bottombar',
	'settings' => array(
		array(
			'id' => 'bottom_custom_logo',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Logo Image', 'octavian' ),
				'type' => 'image',
			),
		),
		array(
			'id' => 'bottom_logo_width',
			'control' => array(
				'label' => esc_html__( 'Logo Width', 'octavian' ),
				'type' => 'text',
			),
		),
	)
);
