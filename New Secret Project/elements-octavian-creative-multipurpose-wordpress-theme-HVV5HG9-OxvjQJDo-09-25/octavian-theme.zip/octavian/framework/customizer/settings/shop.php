<?php
/**
 * Shop setting for Customizer
 *
 * @package octavian
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Main Shop
$this->sections['octavian_shop_general'] = array(
	'title' => esc_html__( 'Main Shop', 'octavian' ),
	'panel' => 'octavian_shop',
	'settings' => array(
		array(
			'id' => 'shop_layout_position',
			'default' => 'no-sidebar',
			'control' => array(
				'label' => esc_html__( 'Shop Layout Position', 'octavian' ),
				'type' => 'select',
				'choices' => array(
					'sidebar-right' => esc_html__( 'Right Sidebar', 'octavian' ),
					'sidebar-left'  => esc_html__( 'Left Sidebar', 'octavian' ),
					'no-sidebar'    => esc_html__( 'No Sidebar', 'octavian' ),
				),
				'desc' => esc_html__( 'Specify layout for main shop page.', 'octavian' ),
				'active_callback' => 'octavian_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_featured_title',
			'default' => esc_html__( 'Our Shop', 'octavian' ),
			'control' => array(
				'label' => esc_html__( 'Shop: Featured Title', 'octavian' ),
				'type' => 'octavian_textarea',
				'active_callback' => 'octavian_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_featured_title_background_img',
			'control' => array(
				'type' => 'image',
				'label' => esc_html__( 'Shop: Featured Title Background', 'octavian' ),
				'active_callback' => 'octavian_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_products_per_page',
			'default' => 6,
			'control' => array(
				'label' => esc_html__( 'Products Per Page', 'octavian' ),
				'type' => 'number',
				'active_callback' => 'octavian_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_columns',
			'default' => '3',
			'control' => array(
				'label' => esc_html__( 'Shop Columns', 'octavian' ),
				'type' => 'select',
				'choices' => array(
					'2' => '2',
					'3' => '3',
					'4' => '4',
				),
				'active_callback' => 'octavian_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_item_bottom_margin',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Item Bottom Margin', 'octavian' ),
				'description' => esc_html__( 'Example: 30px.', 'octavian' ),
				'active_callback' => 'octavian_cac_has_woo',
			),
			'inline_css' => array(
				'target' => '.products li',
				'alter' => 'margin-top',
			),
		),
	),
);

// Single Shop
$this->sections['octavian_single_shop_general'] = array(
	'title' => esc_html__( 'Single Shop', 'octavian' ),
	'panel' => 'octavian_shop',
	'settings' => array(
		array(
			'id' => 'shop_single_layout_position',
			'default' => 'no-sidebar',
			'control' => array(
				'label' => esc_html__( 'Shop Single Layout Position', 'octavian' ),
				'type' => 'select',
				'choices' => array(
					'sidebar-right' => esc_html__( 'Right Sidebar', 'octavian' ),
					'sidebar-left'  => esc_html__( 'Left Sidebar', 'octavian' ),
					'no-sidebar'    => esc_html__( 'No Sidebar', 'octavian' ),
				),
				'desc' => esc_html__( 'Specify layout on the shop single page.', 'octavian' ),
				'active_callback' => 'octavian_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_single_featured_title',
			'default' => esc_html__( 'Our Shop', 'octavian' ),
			'control' => array(
				'label' => esc_html__( 'Shop Single: Featured Title', 'octavian' ),
				'type' => 'text',
				'active_callback' => 'octavian_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_single_featured_title_background_img',
			'control' => array(
				'type' => 'image',
				'label' => esc_html__( 'Shop Single: Featured Title Background', 'octavian' ),
				'active_callback' => 'octavian_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_realted_columns',
			'default' => '3',
			'control' => array(
				'label' => esc_html__( 'Related Product Columns', 'octavian' ),
				'type' => 'select',
				'choices' => array(
					'2' => '2',
					'3' => '3',
					'4' => '4',
				),
				'active_callback' => 'octavian_cac_has_woo',
			),
		),
	),
);