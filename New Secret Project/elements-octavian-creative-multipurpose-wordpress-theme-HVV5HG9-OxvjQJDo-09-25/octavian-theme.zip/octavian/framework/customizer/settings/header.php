<?php
/**
 * Header setting for Customizer
 *
 * @package octavian
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Header General
$this->sections['octavian_header_general'] = array(
	'title' => esc_html__( 'General', 'octavian' ),
	'panel' => 'octavian_header',
	'settings' => array(
		array(
			'id' => 'header_background',
			'transport' => 'postMessage',
			'control' => array(
				'label' => esc_html__( 'Background', 'octavian' ),
				'type' => 'color',
			),
			'inline_css' => array(
				'target' => array(
					'#site-header:after'
				),
				'alter' => 'background-color',
			),
		),
		array(
			'id' => 'header_padding',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Padding', 'octavian' ),
				'description' => esc_html__( 'Top Right Bottom Left.', 'octavian' ),
			),
			'inline_css' => array(
				'media_query' => '(min-width: 1199px)',
				'target' => '.site-header-inner',
				'alter' => 'padding',
			),
			'sanitize_callback' => 'esc_url',
		),
		array(
			'id' => 'header_class',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Extra Class', 'octavian' ),
				'type' => 'text',
				'desc' => esc_html__( 'Header Class for all pages on website. (e.g. pages, blog posts, single post, archives, etc ). Single page can override this setting in Page Settings metabox when edit.', 'octavian' )
			),
		),
	)
);

// Header Logo
$this->sections['octavian_header_logo'] = array(
	'title' => esc_html__( 'Logo', 'octavian' ),
	'panel' => 'octavian_header',
	'settings' => array(
		array(
			'id' => 'custom_logo',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Logo Image', 'octavian' ),
				'type' => 'image',
			),
		),
		array(
			'id' => 'logo_width',
			'control' => array(
				'label' => esc_html__( 'Logo Width', 'octavian' ),
				'type' => 'text',
			),
		),
	)
);

// Header Menu
$this->sections['octavian_header_menu'] = array(
	'title' => esc_html__( 'Menu', 'octavian' ),
	'panel' => 'octavian_header',
	'settings' => array(
		// General
		array(
			'id' => 'menu_show_current',
			'default' => false,
			'control' => array(
				'label' => esc_html__( 'Show current page indicator?', 'octavian' ),
				'type' => 'checkbox',
			),
		),
		array(
			'id' => 'menu_link_spacing',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Link Spacing', 'octavian' ),
				'description' => esc_html__( 'Example: 20px', 'octavian' ),
			),
			'inline_css' => array(
				'target' => array(
					'#main-nav > ul > li',
				),
				'alter' => array(
					'padding-left',
					'padding-right',
				),
			),
		),
		array(
			'id' => 'menu_height',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Menu Height', 'octavian' ),
				'description' => esc_html__( 'Example: 100px', 'octavian' ),
			),
			'inline_css' => array(
				'target' => array(
					'#site-header #main-nav > ul > li > a',
				),
				'alter' => array(
					'height',
					'line-height',
				),
			),
		),
		array(
			'id' => 'menu_link_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color', 'octavian' ),
			),
			'inline_css' => array(
				'target' => array(
					'#main-nav > ul > li > a > span',
				),
				'alter' => 'color',
			),
		),
		array(
			'id' => 'menu_link_color_hover',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color: Hover', 'octavian' ),
			),
			'inline_css' => array(
				'target' => array(
					'#main-nav > ul > li > a:hover > span',
				),
				'alter' => 'color',
			),
		),
	)
);

// Search & Cart
$this->sections['octavian_header_search_cart'] = array(
	'title' => esc_html__( 'Search & Cart', 'octavian' ),
	'panel' => 'octavian_header',
	'settings' => array(
		// Search Icon
		array(
			'id' => 'header_search_icon',
			'default' => false,
			'control' => array(
				'label' => esc_html__( 'Search Icon', 'octavian' ),
				'type' => 'checkbox',
			),
		),
		// Cart Icon
		array(
			'id' => 'header_cart_icon',
			'default' => false,
			'control' => array(
				'label' => esc_html__( 'Cart Icon', 'octavian' ),
				'type' => 'checkbox',
				'active_callback' => 'octavian_cac_has_woo',
			),
		),
	)
);

// Button
$this->sections['octavian_header_button'] = array(
	'title' => esc_html__( 'Button', 'octavian' ),
	'panel' => 'octavian_header',
	'settings' => array(
		array(
			'id' => 'header_button_text',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Text', 'octavian' ),
				'type' => 'text',
			),
		),
		array(
			'id' => 'header_button_url',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Url', 'octavian' ),
				'type' => 'text',
			),
		),
		array(
			'id' => 'header_button_extra',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Extra Class', 'octavian' ),
				'type' => 'text',
			),
		),
	),
);

// Header Info
$this->sections['octavian_header_info'] = array(
	'title' => esc_html__( 'Header Information', 'octavian' ),
	'panel' => 'octavian_header',
	'settings' => array(
		// Content
		array(
			'id' => 'header_info_phone_prefix',
			'default' => 'Phone:',
			'control' => array(
				'label' => esc_html__( 'Phone', 'octavian' ),
				'type' => 'text',
				'rows' => 3,
			),
		),
		array(
			'id' => 'header_info_phone',
			'default' => '',
			'control' => array(
				'type' => 'text',
				'rows' => 3,
			),
		),
		array(
			'id' => 'header_info_email_prefix',
			'default' => 'Email:',
			'control' => array(
				'label' => esc_html__( 'Email', 'octavian' ),
				'type' => 'text',
				'rows' => 3,
			),
		),
		array(
			'id' => 'header_info_email',
			'default' => '',
			'control' => array(
				'type' => 'text',
				'rows' => 3,
			),
		),	
		array(
			'id' => 'header_info_address_prefix',
			'default' => 'Address:',
			'control' => array(
				'label' => esc_html__( 'Address', 'octavian' ),
				'type' => 'text',
				'rows' => 3,
			),
		),
		array(
			'id' => 'header_info_address',
			'default' => '',
			'control' => array(
				'type' => 'text',
				'rows' => 3,
			),
		),
		// Style
		array(
			'id' => 'header_info_color',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Header Infor Color', 'octavian' ),
				'type' => 'color',
			),
			'inline_css' => array(
				'target' => '.header-info .content, #header.header-dark .header-info .content',
				'alter' => 'color',
			),
		),
	),
);
