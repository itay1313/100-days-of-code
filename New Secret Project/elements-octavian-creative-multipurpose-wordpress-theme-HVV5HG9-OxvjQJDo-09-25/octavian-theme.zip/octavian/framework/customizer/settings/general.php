<?php
/**
 * General setting for Customizer
 *
 * @package octavian
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Accent Colors
$this->sections['octavian_accent_colors'] = array(
	'title' => esc_html__( 'Accent Colors', 'octavian' ),
	'panel' => 'octavian_general',
	'settings' => array(
		array(
			'id' => 'accent_color',
			'default' => '#4a44f2',
			'control' => array(
				'label' => esc_html__( 'Accent Color', 'octavian' ),
				'type' => 'color',
			),
		),
	)
);

// PreLoader
$this->sections['octavian_preloader'] = array(
	'title' => esc_html__( 'PreLoader', 'octavian' ),
	'panel' => 'octavian_general',
	'settings' => array(
		array(
			'id' => 'preloader',
			'default' => 'animsition',
			'control' => array(
				'label' => esc_html__( 'Preloader Option', 'octavian' ),
				'type' => 'select',
				'choices' => array(
					'animsition' => esc_html__( 'Enable','octavian' ),
					'' => esc_html__( 'Disable','octavian' )
				),
			),
		),
		array(
			'id' => 'preload_color_1',
			'default' => '#4a44f2',
			'control' => array(
				'label' => esc_html__( 'Color', 'octavian' ),
				'type' => 'color',
			),
			'inline_css' => array(
				'target' => '.animsition-loading',
				'alter' => 'background-color',
			),
		),
	)
);

// Header Site
$this->sections['octavian_header_site'] = array(
	'title' => esc_html__( 'Header Site', 'octavian' ),
	'panel' => 'octavian_general',
	'settings' => array(
		array(
			'id' => 'header_site_style',
			'default' => 'style-2',
			'control' => array(
				'label' => esc_html__( 'Header Style', 'octavian' ),
				'type' => 'select',
				'choices' => array(
					'style-1' => esc_html__( 'Basic', 'octavian' ),
					'style-2' => esc_html__( 'Modern', 'octavian' ),
				),
				'desc' => esc_html__( 'Header Style for all pages on website. (e.g. pages, blog posts, single post, archives, etc ). Single page can override this setting in Page Settings metabox when edit.', 'octavian' )
			),
		),
		array(
			'id' => 'header_fixed',
			'default' => false,
			'control' => array(
				'label' => esc_html__( 'Header Fixed: Enable', 'octavian' ),
				'type' => 'checkbox',
			),
		),
	),
);

// Scroll to top
$this->sections['octavian_scroll_top'] = array(
	'title' => esc_html__( 'Scroll Top Button', 'octavian' ),
	'panel' => 'octavian_general',
	'settings' => array(
		array(
			'id' => 'scroll_top',
			'default' => true,
			'control' => array(
				'label' => esc_html__( 'Enable', 'octavian' ),
				'type' => 'checkbox',
			),
		),
	),
);

// Forms
$this->sections['octavian_general_forms'] = array(
	'title' => esc_html__( 'Forms', 'octavian' ),
	'panel' => 'octavian_general',
	'settings' => array(
		array(
			'id' => 'input_border_rounded',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Border Rounded', 'octavian' ),
			),
			'inline_css' => array(
				'target' => array(
					'textarea,input[type="text"],input[type="password"],input[type="datetime"],input[type="datetime-local"],input[type="date"],input[type="month"],input[type="time"],input[type="week"],input[type="number"],input[type="email"],input[type="url"],input[type="search"],input[type="tel"],input[type="color"]',
				),
				'alter' => 'border-radius',
			),
		),
		array(
			'id' => 'input_background_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Background', 'octavian' ),
			),
			'inline_css' => array(
				'target' => array(
					'textarea,input[type="text"],input[type="password"],input[type="datetime"],input[type="datetime-local"],input[type="date"],input[type="month"],input[type="time"],input[type="week"],input[type="number"],input[type="email"],input[type="url"],input[type="search"],input[type="tel"],input[type="color"]',
				),
				'alter' => 'background-color',
			),
		),
		array(
			'id' => 'input_border_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Border Color', 'octavian' ),
			),
			'inline_css' => array(
				'target' => array(
					'textarea,input[type="text"],input[type="password"],input[type="datetime"],input[type="datetime-local"],input[type="date"],input[type="month"],input[type="time"],input[type="week"],input[type="number"],input[type="email"],input[type="url"],input[type="search"],input[type="tel"],input[type="color"]',
				),
				'alter' => 'border-color',
			),
		),
		array(
			'id' => 'input_border_width',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Border Width', 'octavian' ),
				'description' => esc_html__( 'Enter a value in pixels. Example: 1px', 'octavian' ),
			),
			'inline_css' => array(
				'target' => array(
					'textarea,input[type="text"],input[type="password"],input[type="datetime"],input[type="datetime-local"],input[type="date"],input[type="month"],input[type="time"],input[type="week"],input[type="number"],input[type="email"],input[type="url"],input[type="search"],input[type="tel"],input[type="color"]',
				),
				'alter' => 'border-width',
			),
		),
		array(
			'id' => 'input_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Color', 'octavian' ),
			),
			'inline_css' => array(
				'target' => array(
					'textarea,input[type="text"],input[type="password"],input[type="datetime"],input[type="datetime-local"],input[type="date"],input[type="month"],input[type="time"],input[type="week"],input[type="number"],input[type="email"],input[type="url"],input[type="search"],input[type="tel"],input[type="color"]',
				),
				'alter' => 'color',
			),
		),
	),
);

// Responsive
$this->sections['octavian_responsive'] = array(
	'title' => esc_html__( 'Responsive', 'octavian' ),
	'panel' => 'octavian_general',
	'settings' => array(
		// Mobile Logo
		array(
			'id' => 'heading_mobile_logo',
			'control' => array(
				'type' => 'octavian-heading',
				'label' => esc_html__( 'Mobile Logo', 'octavian' ),
			),
		),
		array(
			'id' => 'mobile_logo_width',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Mobile Logo: Width', 'octavian' ),
				'description' => esc_html__( 'Example: 150px', 'octavian' ),
			),
			'inline_css' => array(
				'media_query' => '(max-width: 991px)',
				'target' => '#site-logo',
				'alter' => 'max-width',
			),
		),
		array(
			'id' => 'mobile_logo_margin',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Mobile Logo: Margin', 'octavian' ),
				'description' => esc_html__( 'Example: 20px 0px 20px 0px', 'octavian' ),
			),
			'inline_css' => array(
				'media_query' => '(max-width: 991px)',
				'target' => '#site-logo-inner',
				'alter' => 'margin',
			),
		),
		// Mobile Menu
		array(
			'id' => 'heading_mobile_menu',
			'control' => array(
				'type' => 'octavian-heading',
				'label' => esc_html__( 'Mobile Menu', 'octavian' ),
			),
		),
		array(
			'id' => 'mobile_menu_item_height',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Item Height', 'octavian' ),
				'description' => esc_html__( 'Example: 40px', 'octavian' ),
			),
			'inline_css' => array(
				'target' => array(
					'#main-nav-mobi ul > li > a',
					'#main-nav-mobi .menu-item-has-children .arrow'
				),
				'alter' => 'line-height'
			),
		),
		array(
			'id' => 'mobile_menu_logo',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Mobile Menu Logo', 'octavian' ),
				'type' => 'image',
			),
		),
		array(
			'id' => 'mobile_menu_logo_width',
			'control' => array(
				'label' => esc_html__( 'Mobile Menu Logo: Width', 'octavian' ),
				'type' => 'text',
			),
		),
		// Featured Title
		array(
			'id' => 'heading_featured_title',
			'control' => array(
				'type' => 'octavian-heading',
				'label' => esc_html__( 'Mobile Featured Title', 'octavian' ),
			),
		),
		array(
			'id' => 'mobile_featured_title_padding',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Padding', 'octavian' ),
				'description' => esc_html__( 'Top Right Bottom Left.', 'octavian' ),
				'active_callback' => 'octavian_cac_has_featured_title',
			),
			'inline_css' => array(
				'media_query' => '(max-width: 991px)',
				'target' => '#featured-title .inner-wrap, #featured-title.centered .inner-wrap, #featured-title.creative .inner-wrap',
				'alter' => 'padding',
			),
		),
	)
);