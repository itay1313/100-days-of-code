<?php
/**
 * Framework functions
 *
 * @package octavian
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Return class for reploader site
function octavian_preloader_class() {
	// Get page preloader option from theme mod
	$class = octavian_get_mod( 'preloader', 'animsition' );
	return esc_attr( $class );
}

// Get layout position for pages
function octavian_layout_position() {
	// Default layout position
	$layout = 'sidebar-right';

	// Get layout position for site
	$layout = octavian_get_mod( 'site_layout_position', 'sidebar-right' );

	// Remove sidebar on member page
	if ( is_singular( 'member' ) ) {
		$layout = 'no-sidebar';
	}

	// Get layout position for single post
	if ( is_singular( 'post' ) )
		$layout = octavian_get_mod( 'single_post_layout_position', 'sidebar-right' );

	// Single post/page can have custom layout position
	if ( is_singular() && octavian_metabox( 'page_layout' ) )
		$layout = octavian_metabox( 'page_layout' );

	// Get layout position for shop pages
	if ( class_exists( 'woocommerce' ) ) {
		if ( is_shop() || is_product_category() )
			$layout = octavian_get_mod( 'shop_layout_position', 'no-sidebar' );  
		if ( is_singular( 'product' ) )
			$layout = octavian_get_mod( 'shop_single_layout_position', 'no-sidebar' );
		if ( is_cart() || is_checkout() ) {
			if ( octavian_metabox( 'page_layout' ) ) {
				$layout = octavian_metabox( 'page_layout' );
			} else {
				$layout = 'no-sidebar';
			}
		}
	}

	return $layout;
}

// Theme pagination
function octavian_pagination( $query = '', $echo = true ) {
	
	$prev_arrow = '<i class="elegant-arrow_carrot-left"></i>';
	$next_arrow = '<i class="elegant-arrow_carrot-right"></i>';

	if ( ! $query ) {
		global $wp_query;
		$query = $wp_query;
	}

	$total  = $query->max_num_pages;
	$big    = 999999999;

	// Display pagination
	if ( $total > 1 ) {

		// Get current page
		if ( $current_page = get_query_var( 'paged' ) ) {
			$current_page = $current_page;
		} elseif ( $current_page = get_query_var( 'page' ) ) {
			$current_page = $current_page;
		} else {
			$current_page = 1;
		}

		// Get permalink structure
		if ( get_option( 'permalink_structure' ) ) {
			if ( is_page() ) {
				$format = 'page/%#%/';
			} else {
				$format = '/%#%/';
			}
		} else {
			$format = '&paged=%#%';
		}

		$args = array(
			'base'      => str_replace( $big, '%#%', html_entity_decode( get_pagenum_link( $big ) ) ),
			'format'    => $format,
			'current'   => max( 1, $current_page ),
			'total'     => $total,
			'mid_size'  => 3,
			'type'      => 'list',
			'prev_text' => $prev_arrow,
			'next_text' => $next_arrow
		);

		// Output
		if ( $echo ) {
			echo '<div class="octavian-pagination clearfix">'. paginate_links( $args ) .'</div>';
		} else {
			return '<div class="octavian-pagination clearfix">'. paginate_links( $args ) .'</div>';
		}

	}
}

// Render blog entry blocks
function octavian_blog_entry_layout_blocks() {

	// Get layout blocks
	$blocks = octavian_get_mod( 'blog_entry_composer' );

	// If blocks are 100% empty return defaults
	$blocks = $blocks ? $blocks : 'meta,title,excerpt_content,readmore';

	// Convert blocks to array so we can loop through them
	if ( ! is_array( $blocks ) ) {
		$blocks = explode( ',', $blocks );
	}

	// Set block keys equal to vals
	$blocks = array_combine( $blocks, $blocks );

	// Return blocks
	return $blocks;
}

// Render blog meta items
function octavian_entry_meta() {
	// Get meta items from theme mod
	$meta_item = octavian_get_mod( 'blog_entry_meta_items', array( 'date', 'categories' ) );

	// If blocks are 100% empty return defaults
	$meta_item = $meta_item ? $meta_item : 'author,comments';

	// Turn into array if string
	if ( $meta_item && ! is_array( $meta_item ) ) {
		$meta_item = explode( ',', $meta_item );
	}

	// Set keys equal to values
	$meta_item = array_combine( $meta_item, $meta_item );

	// Loop through items
	foreach ( $meta_item as $item ) :
		if ( 'author' == $item ) {
			printf( '<span class="post-by-author item">%4$s <a class="name" href="%1$s" title="%2$s">%3$s</a></span>',
				esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
				esc_attr( sprintf( esc_html__( 'View all posts by %s', 'octavian' ), get_the_author() ) ),
				get_the_author(),
				esc_html__( 'by', 'octavian' )
			);
			
		}
		else if ( 'comments' == $item ) {
			if ( comments_open() || get_comments_number() ) {
				echo '<span class="post-comment item"><span class="inner">';
				comments_popup_link( esc_html__( '0 comments', 'octavian' ), esc_html__( '1 Comment', 'octavian' ), esc_html__( '% Comments', 'octavian' ) );
				echo '</span></span>';
			}
		}
		else if ( 'date' == $item ) {
			printf( '<span class="post-date item"><span class="entry-date">%1$s</span></span>',
				get_the_date()
			);
		}
		else if ( 'categories' == $item ) {
			echo '<span class="post-meta-categories item">' . esc_html__( 'in ', 'octavian' );
			the_category( ', ', get_the_ID() );
			echo '</span>';
		}
	endforeach;
}

// Return background CSS
function octavian_bg_css( $style ) {
	$css = '';
	if ( $style = octavian_get_mod( $style ) ) {
		if ( 'fixed' == $style ) {
			$css .= ' background-position: center center; background-repeat: no-repeat; background-attachment: fixed; background-size: cover;';
		} elseif ( 'fixed-top' == $style ) {
			$css .= ' background-position: center top; background-repeat: no-repeat; background-attachment: fixed; background-size: cover;';
		} elseif ( 'fixed-bottom' == $style ) {
			$css .= ' background-position: center bottom; background-repeat: no-repeat; background-attachment: fixed; background-size: cover;';
		} elseif ( 'cover' == $style ) {
			$css .= ' background-repeat: no-repeat; background-position: center top; background-size: cover;';
		} elseif ( 'center-top' == $style ) {
			$css .= ' background-repeat: no-repeat; background-position: center top;';
		} elseif ( 'repeat' == $style ) {
			$css .= ' background-repeat: repeat;';
		} elseif ( 'repeat-x' == $style ) {
			$css .= ' background-repeat: repeat-x;';
		} elseif ( 'repeat-y' == $style ) {
			$css .= ' background-repeat: repeat-y;';
		}
	}

	return esc_attr( $css );
}

// Return background css for elements
function octavian_element_bg_css( $bg ) {
	$css = '';
	$style = $bg .'_style';

	if ( $bg_img = octavian_get_mod( $bg ) )
		$css .= 'background-image: url('. esc_url( $bg_img ). ');';

	$css .= octavian_bg_css( $style );

	return esc_attr( $css );
}

// Return background css for featured title area
function octavian_featured_title_bg() {
	$css = '';

	if ( is_page() && octavian_metabox('featured_title_bg') ) {
		$images = octavian_metabox( 'featured_title_bg', array( 'size' => 'full', 'limit' => 1 ) );
		$image = reset( $images );
		$css .= 'background-image: url('. esc_url( $image['url'] ) .');';
	} elseif ( is_single() && ( $bg_img = octavian_get_mod( 'blog_single_featured_title_background_img' ) ) ) {
		$css .= 'background-image: url('. esc_url( $bg_img ) .');';
	} elseif ( $bg_img = octavian_get_mod( 'featured_title_background_img' ) ) {
		$css .= 'background-image: url('. esc_url( $bg_img ) .');';
	}

	if ( octavian_is_woocommerce_shop() && $bg_img = octavian_get_mod( 'shop_featured_title_background_img' ) ) {
		$css .= 'background-image: url('. esc_url( $bg_img ) .');';
	}

	if ( is_singular( 'product' ) && $bg_img = octavian_get_mod( 'shop_single_featured_title_background_img' ) ) {
		$css .= 'background-image: url('. esc_url( $bg_img ) .');';
	}

	if ( is_tax() || is_singular( 'project' ) ) {
		if ( $bg_img = octavian_get_mod( 'project_single_featured_title_background_img' ) )
			$css .= 'background-image: url('. esc_url( $bg_img ) .');';
	}

	$css .= octavian_bg_css('featured_title_background_img_style');

	return esc_attr( $css );
}

// Return background for main content area
function octavian_main_content_bg() {
	$css = '';

	if ( $bg_img = octavian_get_mod( 'main_content_background_img' ) ) {
		$css = 'background-image: url('. esc_url( $bg_img ). ');';
	}

	if ( is_page() ) {
		if ( octavian_metabox('main_content_bg') ) {
			$css = 'background-color:'. octavian_metabox('main_content_bg') .';';
		}
		if ( octavian_metabox('main_content_bg_img') ) {
			$images = octavian_metabox( 'main_content_bg_img', array( 'size' => 'full', 'limit' => 1 ) );
			$image = reset( $images );
			$css = 'background-image: url('. esc_url( $image['url'] ) .');';
		}
	}

	$css .= octavian_bg_css('main_content_background_img_style');

	return esc_attr( $css );
}

add_action( 'after_setup_theme', 'octavian_main_content_bg' );

// Return background for footer area
function octavian_footer_bg() {
	$css = '';

	if ( is_page() ) {
		if ( octavian_metabox('footer_bg') ) {
			$css .= 'background-color:'. octavian_metabox('footer_bg') .';';
		}
		if ( octavian_metabox('footer_bg_img') ) {
			$images = octavian_metabox( 'footer_bg_img', array( 'size' => 'full', 'limit' => 1 ) );
			$image = reset( $images );
			$css .= 'background-image: url('. esc_url( $image['url'] ) .');';
		}
	} elseif ( $bg_img = octavian_get_mod( 'footer_bg_img' ) ) {
		$css .= 'background-image: url('. esc_url( $bg_img ) .');';
	}

	$css .= octavian_bg_css('footer_bg_img_style');

	return esc_attr( $css );
}

// Returns array of social
function octavian_header_social_options() {
	return apply_filters ( 'octavian_header_social_options', array(
		'facebook' => array(
			'label' => esc_html__( 'Facebook', 'octavian' ),
			'icon_class' => 'fab fa-facebook-f',
		),
		'twitter' => array(
			'label' => esc_html__( 'Twitter', 'octavian' ),
			'icon_class' => 'fab fa-twitter',
		),
		'instagram'  => array(
			'label' => esc_html__( 'Instagram', 'octavian' ),
			'icon_class' => 'fab fa-instagram',
		),
		'youtube' => array(
			'label' => esc_html__( 'Youtube', 'octavian' ),
			'icon_class' => 'fab fa-youtube',
		),
		'dribbble'  => array(
			'label' => esc_html__( 'Dribbble', 'octavian' ),
			'icon_class' => 'fab fa-dribbble',
		),
		'vimeo' => array(
			'label' => esc_html__( 'Vimeo', 'octavian' ),
			'icon_class' => 'fab fa-vimeo',
		),
		'tumblr'  => array(
			'label' => esc_html__( 'Tumblr', 'octavian' ),
			'icon_class' => 'fab fa-tumblr',
		),
		'pinterest'  => array(
			'label' => esc_html__( 'Pinterest', 'octavian' ),
			'icon_class' => 'fab fa-pinterest',
		),
		'linkedin'  => array(
			'label' => esc_html__( 'LinkedIn', 'octavian' ),
			'icon_class' => 'fab fa-linkedin',
		),
	) );
}

// Check if it is WooCommerce Pages
function octavian_is_woocommerce_page() {
    if ( function_exists ( "is_woocommerce" ) && is_woocommerce() )
		return true;

    $woocommerce_keys = array (
    	"woocommerce_shop_page_id" ,
        "woocommerce_terms_page_id" ,
        "woocommerce_cart_page_id" ,
        "woocommerce_checkout_page_id" ,
        "woocommerce_pay_page_id" ,
        "woocommerce_thanks_page_id" ,
        "woocommerce_myaccount_page_id" ,
        "woocommerce_edit_address_page_id" ,
        "woocommerce_view_order_page_id" ,
        "woocommerce_change_password_page_id" ,
        "woocommerce_logout_page_id" ,
        "woocommerce_lost_password_page_id" );

    foreach ( $woocommerce_keys as $wc_page_id ) {
		if ( get_the_ID () == get_option ( $wc_page_id , 0 ) ) {
			return true ;
		}
    }
    
    return false;
}

// Checks if is WooCommerce Shop page
function octavian_is_woocommerce_shop() {
	if ( ! class_exists( 'woocommerce' ) ) {
		return false;
	} elseif ( is_shop() ) {
		return true;
	}
}

// Checks if is WooCommerce archive product page
function octavian_is_woocommerce_archive_product() {
	if ( ! class_exists( 'woocommerce' ) ) {
		return false;
	} elseif ( is_product_category() || is_product_tag() ) {
		return true;
	}
}

// Returns correct ID for any object
function octavian_parse_obj_id( $id = '', $type = 'page' ) {
	if ( $id && function_exists( 'icl_object_id' ) ) {
		$id = icl_object_id( $id, $type );
	}
	return $id;
}

// Hexdec color string to rgb(a) string
function octavian_hex2rgba( $color, $opacity = false ) {
 	$default = 'rgb(0,0,0)';

	if ( empty( $color ) ) return $default; 
    if ( $color[0] == '#' ) $color = substr( $color, 1 );

    if ( strlen( $color ) == 6 ) {
		$hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
    } elseif ( strlen( $color ) == 3 ) {
        $hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
    } else {
        return $default;
    }

    $rgb =  array_map( 'hexdec', $hex );

    if ( $opacity ) {
    	if ( abs($opacity ) > 1 ) $opacity = 1.0;
    	$output = 'rgba('. implode( ",", $rgb ) .','. $opacity .')';
    } else {
    	$output = 'rgb('. implode( ",", $rgb ) .')';
    }

    return $output;
}

// SVG Core Icons
function octavian_svg( $icon ) {
	$svg = array(
		'cart' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
						<path d="M180.213,395.039c-32.248,0-58.48,26.232-58.48,58.48s26.233,58.48,58.48,58.48c32.248,0,58.48-26.239,58.48-58.48
						C238.693,421.278,212.461,395.039,180.213,395.039z M180.213,476.201c-12.502,0-22.676-10.168-22.676-22.676
						s10.174-22.676,22.676-22.676c12.508,0,22.676,10.168,22.676,22.676S192.721,476.201,180.213,476.201z"/>
						<path d="M392.657,395.039c-32.254,0-58.486,26.233-58.486,58.48c0,32.248,26.233,58.48,58.486,58.48
						c32.242,0,58.48-26.233,58.48-58.48S424.899,395.039,392.657,395.039z M392.657,476.195c-12.508,0-22.682-10.174-22.682-22.676
						s10.174-22.67,22.682-22.67c12.502,0,22.676,10.162,22.676,22.67C415.333,466.027,405.165,476.195,392.657,476.195z"/>
						<path d="M154.553,377.143h278.676c9.894,0,17.902-8.014,17.902-17.902c0-9.888-8.014-17.902-17.902-17.902H169.776L118.522,26.96
						c-1.229-7.531-7.089-13.45-14.602-14.757L35.295,0.268c-9.769-1.695-19.012,4.828-20.707,14.566
						c-1.701,9.745,4.828,19.012,14.566,20.707l56.075,9.751l51.653,316.825C138.298,370.788,145.775,377.143,154.553,377.143z"/>
						<path d="M494.24,115.969c-3.372-4.625-8.742-7.358-14.465-7.358H115.765v35.804h339.454l-36.825,114.573H141.425v35.804h290.02
						c7.769,0,14.662-5.025,17.043-12.424l48.336-150.378C498.572,126.543,497.611,120.588,494.24,115.969z"/>
					</svg>',
		'search' => '<svg viewBox="0 0 513 512">
						<path d="m202.667969 405.339844c-111.746094 0-202.667969-90.921875-202.667969-202.664063 0-111.746093 90.921875-202.6679685 202.667969-202.6679685 111.742187 0 202.664062 90.9218755 202.664062 202.6679685 0 111.742188-90.921875 202.664063-202.664062 202.664063zm0-373.332032c-94.101563 0-170.667969 76.566407-170.667969 170.667969 0 94.101563 76.566406 170.664063 170.667969 170.664063 94.101562 0 170.664062-76.5625 170.664062-170.664063 0-94.101562-76.5625-170.667969-170.664062-170.667969zm0 0"/>
						<path d="m496 512.007812c-4.097656 0-8.191406-1.558593-11.308594-4.691406l-161.277344-161.28125c-6.25-6.25-6.25-16.382812 0-22.636718 6.25-6.25 16.382813-6.25 22.632813 0l161.28125 161.28125c6.25 6.25 6.25 16.382812 0 22.636718-3.136719 3.132813-7.230469 4.691406-11.328125 4.691406zm0 0"/>
					</svg>',
		'menu' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
						<path d="m453.332031 512h-394.664062c-32.363281 0-58.667969-26.304688-58.667969-58.667969v-394.664062c0-32.363281 26.304688-58.667969 58.667969-58.667969h394.664062c32.363281 0 58.667969 26.304688 58.667969 58.667969v394.664062c0 32.363281-26.304688 58.667969-58.667969 58.667969zm-394.664062-480c-14.699219 0-26.667969 11.96875-26.667969 26.667969v394.664062c0 14.699219 11.96875 26.667969 26.667969 26.667969h394.664062c14.699219 0 26.667969-11.96875 26.667969-26.667969v-394.664062c0-14.699219-11.96875-26.667969-26.667969-26.667969zm0 0"/>
						<path d="m346.667969 181.332031h-181.335938c-8.832031 0-16-7.167969-16-16s7.167969-16 16-16h181.335938c8.832031 0 16 7.167969 16 16s-7.167969 16-16 16zm0 0"/>
						<path d="m346.667969 272h-181.335938c-8.832031 0-16-7.167969-16-16s7.167969-16 16-16h181.335938c8.832031 0 16 7.167969 16 16s-7.167969 16-16 16zm0 0"/>
						<path d="m346.667969 362.667969h-181.335938c-8.832031 0-16-7.167969-16-16s7.167969-16 16-16h181.335938c8.832031 0 16 7.167969 16 16s-7.167969 16-16 16zm0 0"/>
					</svg>',
		'arrow_left' => '',
		'arrow_right' => '',
	);

	if ( array_key_exists( $icon, $svg) ) {
		return $svg[$icon];
	} else {
		return null;
	}
}
